using System;
using System.Threading;
using IAZI.Common.Core.Infrastructure.Interfaces.Cache.Simple;
using IAZI.Common.Infrastructure.Cache.Simple;
using Microsoft.Extensions.Caching.Memory;
using Xunit;

namespace IAZI.Common.Infrastructure.Test.Cache.Simple
{
    public class MemoryCacheServiceTest
    {
        private readonly IMemoryCacheService _memoryCacheService;
                
        public MemoryCacheServiceTest()
        {            
            var cache = new MemoryCache(new MemoryCacheOptions());
            _memoryCacheService = new MemoryCacheService(cache);
        }
        
        [Fact]
        public void GetAndSetValuesToMemoryCache()
        {
            const string cacheKey = "_CacheKeyTest";
            string data = "123456";
            
            // Getting, Setting, Expiration
            Assert.Null(_memoryCacheService.GetCachedValue<string>(cacheKey));            
            _memoryCacheService.SetCachedValue<string>(cacheKey, data, TimeSpan.FromSeconds(3));
            Assert.Equal(data, _memoryCacheService.GetCachedValue<string>(cacheKey));
            Thread.Sleep(3000); // to be sure Memory Cache has cleaned up the value
            Assert.Null(_memoryCacheService.GetCachedValue<string>(cacheKey)); 
            
            // Replace
            _memoryCacheService.SetCachedValue<string>(cacheKey, data, TimeSpan.FromSeconds(100));
            Assert.Equal(data, _memoryCacheService.GetCachedValue<string>(cacheKey));
            string data2 = "7890";
            _memoryCacheService.SetCachedValue<string>(cacheKey, data2, TimeSpan.FromSeconds(100));
            Assert.Equal(data2, _memoryCacheService.GetCachedValue<string>(cacheKey));

            // Remove
            _memoryCacheService.RemoveCachedValue(cacheKey);
            Assert.Null(_memoryCacheService.GetCachedValue<string>(cacheKey));            
            _memoryCacheService.RemoveCachedValue(cacheKey); // No exception
        }
    }
}
using Xunit;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Caching.Distributed;
using FluentAssertions;
using System.ComponentModel;

namespace IAZI.Common.Infrastructure.Test.Cache.Redis
{
    public class RedisTest
    {
        /* [Fact(Skip = "Requires setup of Redis")]
        [Trait("Category", "ExcludeTeamCity")]
        public void SimpleRedisTest()
        {   
            string server = "localhost";
            string port = "6379";
            string cnstring = $"{server}:{port}";

            var redisOptions = new RedisCacheOptions
            {
                ConfigurationOptions = new ConfigurationOptions()
            };
            redisOptions.ConfigurationOptions.EndPoints.Add(cnstring);
            var opts = Options.Create<RedisCacheOptions>(redisOptions);

            var cache = new RedisCache(opts);
            string expectedStringData = "Hello world";
            cache.Set("key003", System.Text.Encoding.UTF8.GetBytes(expectedStringData));
            var dataFromCache = cache.Get("key003");
            var actualCachedStringData = System.Text.Encoding.UTF8.GetString(dataFromCache);
            expectedStringData.Should().Be(actualCachedStringData);
        } */
    }
}
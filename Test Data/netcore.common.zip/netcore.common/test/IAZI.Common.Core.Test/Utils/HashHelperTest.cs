using System.Text;
using System;
using Xunit;
using IAZI.Common.Core.Utils;

namespace IAZI.Common.Core.Utils.Test
{    
    public class HashHelperTest
    {
        [Fact]
        public void TestConvertPasswordFormat()
        {
            var hashedPassword = "$2a$10$e/Pu7mEn0wF6dqFsek.pi.E4dXhitVJ3z9qGmSCYNnp.YmBn3JcZ.";
            var res = HashHelper.ConvertPasswordFormat(hashedPassword, 0xFF); 
            Assert.NotNull(res);

            //offeredrentmodel@iazi.ch --> Intern@lT3st
        }

        [Fact]
        public void TestPasswordHashComparison()
        {
            var hashedPassword = "$2a$10$e/Pu7mEn0wF6dqFsek.pi.E4dXhitVJ3z9qGmSCYNnp.YmBn3JcZ.";
            var userPassword = "Intern@lT3st";
            
            var result = BCrypt.Net.BCrypt.Verify(HashHelper.Pepperify(userPassword), hashedPassword);

            Assert.True(result);
        }

        [Fact]
        public void VerifyNewPasswordFlowForBCrypt()
        {
            var hashedPassword = "$2a$10$e/Pu7mEn0wF6dqFsek.pi.E4dXhitVJ3z9qGmSCYNnp.YmBn3JcZ.";
            var userPassword = "Intern@lT3st";

            var perrifiedUserPassword = HashHelper.Pepperify(userPassword);

            // Password is first added with flag
            var flaggedHashedPassword = HashHelper.ConvertPasswordFormat(hashedPassword, 0xFF); 
            var decodedHashedPassword = Convert.FromBase64String(flaggedHashedPassword);

             //convert back to string for BCrypt, ignoring first byte
            var storedHash = Encoding.UTF8.GetString(decodedHashedPassword, 1, decodedHashedPassword.Length - 1);

            var result = BCrypt.Net.BCrypt.Verify(perrifiedUserPassword, storedHash);

            Assert.True(result);

        }
    }
}
using FluentAssertions;
using IAZI.Common.Core.Utils;
using Xunit;

namespace IAZI.Common.Core.Test.Utils
{
    public class GzipHelperTest
    {
        [Fact]
        public void TestZipAndUnzip()
        {
            const string testData = "gordpgkpoekto5tj5909u9u9JIOJ¼½¬6ögädgää4tegegrgr";
            var result = GzipHelper.Zip(testData);
            result.Should().NotBeNull();

            var original = GzipHelper.UnzipToString(result);
            original.Should().NotBeNull();
            original.Should().Be(testData);
        }
    }
}
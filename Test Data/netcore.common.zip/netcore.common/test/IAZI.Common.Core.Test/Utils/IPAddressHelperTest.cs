using System.Collections.Generic;
using System.Linq;
using System.Net;
using FluentAssertions;
using IAZI.Common.Core.Models.Web.Utils;
using IAZI.Common.Core.Utils;
using Xunit;

namespace IAZI.Common.Core.Test.Utils
{
    public class IPAddressHelperTest
    {
        [Theory]
        [InlineData("127.0.0.1", new [] { "127.0.0.1", "1.2.3.4"}, true)]
        [InlineData("127.0.0.1", new [] { "127.0.0.2", "1.2.3.4"}, false)]
        [InlineData("::1", new [] { "127.0.0.2", "1.2.3.4"}, false)]
        [InlineData("::1", new [] { "127.0.0.2", "1.2.3.4", "::1"}, true)]
        public void IPAddressIsInSimpleIPSafeList(string ipAddress, string[] ipAddressSafeList, bool expectedResult)
        {
            var ipAdr = IPAddress.Parse(ipAddress);

            var ipAdrSafeList = ipAddressSafeList.Select(i => IPAddress.Parse(i));

            var result = IPAddressHelper.IPAddressIsInSimpleIPSafeList(ipAdr, ipAdrSafeList);

            result.Should().Be(expectedResult);
        }

        [Theory]
        [InlineData("127.0.0.1", new [] { "127.0.0.1", "192.168.2.0/24"}, true)]
        [InlineData("192.168.2.1", new [] { "127.0.0.1", "192.168.2.0/24"}, true)]
        [InlineData("192.167.2.1", new [] { "127.0.0.1", "192.168.2.0/24"}, false)]
        [InlineData("127.1.1.1", new [] { "127.0.0.1", "192.168.2.0/24"}, false)]
        [InlineData("127.0.0.1", new [] { "127.0.0.1", "1.2.3.4"}, true)]
        [InlineData("127.0.0.1", new [] { "127.0.0.2", "1.2.3.4"}, false)]
        [InlineData("::1", new [] { "127.0.0.2", "1.2.3.4"}, false)]
        [InlineData("::1", new [] { "127.0.0.2", "1.2.3.4", "::1"}, true)]
        public void IPAddressIsInIPSafeList(string ipAddress, string[] ipAddressSafeList, bool expectedResult)
        {
            var ipAdr = IPAddress.Parse(ipAddress);
                        
            var ipAdrSafeList = ipAddressSafeList.Select(i => new ComplexIPAddress(i));

            var result = IPAddressHelper.IPAddressIsInIPSafeList(ipAdr, ipAdrSafeList);

            result.Should().Be(expectedResult);
        }

        [Theory]
        [InlineData("192.168.2.4", "192.168.2.0/24", true)]
        [InlineData("127.0.0.1", "192.168.2.0/24", false)]
        public void IpAddressIsInRange(string ipAddress, string ipCIDRRange, bool expectedResult)
        {
            var isInRange = IPAddressHelper.IPAddressIsInCIDRRange(ipAddress, ipCIDRRange); 
            isInRange.Should().Be(expectedResult);           
        }  

        [Theory]
        [InlineData("192.168.2.0/24", true)]
        [InlineData("127.0.0.1", false)]
        public void IsCIDRIPAddress(string ipAddress, bool expectedResult)
        {
            var result = IPAddressHelper.IsCIDRIPAddress(ipAddress); 
            result.Should().Be(expectedResult);           
        }     

        
    }
}
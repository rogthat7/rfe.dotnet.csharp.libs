using System.Globalization;
using FluentAssertions;
using IAZI.Common.Core.Utils;
using Xunit;

namespace IAZI.Common.Core.Test.Utils
{
    public class CultureHelperTest
    {
        [Theory]
        [InlineData("de-CH", "de-CH", true, "de-CH")]
        [InlineData("de-CH", "de-CH", false, "c=de-CH|uic=de-CH")]
        [InlineData("en-US", "de-CH", false, "c=de-CH|uic=en-US")]
        [InlineData("en-US", "de-CH", true, "c=de-CH|uic=en-US")]
        [InlineData("de-CH", "", true, "de-CH")]
        [InlineData("de-CH", "", false, "c=de-CH|uic=de-CH")]
        public void CreateCultureString(string uiCulture, string culture, bool allowSimpleFormat, string expectedString)
        {
            var uiCi = new CultureInfo(uiCulture);
            CultureInfo ci = null;
            if (!string.IsNullOrEmpty(culture))
            {
                ci = new CultureInfo(culture);
            }

            var result = CultureHelper.CreateCultureString(uiCi, ci, allowSimpleFormat);
            result.Should().Be(expectedString);
        }
    }
}
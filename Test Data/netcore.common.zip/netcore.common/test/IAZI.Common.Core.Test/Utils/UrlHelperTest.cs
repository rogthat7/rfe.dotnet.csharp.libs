using IAZI.Common.Core.Utils;
using Xunit;

namespace IAZI.Common.Core.Test.Utils
{
    public class UrlHelperTest
    {
        [Theory]
        [InlineData("http://*:5000;https://*:5001", ";", "https", 5001)]
        [InlineData("http://*:5000;http://*:5001", ";", "http", 5000)]
        [InlineData("http://localhost:5000/test", ";", "https", 0)]
        [InlineData("http://localhost:5000/test", ";", "http", 5000)]
        [InlineData("http://*:5000/dsds;https://*:5001/fdefsd", ";", "https", 5001)]
        public void ExtractPortNumberFromUrl_GivenUrl(string url, string separator, string protocol, int expectedPort)
        {
            var resultPort = UrlHelper.ExtractPortNumberFromUrl(url, separator, protocol);
            Assert.True(resultPort == expectedPort);
        }
    }
}
using System;
using Xunit;

namespace IAZI.Common.Core.Utils.Test
{
    public class OTPGeneratorTest
    {
        [Fact]
        public void GenerateToken()
        {
            var token = OTPGenerator.GenerateRandomOTP(5);
            Assert.NotNull(token);
            Assert.Equal(5, token.Length);            
            Assert.True(int.TryParse(token, out int a));
        }

        [Fact]        
        public void GenerateTokenInvalidLength()
        {
            Assert.Throws<ArgumentNullException>(() => OTPGenerator.GenerateRandomOTP(0));
            Assert.Throws<ArgumentNullException>(() => OTPGenerator.GenerateRandomOTP(-1));
        }
    }
}
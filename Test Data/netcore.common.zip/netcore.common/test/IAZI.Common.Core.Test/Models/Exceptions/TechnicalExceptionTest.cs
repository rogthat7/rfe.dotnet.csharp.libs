using System;
using IAZI.Common.Core.Models.Exceptions;
using Xunit;

namespace IAZI.Common.Core.Test.Models.Exceptions
{
    public class TechnicalExceptionTest
    {       
        [Theory]
        [InlineData(100, "TE0100")]
        [InlineData(5100, "TE5100")]
        [InlineData(0, "TE0000")]
        [InlineData(-1, "")]
        [InlineData(99999, "")]
        public void CreateTechnicalExceptionAndCheckErrorCode(int errorCodeNumber, string expectedErrorCode)
        {
            if (errorCodeNumber < 0)
            {
                var ex = Assert.Throws<ArgumentException>(() => new TechnicalException(errorCodeNumber, "Error message"));
                Assert.Equal("errorCodeNumber needs to be >= 0", ex.Message);
            }
            else if (errorCodeNumber >= 10000)
            {
                var ex = Assert.Throws<ArgumentException>(() => new TechnicalException(errorCodeNumber, "Error message"));
                Assert.Equal("errorCodeNumber needs to be < 10000", ex.Message);
            }
            else
            {
                var be = new TechnicalException(errorCodeNumber, "Error message");
                Assert.Equal(expectedErrorCode, be.ErrorCode);
            }            
        }
    }
}
using System;
using IAZI.Common.Core.Models.Exceptions;
using Xunit;

namespace IAZI.Common.Core.Test.Models.Exceptions
{
    public class BusinessExceptionTest
    {
        [Theory]
        [InlineData(100, "BE0100")]
        [InlineData(5100, "BE5100")]
        [InlineData(0, "BE0000")]
        [InlineData(-1, "")]
        [InlineData(99999, "")]
        public void CreateBusinessExceptionAndCheckErrorCode(int errorCodeNumber, string expectedErrorCode)
        {
            if (errorCodeNumber < 0)
            {
                var ex = Assert.Throws<ArgumentException>(() => new BusinessException(errorCodeNumber, "Error message"));
                Assert.Equal("errorCodeNumber needs to be >= 0", ex.Message);
            }
            else if (errorCodeNumber >= 10000)
            {
                var ex = Assert.Throws<ArgumentException>(() => new BusinessException(errorCodeNumber, "Error message"));
                Assert.Equal("errorCodeNumber needs to be < 10000", ex.Message);
            }
            else
            {
                var be = new BusinessException(errorCodeNumber, "Error message");
                Assert.Equal(expectedErrorCode, be.ErrorCode);
            }            
        }
    }
}
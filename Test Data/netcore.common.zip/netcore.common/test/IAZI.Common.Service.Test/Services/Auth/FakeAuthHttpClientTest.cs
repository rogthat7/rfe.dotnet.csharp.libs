using System.Net.Http;
using System.Threading.Tasks;
using IAZI.Common.Service.Services.Auth;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using System;
using WireMock.Server;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Settings;
using IAZI.Common.Core.Models.Auth.Legacy;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Options;
using IAZI.Common.Core.Formatter.Json;

namespace IAZI.Common.Service.Test.Services.Auth
{
    public class FakeAuthHttpClientTest : IDisposable
    {
        #region Properties

        private WireMockServer _mockServer;        

        #endregion
        
        #region Constructor

        public FakeAuthHttpClientTest()
        {                        
            _mockServer = WireMockServer.Start(new WireMockServerSettings
            {               
            });       
        }

        public void Dispose()
        {
            _mockServer?.Stop();
        }

        #endregion

        #region Public methods

        [Fact]
        public async Task ExecuteHttpCall()
        {
            // Mock Http server
            _mockServer
                .Given(Request.Create().WithPath("/v1/apptoken").UsingPost())
                .RespondWith(
                Response.Create()
                    .WithStatusCode(200)
                    .WithBody(@"{ ""token"": ""123456789"" }")
                );           

            var serviceOptions = new ServiceOptions();
            serviceOptions.Interfaces.Add(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer, new ServiceInterface
            {
                Name = "mock value",
                BaseUrl = "mock url"
            });
            
            var optionsServiceConfiguration = Options.Create(serviceOptions);
           
            using(var httpClient = new HttpClient
            {
                BaseAddress = new Uri("http://localhost:"+_mockServer.Ports[0])
            })
            {
                var legacyAuthHttpClient = new LegacyAuthHttpClient(httpClient, Mock.Of<ILogger<LegacyAuthHttpClient>>(), optionsServiceConfiguration, new JsonSystemTextFacade());                                

                var response = await legacyAuthHttpClient.RequestAppToken(new AppTokenClientRequestDto
                {
                    App = "FakeApp",
                    IpAddress = "192.168.9.22",
                    PortalToken = "abcdef"
                });

                Assert.NotNull(response);
                Assert.NotNull(response.AppToken);
                Assert.True(response.AppToken == "123456789");
            }            
        }

        [Fact]
        public async Task ExecuteHttpCallCredentials()
        {
            // Mock Http server
            _mockServer
                .Given(Request.Create().WithPath("/v1/apptoken").UsingPost())
                .RespondWith(
                Response.Create()
                    .WithStatusCode(200)
                    .WithBody(@"{ ""token"": ""123456789"" }")
                );           

            var serviceOptions = new ServiceOptions();
            serviceOptions.Interfaces.Add(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer, new ServiceInterface
            {
                Name = "mock value",
                BaseUrl = "mock url"
            });
            
            var optionsServiceConfiguration = Options.Create(serviceOptions);
           
            using(var httpClient = new HttpClient
            {
                BaseAddress = new Uri("http://localhost:"+_mockServer.Ports[0])
            })
            {
                var legacyAuthHttpClient = new LegacyAuthHttpClient(httpClient, Mock.Of<ILogger<LegacyAuthHttpClient>>(), optionsServiceConfiguration, new JsonSystemTextFacade());                                

                var response = await legacyAuthHttpClient.RequestAppToken(new AppTokenClientRequestDto
                {
                    App = "FakeApp",
                    IpAddress = "192.168.9.22",
                    UserName = "username",
                    Password = "secret",
                });

                Assert.NotNull(response);
                Assert.NotNull(response.AppToken);
                Assert.True(response.AppToken == "123456789");
            }            
        }

        #endregion
    }
}
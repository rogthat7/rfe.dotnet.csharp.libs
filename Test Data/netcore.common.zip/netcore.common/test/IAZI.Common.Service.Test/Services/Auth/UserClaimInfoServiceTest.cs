﻿using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Service.Services.Auth;
using Xunit;
using System.Security.Claims;
using IAZI.Common.Core.Models.Auth;
using System.Linq;

namespace IAZI.Common.Auth.Test.Services
{
    public class UserClaimInfoServiceTest
    {
        private IUserClaimInfoService _userClaimInfoService;

        public UserClaimInfoServiceTest()
        {
            _userClaimInfoService = new UserClaimInfoService();
        }

        [Fact]
        public void ExtractUserClaimInfoOfIdentityServerTokenWithGroups()
        {

            ClaimsIdentity claimsIdentity = new ClaimsIdentity();
            claimsIdentity.AddClaim(new Claim(IAZIToken.IssuerClaimType, "https://dev.iazi.ch/api/auth"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenNotBeforeClaimType, "421646110"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenExpirationClaimType, "1613046477"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeClientId, "97326481230320"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.Scope, "IAZI.Service.Auth.IdentityServer"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeSubject, "91554"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeEmail, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypePreferredUserName, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeCustomerId, "65"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeCustomerName, "IAZI"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeEmail, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityRoleClaimType, "AMS"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityRoleClaimType, "Analytics"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityRoleClaimType, "Auth"));
            //Adding Duplicate
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityRoleClaimType, "Auth"));

            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            claimsPrincipal.AddIdentity(claimsIdentity);

            var userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(claimsPrincipal.Claims, null);

            Assert.NotNull(userClaimInfo);
            Assert.False(userClaimInfo.IsLegacyToken);
            Assert.NotNull(userClaimInfo.Groups);
            Assert.Equal(3, userClaimInfo.Groups.Count());
            Assert.Contains("AMS", userClaimInfo.Groups);
            Assert.Contains("Analytics", userClaimInfo.Groups);
            Assert.Contains("Auth", userClaimInfo.Groups);

        }

        [Fact]
        public void ExtractUserClaimInfoOfIdentityServerTokenWithOutGroups()
        {

            ClaimsIdentity claimsIdentity = new ClaimsIdentity();
            claimsIdentity.AddClaim(new Claim(IAZIToken.IssuerClaimType, "https://dev.iazi.ch/api/auth"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenNotBeforeClaimType, "421646110"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenExpirationClaimType, "1613046477"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeClientId, "97326481230320"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.Scope, "IAZI.Service.Auth.IdentityServer"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeSubject, "91554"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeEmail, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypePreferredUserName, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeCustomerId, "65"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeCustomerName, "IAZI"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.IdentityClaimTypeEmail, "anaik@iazi.ch"));

            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            claimsPrincipal.AddIdentity(claimsIdentity);

            var userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(claimsPrincipal.Claims, null);

            Assert.NotNull(userClaimInfo);
            Assert.False(userClaimInfo.IsLegacyToken);
            Assert.Null(userClaimInfo.Groups);

        }

        [Fact]
        public void ExtractUserClaimInfoOfLegacyTokenWithGroups()
        {
            ClaimsIdentity claimsIdentity = new ClaimsIdentity();
            claimsIdentity.AddClaim(new Claim(IAZIToken.IssuerClaimType, "https://www.iazi.ch/dev"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenExpirationClaimType, "1613046477"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.Scope, "IAZI.Service.Auth.IdentityServer"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyUserId, "91554"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyEmailAddress, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyCustomerId, "65"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyCustomerName, "IAZI"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyGroups, "AMS"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyGroups, "Analytics"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyGroups, "Auth"));
            //Adding Duplicate
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyGroups, "Auth"));

            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            claimsPrincipal.AddIdentity(claimsIdentity);

            var userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(claimsPrincipal.Claims, null);

            Assert.NotNull(userClaimInfo);
            Assert.True(userClaimInfo.IsLegacyToken);
            Assert.Equal(3, userClaimInfo.Groups.Count());
            Assert.NotNull(userClaimInfo.Groups);
            Assert.Contains("AMS", userClaimInfo.Groups);
            Assert.Contains("Analytics", userClaimInfo.Groups);
            Assert.Contains("Auth", userClaimInfo.Groups);
        }

        [Fact]
        public void ExtractUserClaimInfoOfLegacyTokenWithOutGroups()
        {
            ClaimsIdentity claimsIdentity = new ClaimsIdentity();
            claimsIdentity.AddClaim(new Claim(IAZIToken.IssuerClaimType, "https://www.iazi.ch/dev"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.TokenExpirationClaimType, "1613046477"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.Scope, "IAZI.Service.Auth.IdentityServer"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyUserId, "91554"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyEmailAddress, "anaik@iazi.ch"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyCustomerId, "65"));
            claimsIdentity.AddClaim(new Claim(IAZIToken.LegacyCustomerName, "IAZI"));

            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal();
            claimsPrincipal.AddIdentity(claimsIdentity);

            var userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(claimsPrincipal.Claims, null);

            Assert.NotNull(userClaimInfo);
            Assert.True(userClaimInfo.IsLegacyToken);
            Assert.Null(userClaimInfo.Groups);
        }
    }
}

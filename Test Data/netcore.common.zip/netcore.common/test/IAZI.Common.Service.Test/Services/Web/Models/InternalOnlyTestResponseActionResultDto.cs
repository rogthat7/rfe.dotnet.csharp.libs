using System.Runtime.Serialization;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestResponseActionResultDto
    {
        [DataMember]
        public string ActionResult
        {
            get; set;
        }
    }
}
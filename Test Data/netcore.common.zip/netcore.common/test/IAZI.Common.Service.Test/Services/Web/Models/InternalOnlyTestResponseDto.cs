using System.Runtime.Serialization;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestResponseDto
    {
        [DataMember]
        public string Result
        {
            get; set;
        }
    }
}
using System.Collections.Generic;
using System.Linq;

namespace IAZI.Common.Service.Test.Services.Web.Models
{   
    public class InternalOnlyTestCollectionParentGetResponseDto
    {
        
        //[JsonPropertyName("activeApps")]
        /// <summary>
        /// Active apps for the current user
        /// </summary>
        /// <value></value>
        public IEnumerable<InternalOnlyTestCollectionGetResponseDto> ActiveApps { get; set; }

        //[JsonPropertyName("inactiveApps")]
        /// <summary>
        /// Inactive apps for the current user
        /// </summary>
        /// <value></value>
        public IEnumerable<InternalOnlyTestCollectionGetResponseDto> InactiveApps { get; set; }
            
    }
}
namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class TestDto
    {
        public int MyProperty { get; set; }
    }
}
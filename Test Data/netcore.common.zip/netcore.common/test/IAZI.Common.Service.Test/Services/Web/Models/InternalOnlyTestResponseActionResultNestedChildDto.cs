using System.Runtime.Serialization;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestResponseActionResultNestedChildDto
    {
        [DataMember]
        public InternalOnlyTestResponseActionResultNestedChildLevel2Dto Child
        {
            get; set;
        }
    }
}
using System;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class MyCustomOptions : CustomOptions
    {
        #region Properties

        public string CustomParamString
        {
            get; set;
        }

        public int CustomParamInt
        {
            get; set;
        }

        public bool CustomParamBool
        {
            get; set;
        }     
        
        #endregion

        #region Methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(MyCustomOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }   

            if (string.IsNullOrEmpty(options.CustomParamString))
            {
                throw new Exception("CustomParamString cannot be empty");
            }

            return true;
        }

        #endregion
    }
}
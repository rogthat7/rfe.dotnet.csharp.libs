
namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestCollectionGetResponseDto
    {
        public TestDto Test { get; set; }
        
        public string AppName { get; set; }

        public int? AppSort { get; set; }
        
        public string AppLabel { get; set; }
        
        public string AppDescription { get; set; }
        
        public int AppFamily { get; set; }
        
        public string AppUrl { get; set; }
        
        public string AppIconUrl { get; set; }

        public string AppGroup { get; set; }

        public int? AppGroupId { get; set; }

        public int? AppGroupSort { get; set; }
    }
}
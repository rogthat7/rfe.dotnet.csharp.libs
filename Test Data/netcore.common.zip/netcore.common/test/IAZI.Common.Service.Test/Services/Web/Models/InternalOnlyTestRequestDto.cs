using System.Runtime.Serialization;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestRequestDto
    {
        [DataMember]
        public string Input
        {
            get; set;
        }
    }
}
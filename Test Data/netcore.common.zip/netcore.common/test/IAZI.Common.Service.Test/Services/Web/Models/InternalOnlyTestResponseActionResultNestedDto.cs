using System.Runtime.Serialization;

namespace IAZI.Common.Service.Test.Services.Web.Models
{
    public class InternalOnlyTestResponseActionResultNestedDto
    {
        [DataMember]
        public InternalOnlyTestResponseActionResultNestedChildDto Result
        {
            get; set;
        }
    }
}
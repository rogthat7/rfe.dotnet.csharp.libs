using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Web.Attributes;
using IAZI.Common.Service.Web.Controllers.Shared;
using IAZI.Common.Service.Web.Swagger;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Test.Services.Web.Controllers.V1
{
    public class AuthTestController : ApiControllerBase
    {
         #region Constructor

        public AuthTestController(IOptions<ServiceOptions> serviceOptions, ILogger<AuthTestController> logger, 
            IStringLocalizer localizer) : base(serviceOptions, logger, localizer)
        {            
        }
            
        #endregion

        #region Public methods

        [Authorize]
        [HttpGet]
        [Route("auth")]        
        [ProducesCustom("application/json", "application/problem+json")]        
        public string TestAuth()
        {
            return "Ok";
        }     

        [AllowAnonymous]
        [HttpGet]
        [Route("authanonmyous")]
        [ProducesCustom("application/json", "application/problem+json")]        
        public string TestAuthAnonymous()
        {
            return "Ok";
        }      
            
        #endregion
    }
}
using System;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Web.Attributes;
using IAZI.Common.Service.Web.Controllers.Shared;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Test.Services.Web.Controllers.V1
{
    [AllowAnonymous]
    public class TestProblemDetailsController : ApiControllerBase
    {
        #region Constructor

        public TestProblemDetailsController(IOptions<ServiceOptions> serviceOptions, ILogger<TestProblemDetailsController> logger, 
            IStringLocalizer localizer) : base(serviceOptions, logger, localizer)
        {            
        }
            
        #endregion

        #region Public methods

        [HttpGet]
        [Route("400")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status400BadRequest)]         
        public IActionResult TestProblemDetailsWithStatusCode400()
        {
            return BadRequest();
        }

        [HttpGet]
        [Route("401")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status401Unauthorized)]        
        public IActionResult TestProblemDetailsWithStatusCode401()
        {
            return Unauthorized();
        }

        [HttpGet]
        [Route("402")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status402PaymentRequired)]        
        public IActionResult TestProblemDetailsWithStatusCode402()
        {
            return StatusCode(402);
        }

        [HttpGet]
        [Route("403")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status403Forbidden)]        
        public IActionResult TestProblemDetailsWithStatusCode403()
        {
            return Forbid();
        }

        [HttpGet]
        [Route("500")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status500InternalServerError)]        
        public IActionResult TestProblemDetailsWithStatusCode500()
        {
            throw new Exception("Fake TestProblemDetailsWithStatusCode500 exception");
        }

        [HttpGet]
        [Route("500custom")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status500InternalServerError)]        
        public IActionResult TestProblemDetailsWithStatusCode500AndCustomException()
        {
            throw new IAZIHttpRequestException("Fake TestProblemDetailsWithStatusCode500 custom exception", true, StatusCodes.Status400BadRequest);
        }

        [HttpGet]
        [Route("500custom2")]
        [ProducesCustom("application/json", "application/problem+json")]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status500InternalServerError)]        
        public IActionResult TestProblemDetailsWithStatusCode500AndCustomException2()
        {
            throw new IAZIHttpRequestException("Fake TestProblemDetailsWithStatusCode500 custom exception", false, StatusCodes.Status400BadRequest);
        }
            
        #endregion
    }
}
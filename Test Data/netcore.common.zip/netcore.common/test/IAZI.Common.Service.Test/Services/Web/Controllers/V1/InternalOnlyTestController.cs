using System.Net.Mime;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Test.Services.Web.Models;
using IAZI.Common.Service.Web.Attributes;
using IAZI.Common.Service.Web.Controllers.Shared;
using IAZI.Common.Service.Web.Swagger;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Test.Services.Web.Controllers.V1
{
    public class InternalOnlyTestController : ApiControllerBase
    {
         #region Constructor

        public InternalOnlyTestController(IOptions<ServiceOptions> serviceOptions, ILogger<AuthTestController> logger, 
            IStringLocalizer localizer) : base(serviceOptions, logger, localizer)
        {            
        }
            
        #endregion

        #region Public methods

        [Authorize]
        [HttpGet]
        [Route("1")]        
        [ProducesCustom("application/json", "application/problem+json")]        
        public string Get()
        {
            return "Ok";
        }     

        [AllowAnonymous]
        [HttpGet]
        [Route("2")]
        [ProducesCustom("application/json", "application/problem+json")]        
        public string Get2()
        {
            return "Ok";
        }   

        [HideFromSwagger]
        [Authorize]
        [HttpGet]
        [Route("3")]        
        [ProducesCustom("application/json", "application/problem+json")]        
        public string GetInternal1()
        {
            return "Ok";
        }     

        [HideFromSwagger]
        [AllowAnonymous]
        [HttpGet]
        [Route("4")]
        [ProducesCustom("application/json", "application/problem+json")]        
        public string GetInternal2()
        {
            return "Ok";
        }    

        [HideFromSwagger]        
        [Authorize]
        [HttpPost]
        [Route("5")]        
        [ProducesCustom("application/json", "application/problem+json")]        
        public InternalOnlyTestResponseDto GetInternalWithComplexTypes([FromBody] InternalOnlyTestRequestDto request)
        {
            return new InternalOnlyTestResponseDto()
            {
                Result = request.Input
            };
        }    

        [HideFromSwagger]        
        [Authorize]
        [HttpPost]
        [Route("6")]        
        [ProducesCustom("application/json", "application/problem+json")] 
        [ProducesResponseType(typeof(InternalOnlyTestResponseActionResultDto), StatusCodes.Status200OK)]       
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetInternalWithComplexTypesAndGenericActionResult([FromBody] InternalOnlyTestRequestDto request)
        {
            return Ok(new InternalOnlyTestResponseActionResultDto()
            {
                ActionResult = request.Input
            });
        }        

        [HideFromSwagger]        
        [Authorize]
        [HttpPost]
        [Route("7")]        
        [ProducesCustom("application/json", "application/problem+json")] 
        [ProducesResponseType(typeof(InternalOnlyTestResponseActionResultNestedDto), StatusCodes.Status200OK)]       
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetInternalWithComplexTypesAndGenericActionResultAndNestedSchemas([FromBody] InternalOnlyTestRequestDto request)
        {
            return Ok(new InternalOnlyTestResponseActionResultNestedDto
            {
                Result = new InternalOnlyTestResponseActionResultNestedChildDto
                {
                    Child = new InternalOnlyTestResponseActionResultNestedChildLevel2Dto
                    {
                        ActionResult = request.Input
                    }                    
                }
            });
        }   
       
        [HttpGet]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(InternalOnlyTestCollectionParentGetResponseDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetailsDto), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("8")]
        [HideFromSwagger]
        public IActionResult GetInternalWithComplexTypesAndGenericActionResultAndNestedSchemasWithCollections()
        {
           return Ok(new InternalOnlyTestCollectionParentGetResponseDto());
        }  
            
        #endregion
    }
}
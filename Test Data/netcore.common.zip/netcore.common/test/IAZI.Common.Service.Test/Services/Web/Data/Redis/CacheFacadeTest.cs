using System.Threading.Tasks;
using FluentAssertions;
using IAZI.Common.Core.Interfaces.Infrastructure.Cache.Redis;
using IAZI.Common.Service.Test.Services.Web.Init;
using StackExchange.Redis.Extensions.Core.Abstractions;
using Xunit;
using Xunit.Abstractions;

namespace IAZI.Common.Service.Test.Services.Web.Data.Redis
{
    public class CacheFacadeTest : TestServerBase<TestServiceStartup>, IClassFixture<ServiceTestWebApplicationFactory>
    {
        #region Properties       
        
        #endregion
        
        #region Constructor

        public CacheFacadeTest(ITestOutputHelper testOutputHelper, ServiceTestWebApplicationFactory factory)
        : base(testOutputHelper, factory)
        {                 
        }
            
        #endregion

        #region Public methods

        [Fact(Skip = "Requires setup of Redis, please ensure your IP is set in the Whitelist")]
        [Trait("Category", "ExcludeTeamCity")]
        public async Task TestRedis()
        {                                 
            var cache = Factory.GetService<IRedisCacheClient>();
      
            const string expectedStringData = "Hello world";
            const string key = "key003";
            await cache.GetDbFromConfiguration().AddAsync(key, expectedStringData);

            var dataFromCache = await cache.GetDbFromConfiguration().GetAsync<string>(key);
            expectedStringData.Should().Be(dataFromCache);

            await cache.GetDbFromConfiguration().RemoveAsync(key);
            dataFromCache = await cache.GetDbFromConfiguration().GetAsync<string>(key);
            dataFromCache.Should().BeNull();
        } 

        [Fact(Skip = "Requires setup of Redis, please ensure your IP is set in the Whitelist")]
        [Trait("Category", "ExcludeTeamCity")]
        public async Task CacheFacade()
        {                                 
            var cache = Factory.GetService<ICacheFacade>();
      
            var key = "12345";
            var value = "6789";

            await cache.AddAsync(key, value);
            var dataFromCache = await cache.GetAsync<string>(key);            
            dataFromCache.Should().Be(value);

            await cache.RemoveAsync(key);
            dataFromCache = await cache.GetAsync<string>(key);  
            dataFromCache.Should().BeNull();
        } 

        #endregion 
    
    }
}
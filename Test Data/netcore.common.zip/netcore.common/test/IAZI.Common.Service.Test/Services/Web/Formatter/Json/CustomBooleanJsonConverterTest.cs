using FluentAssertions;
using IAZI.Common.Core.Formatter.Json;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Options;
using Xunit;

namespace IAZI.Common.Core.Test.Formatter.Json
{
    public class CustomBooleanJsonConverterTest
    {        
        private readonly IJsonFacade _jsonFacade;

        public CustomBooleanJsonConverterTest()
        {
            _jsonFacade = new JsonSystemTextFacade();
        }

        [Fact]
        public void Deserialize_WithUseJsonCustomBoolConverter()
        {
            var jsonOptions = new JsonOptions
            {
                UseJsonCustomBoolConverter = true
            };
            
            var json = "{\"isSwiss\":null,\"isPreferred\":1}";
            
            var res = _jsonFacade.DeserializeObject<CustomBooleanJsonConverterTestEntity>(json, jsonOptions); 
            res.Should().NotBeNull();
            res.isPreferred.Should().BeTrue();
            res.isSwiss.Should().BeNull();
        }

        [Fact]
        public void Deserialize_WithUseJsonCustomBoolConverterInclNullable()
        {
            var jsonOptions = new JsonOptions
            {
                UseJsonCustomBoolConverter = true
            };
            
            var json = "{\"isSwiss\":1,\"isPreferred\":1}";

            var res = _jsonFacade.DeserializeObject<CustomBooleanJsonConverterTestEntity>(json, jsonOptions); 
            res.Should().NotBeNull();
            res.isSwiss.Should().BeTrue();
        }

        [Fact]
        public void Deserialize_WithUseJsonCustomBoolConverterInclNullableButUsingProperBoolean()
        {
            var jsonOptions = new JsonOptions
            {
                UseJsonCustomBoolConverter = true
            };
            
            var json = "{\"isSwiss\":true, \"isPreferred\":false}";

            var res = _jsonFacade.DeserializeObject<CustomBooleanJsonConverterTestEntity>(json, jsonOptions); 
            res.Should().NotBeNull();
            res.isSwiss.Should().BeTrue();
            res.isPreferred.Should().BeFalse();
        }   
        
    }

    public class CustomBooleanJsonConverterTestEntity
    {        
        public bool? isSwiss { get; set; }  

        public bool isPreferred { get; set; }   
    }    
}
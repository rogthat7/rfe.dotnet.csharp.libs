using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using IAZI.Common.Core.Formatter.Json;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Options;
using Newtonsoft.Json;
using Xunit;

namespace IAZI.Common.Core.Test.Formatter.Json
{
    public class JsonSystemTextFacadeTest
    {
        #region Constants

        private const string _jsonIdToken = @"
        {
            ""email"": ""buehler@iazi.ch"",
            ""customerName"": ""IAZI"",
            ""userId"": ""90016"",
            ""customerId"": ""65"",
            ""appData"": {
                ""portal"": {
                ""activeApps"": [
                    ""leadManagement"",
                    ""ams"",
                    ""analytics"",
                    ""authManagement"",
                    ""benchmark"",
                    ""nearestNeighbour"",
                    ""cockpit_administration"",
                    ""qliksense"",
                    ""cockpit_gmos"",
                    ""dashboard_allianz"",
                    ""qlikview"",
                    ""dashboard_hypo"",
                    ""dashboard_immo"",
                    ""fileBox"",
                    ""hedo"",
                    ""maps"",
                    ""mapsPro"",
                    ""moduledcfTester"",
                    ""neutral"",
                    ""offeredRent"",
                    ""qualicasa"",
                    ""rentcalculator"",
                    ""rentCalculator"",
                    ""repm3"",
                    ""repm5_cpv_2020"",
                    ""repm5"",
                    ""cockpit_cpv"",
                    ""repm5_rg_2020""
                ],
                ""inactiveApps"": [
                    ""ams"",
                    ""mapsPro"",
                    ""benchmark"",
                    ""lore""
                ]
                }
            },
            ""iat"": 1579775050,
            ""exp"": 1579861450,
            ""aud"": ""iJbqXTj9oETMZZWW7q6cRCygNQ4VC0oU"",
            ""iss"": ""https://www.iazi.ch/dev""
        }";

        private const string jsonAuth = @"
        {
            ""util"": {
                ""bionic"": true
            },
            ""address"": {
                ""modebase"": true,
                ""modegeocode"": true,
                ""superUser"": true,
                ""modeinternal"": true
            },
            ""report"": {
                ""ams"": {
                ""appraisalReport"": true
                }
            },
            ""nearestNeighbour"": {
                ""active"": true,
                ""userMode"": 2
            },
            ""offeredRent"": {
                ""active"": true,
                ""userMode"": 1
            },
            ""modelr"": {
                ""GVCH"": {
                ""modebase"": true,
                ""missing"": true
                },
                ""PackageId"": [
                2
                ],
                ""aging"": true,
                ""modeinternal"": true,
                ""doSave"": true,
                ""RACH"": {
                ""FCF"": true,
                ""GIR"": true
                },
                ""PRCH"": {
                ""R5"": true,
                ""R4"": true,
                ""R3"": true,
                ""R1"": true,
                ""missing"": true
                },
                ""ORCH"": {
                ""Residential"": true,
                ""Commercial"": true,
                ""missing"": true
                },
                ""OPCH"": {
                ""A3"": true,
                ""A2"": true,
                ""missing"": true
                },
                ""OPDE"": {
                ""A3"": true,
                ""A2"": true,
                ""missing"": false
                },
                ""PPAT"": {
                ""A3"": true,
                ""A2"": true,
                ""missing"": true
                },
                ""PPCH"": {
                ""A1"": true,
                ""A2"": true,
                ""A3"": true,
                ""missing"": true,
                ""A1Heuristic"": true,
                ""HP"": {
                    ""HR_WCM"": 1,
                    ""HR_LR"": -0.2,
                    ""HR_LO"": -0.1,
                    ""HR_HO"": 0.2,
                    ""HR_HR"": 0.4,
                    ""HR_HP"": ""flat"",
                    ""HR_RC"": 20190331,
                    ""HR_AV"": 423,
                    ""HR_OD"": 1,
                    ""HR_CR"": 0.05,
                    ""HR_CT"": 0.199,
                    ""HR_BK"": 0,
                    ""HR_HK"": 0,
                    ""HR_TR"": 3.5,
                    ""HR_TV"": 6.5
                },
                ""A1caprate"": true,
                ""CP"": {
                    ""CAP_WCM"": 1,
                    ""CAP_TV"": 1,
                    ""CAP_TR"": 0.00001,
                    ""CAP_RC"": 20190331,
                    ""CAP_OD"": 2,
                    ""CAP_LR"": -0.2,
                    ""CAP_LO"": -0.1,
                    ""CAP_HR"": 0.4,
                    ""CAP_HP"": ""rent"",
                    ""CAP_HO"": 0.2,
                    ""CAP_HK"": 0,
                    ""CAP_CT"": 0.2,
                    ""CAP_CR"": 0.05,
                    ""CAP_BK"": 0,
                    ""CAP_AV"": 423
                }
                },
                ""LPCH"": {
                ""A2"": true,
                ""missing"": true
                },
                ""CPCH"": {
                ""A2"": true,
                ""missing"": true
                }
            },
            ""micro"": {
                ""modebase"": true,
                ""modegeocode"": true,
                ""modeinternal"": true,
                ""placedistance"": true
            },
            ""wizard"": {
                ""modebase"": true
            },
            ""reportrepm5"": {
                ""modebase"": true
            },
            ""macro"": {
                ""modebase"": true,
                ""ModeHistorical"": true,
                ""macroTownHistory"": false,
                ""superuser"": true
            },
            ""lore"": {
                ""modebase"": true,
                ""locationdata"": true
            },
            ""benchmark"": {
                ""portfolios"": [
                1
                ]
            },
            ""qlikview"": {
                ""dashboards"": [
                {
                    ""document"": ""QlikView/4_PROD/ubs.qvw""
                }
                ]
            },
            ""qualicasa"": {
                ""qcdiagnose"": ""true"",
                ""qcdiagnoseplot"": ""true"",
                ""qcmonitoring"": ""true"",
                ""qcmonitoringplotmatrixtransposed"": ""true"",
                ""qcplanning"": ""true"",
                ""qcplanningextended"": ""true"",
                ""qcriskplotmatrix"": ""true"",
                ""qcrating"": ""true"",
                ""qccomponents"": ""true"",
                ""qcmaterials"": ""true"",
                ""qcindexed"": ""true"",
                ""qctest"": ""true""
            },
            ""data"": {
                ""active"": ""true"",
                ""modebase"": ""true"",
                ""objectreport"": ""true""
            },
            ""sms"": {
                ""modelbase"": true
            },
            ""utilities"": {
                ""modebase"": ""true""
            },
            ""portal"": {
                ""activeApps"": [
                ""authManagement"",
                ""benchmark"",
                ""maps"",
                ""rentcalculator"",
                ""nearestNeighbour"",
                ""offeredRent"",
                ""repm5"",
                ""repm5_dcf"",
                ""repm5_demo"",
                ""repm5_bas"",
                ""repm5_allianz"",
                ""repm5_bas_local"",
                ""repm5_allianz_local""
                ]
            },
            ""rentcalculator"": {
                ""active"": true,
                ""permissions"": {
                ""Modebase"": true,
                ""PRResidential"": true,
                ""ORResidential"": true,
                ""Commercial"": true,
                ""Parking"": true
                }
            },
            ""authManagement"": {
                ""rolePortal"": true,
                ""roleAuthManagement"": true
            },
            ""PriceImmoSnap"": {},
            ""template"": {
                ""modebase"": true,
                ""active"": true
            }
        }
        ";

        private const string _jsonIdTokenWithoutLineBreaks = "{  \"email\": \"buehler@iazi.ch\",  \"customerName\": \"IAZI\",  \"userId\": \"90016\",  \"customerId\": \"65\",  \"appData\": {    \"portal\": {      \"activeApps\": [        \"leadManagement\",        \"ams\",        \"analytics\",        \"authManagement\",        \"benchmark\",        \"nearestNeighbour\",        \"cockpit_administration\",        \"qliksense\",        \"cockpit_gmos\",        \"dashboard_allianz\",        \"qlikview\",        \"dashboard_hypo\",        \"dashboard_immo\",        \"fileBox\",        \"hedo\",        \"maps\",        \"mapsPro\",        \"moduledcfTester\",        \"neutral\",        \"offeredRent\",        \"qualicasa\",        \"rentcalculator\",        \"rentCalculator\",        \"repm3\",        \"repm5_cpv_2020\",        \"repm5\",        \"cockpit_cpv\",        \"repm5_rg_2020\"      ],      \"inactiveApps\": [        \"ams\",        \"mapsPro\",        \"benchmark\",        \"lore\"      ]    }  },  \"iat\": 1579775050,  \"exp\": 1579861450,  \"aud\": \"iJbqXTj9oETMZZWW7q6cRCygNQ4VC0oU\",  \"iss\": \"https://www.iazi.ch/dev\"}";
        
        #endregion
        
        
        #region Properties

        private readonly IJsonFacade _jsonFacade;

        #endregion

        #region Constructor
        
        public JsonSystemTextFacadeTest()
        {
            _jsonFacade = new JsonSystemTextFacade();
        }

        #endregion

        #region Public methods

        [Fact]
        public void Serialize_GivenObject_ReturnsString()
        {
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = true,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = true
            };
            
            // In the legacy service common code there was a section that was passing
            // a string to the JSON serializer, with this test we ensure that the results are the same
            var res = _jsonFacade.Serialize<string>(_jsonIdTokenWithoutLineBreaks, jsonOptions);
            Assert.NotNull(res);
            
            // Compare with Newtonsoft JSON parsing
            var newtonsoftRes = Newtonsoft.Json.JsonConvert.SerializeObject(_jsonIdTokenWithoutLineBreaks, Formatting.Indented);
            Assert.NotNull(newtonsoftRes);
            Assert.Equal(newtonsoftRes, res);

            // Common usage of a serializer
            res = _jsonFacade.Serialize<WeatherForecast>(new WeatherForecast
            {
                Date = new DateTime(2020,2,1,10,30,50),
                Summary = "Summary",
                TemperatureC = 100
            }, jsonOptions);
            Assert.NotNull(res);      
            var expectedValue = "{\n  \"Date\": \"2020-02-01T10:30:50\",\n  \"TemperatureC\": 100,\n  \"Summary\": \"Summary\"\n}";
            Assert.Equal(expectedValue, res);
        }

        [Fact]
        public async Task SerializeAsync_GivenObject_ReturnsString()
        {
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };

            // Common usage of a serializer
            var res = await _jsonFacade.SerializeAsync<WeatherForecast>(new WeatherForecast
            {
                Date = new DateTime(2020,2,1,10,30,50),
                Summary = "Summary",
                TemperatureC = 100
            }, jsonOptions);
            Assert.NotNull(res);
            Assert.NotEmpty(res);
            Assert.Equal("{\"Date\":\"2020-02-01T10:30:50\",\"TemperatureC\":100,\"Summary\":\"Summary\"}", res);
        }

        [Fact]
        public void DeserializeObject_GivenStringCreatedByGeneric_ReturnsObject()
        {          
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };
            var orgObj = new WeatherForecast
            {
                Date = new DateTime(2020,2,1,10,30,50),
                Summary = "Summary",
                TemperatureC = 100
            };
            var res = _jsonFacade.Serialize<WeatherForecast>(orgObj, jsonOptions);
            Assert.NotNull(res);    
            Assert.NotEmpty(res);
            Assert.Equal("{\"Date\":\"2020-02-01T10:30:50\",\"TemperatureC\":100,\"Summary\":\"Summary\"}", res);

            var obj = _jsonFacade.DeserializeObject<WeatherForecast>(res, jsonOptions);
            Assert.NotNull(res);
            Assert.Equal(orgObj.Date, obj.Date);
            Assert.Equal(orgObj.Summary, obj.Summary);
            Assert.Equal(orgObj.TemperatureC, obj.TemperatureC);
        }

        [Fact]
        public async Task DeserializeObjectAsync_GivenStringCreatedByGeneric_ReturnsObject()
        {          
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };
            var orgObj = new WeatherForecast
            {
                Date = new DateTime(2020,2,1,10,30,50),
                Summary = "Summary",
                TemperatureC = 100
            };
            var res = await _jsonFacade.SerializeAsync<WeatherForecast>(orgObj,jsonOptions);
            Assert.NotNull(res); 
            Assert.NotEmpty(res);
            Assert.Equal("{\"Date\":\"2020-02-01T10:30:50\",\"TemperatureC\":100,\"Summary\":\"Summary\"}", res);   

            var obj = await _jsonFacade.DeserializeObjectAsync<WeatherForecast>(res,jsonOptions);
            Assert.NotNull(res);

            Assert.Equal(orgObj.Date, obj.Date);
            Assert.Equal(orgObj.Summary, obj.Summary);
            Assert.Equal(orgObj.TemperatureC, obj.TemperatureC);
        }

        [Fact]
        public void DeserializeObject_GivenStringAndTypeParameter_ReturnsObject()
        {
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };
            var orgObj = new WeatherForecast
            {
                Date = new DateTime(2020,2,1,10,30,50),
                Summary = "Summary",
                TemperatureC = 100
            };
            var res = _jsonFacade.Serialize<WeatherForecast>(orgObj,jsonOptions);
            Assert.NotNull(res);  
            Assert.NotEmpty(res);
            Assert.Equal("{\"Date\":\"2020-02-01T10:30:50\",\"TemperatureC\":100,\"Summary\":\"Summary\"}", res);   
  
            var obj = _jsonFacade.DeserializeObject(res, orgObj.GetType(),jsonOptions);
            Assert.NotNull(res);

            var newObj = obj as WeatherForecast;
            Assert.NotNull(newObj);
            Assert.Equal(orgObj.Date, newObj.Date);
            Assert.Equal(orgObj.Summary, newObj.Summary);
            Assert.Equal(orgObj.TemperatureC, newObj.TemperatureC);
        }

        [Fact]
        public void ParseAndGetValue_GivenJsonAndPropertyString_ReturnsString()
        {
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };
            const string json = "{\"Date\":\"2020-02-01T10:30:50\",\"TemperatureC\":100,\"Summary\":\"MySummary\"}";
            const string property = "Summary";

            var res = _jsonFacade.ParseAndGetValue(json, property, false, jsonOptions);
            Assert.NotNull(res);  
            Assert.NotEmpty(res);
            Assert.Equal("MySummary", res);

            var exception = Assert.Throws<Exception>(() => _jsonFacade.ParseAndGetValue(json, "InvalidProperty", true, jsonOptions));
            Assert.NotNull(exception);  
            Assert.NotEmpty(exception.Message);
            Assert.Contains("Invalid property", exception.Message);

            res = _jsonFacade.ParseAndGetValue(json, "InvalidProperty", false, jsonOptions);
            Assert.Null(res);  
        }

        [Fact]
        public void SelectTokenValue_GivenJsonAndTokenSelector_ReturnsFoundValue()
        {
            var jsonOptions = new JsonOptions
            {
                UseRelaxedEncoding = false,
                PropertyNameCaseInsensitive = false,
                UsePropertyNamingPolicyCamelCase = false,
                WriteIndented = false
            };
            var permCheckList = new List<string> 
            {
                "address.modebase"
            };

            var res = _jsonFacade.SelectTokenValue(jsonAuth, "address.modebase", false, jsonOptions);
            Assert.NotNull(res);  
            Assert.NotEmpty(res);
            Assert.Equal("True", res);
            var flag = Convert.ToBoolean(res);
            Assert.True(flag);
        }

        #endregion
    }

    class AuthBase
    {
        public AuthAddress Address { get; set; }
    }

    class AuthAddress
    {
        public bool SuperUser { get; set; }
        public bool ModeGeoCode { get; set; }
        public bool ModeInternal { get; set; }
        public int NbLiveValidations { get; set; }
        public int NbValidations { get; set; }
    }

    class WeatherForecast
    {
        public DateTime Date { get; set; }
        public int TemperatureC { get; set; }
        public string Summary { get; set; }
    }
}
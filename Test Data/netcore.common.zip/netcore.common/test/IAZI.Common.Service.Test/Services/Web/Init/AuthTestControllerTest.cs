using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using FluentAssertions;
using IAZI.Common.Core.Utils;
using IAZI.Common.Test.IntegrationAndComponents.Shared;
using Xunit;
using Xunit.Abstractions;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class AuthTestControllerTest : IntegrationAndComponentTestBase<TestServiceStartup>, IClassFixture<ServiceTestWebApplicationFactory>
    {
        #region Properties         
  
        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="factory"></param>
        /// <returns></returns>
        public AuthTestControllerTest(ITestOutputHelper outputHelper, ServiceTestWebApplicationFactory factory) : base(outputHelper, factory)
        {
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Dispose method
        /// </summary>
        public override void Dispose()
        {      
            base.Dispose();
        }

        #endregion

        #region Protected methods

        /// <summary>
        /// Set the Test User
        /// </summary>
        /// <param name="expectedHttpStatusCode"></param>
        protected override void ModifyTestUser(HttpStatusCode expectedHttpStatusCode)
        {            
            if (expectedHttpStatusCode != HttpStatusCode.Forbidden)
            {
                // Create a default system user wtih access to the service
                TestUser.UserClaims = new List<Claim>
                {                                      
                };
            }
            else
            {
                TestUser.UserClaims = new List<Claim>
                {
                };
            }
        }     
      
        #endregion

        #region Public methods

        [Theory]     
        [InlineData(HttpStatusCode.Unauthorized, "/v1/authtest/auth")]
        [InlineData(HttpStatusCode.OK, "/v1/authtest/auth")] // By expecting Ok the FakePolicyEvaluator will take care to authenticate the test user
        public async Task AuthTest(HttpStatusCode expectedHttpStatusCode, string url)
        {            
            IAZI.Common.Test.IntegrationAndComponents.Models.TestUser.GetInstance().DisableAuthorization = true;

             // Arrange 
            url = InitTestUserAndUrl(expectedHttpStatusCode, url, new Dictionary<string, object>
            {                
            }); 

            // Act      
            var client =  GetHttpClientForSUT();    
            var response = await client.GetAsync(url);

            // Assert
            var responseData = await HandleUrlCallResponse<string>(response, expectedHttpStatusCode); 
        }   

        [Theory]     
        [InlineData(HttpStatusCode.OK, "/v1/authtest/authanonmyous")]
        public async Task AuthTestAnonymous(HttpStatusCode expectedHttpStatusCode, string url)
        {            
             // Arrange 
            url = InitTestUserAndUrl(expectedHttpStatusCode, url, new Dictionary<string, object>
            {                
            }); 

            // Act            
            var response = await GetHttpClientForSUT().GetAsync(url);

            // Assert
            var responseData = await HandleUrlCallResponse<string>(response, expectedHttpStatusCode);
            responseData.Should().Be("\"Ok\"");
        }     

                  

        #endregion
    }
}
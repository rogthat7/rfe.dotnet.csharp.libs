using System;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Test.IntegrationAndComponents.Shared;
using Microsoft.Extensions.Logging;
using Xunit.Abstractions;
using IAZI.Common.Test.Utils.Logging;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Utils;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public abstract class TestServerBase<T> where T: RootStartupBase
    {
        #region Properties

        protected readonly TestWebApplicationFactoryBase<T> Factory;

        protected readonly ILogger<TestServerBase<T>> Logger;

        protected static JsonOptions JsonOptions = new JsonOptions();
        
        #endregion
        
        #region Constructor

        public TestServerBase(ITestOutputHelper testOutputHelper, TestWebApplicationFactoryBase<T> factory)
        {
            Factory = factory;                          
            if (testOutputHelper != null)
            {
                Logger = testOutputHelper.CreateLogger<TestServerBase<T>>();
            }
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;         
        }
            
        #endregion        
    }
}
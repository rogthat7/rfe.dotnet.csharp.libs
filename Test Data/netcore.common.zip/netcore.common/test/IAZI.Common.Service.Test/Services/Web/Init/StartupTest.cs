using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using FluentAssertions;
using IAZI.Common.Core.Interfaces.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Test.Services.Web.Models;
using IAZI.Common.Service.Web.Init;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Xunit;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class StartupTest
    {
        #region Private methods

        #endregion

        #region Constructor

        public StartupTest()
        {                     
        }
            
        #endregion
        
        #region Public methods

        [Fact]
        public async Task RunTestServerUsingServiceStartup()
        {
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
            using(var bootstrapper = Bootstrapper.GetInstance())
            using(var webHost = bootstrapper.Features.Init<ServiceStartup>())
            {
                webHost.Should().NotBeNull();
                var serviceOptions = webHost.Services.GetRequiredService<IOptions<ServiceOptions>>();
                serviceOptions.Should().NotBeNull();
                serviceOptions.Value.Should().NotBeNull();                               
                serviceOptions.Value.Logging.Should().NotBeNull();
                serviceOptions.Value.Culture.Should().NotBeNull();
                serviceOptions.Value.Security.Should().NotBeNull();
                serviceOptions.Value.Security.Certificate.Should().NotBeNull();
                serviceOptions.Value.Security.CSPExcludedEndpoints.Should().HaveCount(1);
                serviceOptions.Value.Json.UseJsonStringEnumConverter.Should().BeFalse();
                Bootstrapper.GetInstance().Features.ApplicationInfo.Should().NotBeNull(); 
                
                await webHost.StopAsync();
            } 
        }

        [Fact]
        public async Task RunTestServerUsingServiceStartupWithoutSecurityAndDataProtection()
        {
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
            using(var bootstrapper = Bootstrapper.GetInstance())
            {
                bootstrapper.Features.AdditionalJsonConfigFileAction = config => { config.AddJsonFile("appsettings.withoutsecurity.json", optional: false, reloadOnChange: false); };            
                using(var webHost = bootstrapper.Features.Init<ServiceStartup>())
                {
                    webHost.Should().NotBeNull();
                    var serviceOptions = webHost.Services.GetRequiredService<IOptions<ServiceOptions>>();
                    serviceOptions.Should().NotBeNull();
                    serviceOptions.Value.Should().NotBeNull();                               
                    serviceOptions.Value.Security.Should().NotBeNull();
                    serviceOptions.Value.Security.InitDataProtection.Should().BeFalse();
                    serviceOptions.Value.Security.ServerAuthMode.Should().Be(ServerAuthModes.None);
                    Bootstrapper.GetInstance().Features.ApplicationInfo.Should().NotBeNull(); 
                    
                    await webHost.StopAsync();
                } 
            }            
        }

        [Fact]
        public async Task RunTestServerUsingWebStartup()
        {           
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
            using(var bootstrapper = Bootstrapper.GetInstance())
            using(var webHost = bootstrapper.Features.Init<WebStartup>())
            {
                webHost.Should().NotBeNull();
                TestServiceConfiguration(webHost);
                await webHost.StopAsync();
            }            
        }

        [Fact]
        public void RunTestServer()
        {           
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
                
            using(var bootstrapper = Bootstrapper.GetInstance())
            {
                bootstrapper.Features.ShutDownAfterFiveSecondsForTesting = true;
                var webHost = bootstrapper.Features.Run<WebStartup>();
                webHost.Should().Be(0);                     
            }                    
        }

        [Fact]
        public async Task RunTestServerUsingCustomWebStartup()
        {           
            EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid = true;
            using(var bootstrapper = Bootstrapper.GetInstance())
            using(var webHost = bootstrapper.Features.Init<CustomWebStartup>())
            {                
                webHost.Should().NotBeNull();
                TestServiceConfiguration(webHost);
                
                var serviceOptions = webHost.Services.GetRequiredService<IOptions<ServiceOptions>>();               
                serviceOptions.Should().NotBeNull();
                
                var myCustomServiceConfiguration = webHost.Services.GetRequiredService<IOptions<MyCustomOptions>>();               
                myCustomServiceConfiguration.Should().NotBeNull();
                myCustomServiceConfiguration.Value.CustomParamString.Should().BeEquivalentTo("test");
                myCustomServiceConfiguration.Value.CustomParamInt.Should().Be(2);
                myCustomServiceConfiguration.Value.CustomParamBool.Should().BeTrue();                

                var customServiceConfiguration = webHost.Services.GetRequiredService<IOptions<CustomServiceOptions<MyCustomOptions>>>();               
                customServiceConfiguration.Should().NotBeNull();
                customServiceConfiguration.Value.Custom.Should().NotBeNull();
                customServiceConfiguration.Value.Custom.CustomParamString.Should().BeEquivalentTo("test");
                customServiceConfiguration.Value.Custom.CustomParamInt.Should().Be(2);
                customServiceConfiguration.Value.Custom.CustomParamBool.Should().BeTrue();                
            
                await webHost.StopAsync();                
            }            
        }

        private void TestServiceConfiguration(IHost webHost)
        {
            if (webHost is null)
            {
                throw new ArgumentNullException(nameof(webHost));
            }            
            var serviceOptions = webHost.Services.GetRequiredService<IOptions<ServiceOptions>>();
                serviceOptions.Should().NotBeNull();
                serviceOptions.Value.Should().NotBeNull();
                serviceOptions.Value.BasePath.Should().BeEquivalentTo("/api/sharedlib");
                serviceOptions.Value.Environment.Should().BeEquivalentTo(DeployEnvironment.DEV);
                serviceOptions.Value.UseAutomapper.Should().BeTrue();
                serviceOptions.Value.Swagger.Should().NotBeNull();
                serviceOptions.Value.Swagger.UseSwaggerUI.Should().BeFalse();
                serviceOptions.Value.Swagger.UseSwaggerUIAuth.Should().BeFalse();
                serviceOptions.Value.Swagger.SwaggerUIIndexStream.Should().BeEquivalentTo("swagger");
                serviceOptions.Value.Swagger.UseInlineDefinitionsForEnums.Should().BeFalse();                               
                serviceOptions.Value.Security.Should().NotBeNull();
                serviceOptions.Value.Security.CorsOrigins.Should().BeEquivalentTo("https://dev.iazi.ch,https://devmy2.iazi.ch,https://devweb.iazi.ch,https://devmy.iazi.ch,https://devapp.iazi.ch");
                serviceOptions.Value.Security.ApiName.Should().BeEquivalentTo("IAZI.Service.Template");
                serviceOptions.Value.Security.AppName.Should().BeEquivalentTo("template");
                serviceOptions.Value.Security.ApiSecret.Should().BeEquivalentTo("secret");
                serviceOptions.Value.Security.ServerAuthMode.Should().BeEquivalentTo(ServerAuthModes.Both);
                serviceOptions.Value.Security.TokenIssuerV1.Should().BeEquivalentTo("https://iazi.eu.auth0.com/");
                serviceOptions.Value.Security.TokenIssuerV2.Should().BeEquivalentTo("https://www.iazi.ch/dev");
                serviceOptions.Value.Security.LegacyAudienceClientId.Should().BeEquivalentTo("iJbqXTj9oETMZZWW7q6cRCygNQ4VC0oU");
                serviceOptions.Value.Security.LegacyClientSecret.Should().BeEquivalentTo("Fw5E0kHY6O2XpQD4dkbXRuWctHNYYTkmwUdIDxSI9soD4X9yZOzm6Hgt8iXCRrEp");
                serviceOptions.Value.Security.InitDataProtection.Should().BeFalse();
                serviceOptions.Value.Security.DataProtectionFolder.Should().BeEquivalentTo("myDataProtectionFolder");
                serviceOptions.Value.Security.DataProtectionKeyLifeTimeInDays.Should().Be(999);
                serviceOptions.Value.Security.RequireHttpsMetadata.Should().BeFalse();
                serviceOptions.Value.Security.AuthTokenClass.Should().BeEquivalentTo("IAZI.Common.Service.Test.Services.Web.Init.AuthTestData, IAZI.Common.Service.Test");
                serviceOptions.Value.Security.CSPExcludedEndpoints.Should().HaveCount(1);
                serviceOptions.Value.Security.Certificate.Should().NotBeNull();
                serviceOptions.Value.Security.Certificate.UsedCertMode.Should().BeEquivalentTo(SecurityCertificateOptions.CertMode.None);
                serviceOptions.Value.Security.Certificate.PathKey.Should().BeEquivalentTo("/certs/tls.key");
                serviceOptions.Value.Security.Certificate.PathCrt.Should().BeEquivalentTo("/certs/tls.crt");
                serviceOptions.Value.Security.Certificate.PathPfx.Should().BeEquivalentTo("myPathPFX");
                serviceOptions.Value.Security.Certificate.PfxSecret.Should().BeEquivalentTo("secret");
                serviceOptions.Value.Security.Certificate.StoreCertThumbprint.Should().BeEquivalentTo("12345");
                serviceOptions.Value.Security.Certificate.StoreCertLocation.Should().BeEquivalentTo(StoreLocation.CurrentUser);
                serviceOptions.Value.Security.Certificate.UseServerCertificateForSecuredKestrel.Should().BeTrue();                
                serviceOptions.Value.Security.ServiceInternalIPWhitelist.Should().HaveCount(3);
                serviceOptions.Value.Culture.Should().NotBeNull();
                serviceOptions.Value.Culture.ResourceClass.Should().BeEquivalentTo("IAZI.Common.Service.Test.Services.Web.Init.MyResourceClass, IAZI.Common.Service.Test");
                serviceOptions.Value.Culture.Default.Should().BeEquivalentTo("it-CH");
                serviceOptions.Value.Culture.DefaultUI.Should().BeEquivalentTo("it-CH");
                serviceOptions.Value.Culture.SupportedCultures.Should().HaveCount(2);
                serviceOptions.Value.Logging.Should().NotBeNull();
                serviceOptions.Value.Logging.UseSerilogRequestLoggging.Should().BeFalse();
                serviceOptions.Value.Logging.UseSerilogUserInfoLogging.Should().BeFalse();
                serviceOptions.Value.Logging.ShowPII.Should().BeTrue();
                serviceOptions.Value.Json.Should().NotBeNull();
                serviceOptions.Value.Json.AllowTrailingCommas.Should().BeTrue();
                serviceOptions.Value.Json.IgnoreNullValues.Should().BeFalse();
                serviceOptions.Value.Json.IgnoreReadOnlyProperties.Should().BeTrue();
                serviceOptions.Value.Json.PropertyNameCaseInsensitive.Should().BeFalse();
                serviceOptions.Value.Json.UsePropertyNamingPolicyCamelCase.Should().BeFalse();
                serviceOptions.Value.Json.WriteIndented.Should().BeTrue();
                serviceOptions.Value.Json.UseJsonStringEnumConverter.Should().BeFalse();
                serviceOptions.Value.Json.UseRelaxedEncoding.Should().BeFalse();
                serviceOptions.Value.Data.Should().NotBeNull();
                serviceOptions.Value.Data.ConnectionStrings.Should().NotBeNull();
                serviceOptions.Value.Data.ConnectionStrings.Keys.Count.Should().Be(2);

                serviceOptions.Value.Analytics.Should().NotBeNull();

                serviceOptions.Value.RateLimiting.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.EnableLegacy.Should().BeTrue();
                serviceOptions.Value.RateLimiting.LegacyThrottling.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.LegacyThrottling.whiteListClients.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.LegacyThrottling.clientRateLimiting.Should().NotBeNull();

                serviceOptions.Value.RateLimiting.Enable.Should().BeTrue();
                serviceOptions.Value.RateLimiting.IpRateLimiting.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.IpRateLimitPolicies.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.ClientRateLimiting.Should().NotBeNull();
                serviceOptions.Value.RateLimiting.ClientRateLimitPolicies.Should().NotBeNull();

                serviceOptions.Value.Interfaces.Should().NotBeNull();
                serviceOptions.Value.Interfaces.Count.Should().Be(5);
                var qlikSense = serviceOptions.Value.GetServiceInterface("Service.AuthQlikSense");
                qlikSense.Should().NotBeNull();
                qlikSense.Name.Should().Be("IAZI.Service.AuthQlikSense");
                qlikSense.BaseUrl.Should().Be("https://dev.iazi.ch/api/authqliksense");
                qlikSense.AuthMode.Should().Be(ClientAuthModes.LegacyAuth);
                qlikSense.LegacyAuthMode.Should().Be(LegacyAuthModes.Credentials);
                qlikSense.LegacyAuthUserName.Should().Be("authUser");
                qlikSense.LegacyAuthPassword.Should().Be("secret");
                qlikSense.AuthAppName.Should().Be("qliksense");
    
                Bootstrapper.GetInstance().Features.ApplicationInfo.Should().NotBeNull(); 
                Bootstrapper.GetInstance().Features.ApplicationInfo.ServerAddressList.Should().NotBeNull();                

                var webApplicationConfiguration = webHost.Services.GetRequiredService<IOptions<WebApplicationOptions>>();
                webApplicationConfiguration.Should().NotBeNull();
                webApplicationConfiguration.Value.Should().NotBeNull();
                webApplicationConfiguration.Value.ErrorPage.Should().Equals("/errorPageTest");
        }

        [Fact]
        public async Task RunTestServerUsingLeanServiceStartup()
        {  
            using(var bootstrapper = Bootstrapper.GetInstance())
            using(var webHost = bootstrapper.Features.Init<LeanServiceStartup>())
            {
                webHost.Should().NotBeNull();
                await webHost.StopAsync();
            }  
        }        
            
        #endregion
    }

    public class AuthTestData : IAuthBase
    {        
    }

    public class MyResourceClass
    {        
    }
}
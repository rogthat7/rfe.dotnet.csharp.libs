using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class TestWebStartup : CustomWebStartup
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="env"></param>
        public TestWebStartup(IConfiguration configuration, IWebHostEnvironment env)
            : base(configuration, env)
        {
        }

        #endregion
    }
}
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Utils;
using IAZI.Common.Test.Utils.Logging;
using Microsoft.Extensions.Logging;
using Xunit;
using Xunit.Abstractions;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class TestWebServer : TestServerBase<TestWebStartup>, IClassFixture<WebTestWebApplicationFactory>
    {
        #region Properties
        
        #endregion        
      
        #region Constructor

        public TestWebServer(ITestOutputHelper testOutputHelper, WebTestWebApplicationFactory factory)
        : base(testOutputHelper, factory)
        {                 
        }
                        
        #endregion

        #region Public methods
              

        #endregion
    }
}
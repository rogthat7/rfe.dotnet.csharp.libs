using IAZI.Common.Service.Web.Init;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class CustomBootstrapperFeatures : BootstrapperFeatures
    {
        
    }
}
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class TestServiceStartup : CustomServiceStartup
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="env"></param>
        public TestServiceStartup(IConfiguration configuration, IWebHostEnvironment env)
            : base(configuration, env)
        {
        }

        #endregion
    }
}
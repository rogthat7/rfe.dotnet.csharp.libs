using System.Net;
using System.Threading.Tasks;
using FluentAssertions;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Service.Utils;
using Microsoft.Extensions.Logging;
using Xunit;
using Xunit.Abstractions;
using Microsoft.OpenApi.Readers;
using IAZI.Common.Service.Web.Models;
using System.Net.Http.Headers;
using IAZI.Common.Core.Models.Web.Options;
using System.Net.Http;
using StackExchange.Redis.Extensions.Core.Models;
using System.Collections.Generic;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class TestServiceServer : TestServerBase<TestServiceStartup>, IClassFixture<ServiceTestWebApplicationFactory>
    {
        #region Properties       
        
        #endregion
        
        #region Constructor

        public TestServiceServer(ITestOutputHelper testOutputHelper, ServiceTestWebApplicationFactory factory)
        : base(testOutputHelper, factory)
        {                 
        }
            
        #endregion

        #region Public methods

        [Fact]
        public async Task TestService()
        {                                 
            var jsonFacade = Factory.GetService<IJsonFacade>();
            var client = Factory.CreateClient();
            var response = await client.GetAsync("/");
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
                        
            var content = await response.Content.ReadAsAsync<IndexResponseDto>(jsonFacade, JsonOptions);                    
            content.Should().NotBeNull();  
            content.Database.Should().BeEmpty(); // check removed internal detail 
            content.Version.Should().NotBeEmpty();   
        }  

        [Theory]
        [InlineData(HttpStatusCode.BadRequest)]
        [InlineData(HttpStatusCode.Unauthorized)] 
        [InlineData(HttpStatusCode.Forbidden)]
        [InlineData(HttpStatusCode.NotFound)] 
        [InlineData(HttpStatusCode.InternalServerError)]        
        [InlineData(HttpStatusCode.BadRequest, "500custom")] 
        [InlineData(HttpStatusCode.BadRequest, "500custom2")] 
        public async Task TestProblemDetailsSetup(HttpStatusCode httpStatusCode, string endpoint = null)
        {
            var jsonFacade = Factory.GetService<IJsonFacade>();
            var client = Factory.CreateClient();

            string endpointStr = null;
            if (endpoint == null)
            {
                endpointStr = ((int)httpStatusCode).ToString();
            }
            else
            {
                endpointStr = endpoint;
            }
            var response = await client.GetAsync("/v1/testproblemdetails/"+ endpointStr);
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(httpStatusCode);
            response.Content.Headers.ContentType.MediaType.Should().Be("application/problem+json");
            var content = await response.Content.ReadAsAsync<ProblemDetailsDto>(jsonFacade, JsonOptions);            
            content.Should().NotBeNull();  
            Logger.LogDebug(jsonFacade.Serialize<ProblemDetailsDto>(content, JsonOptions));
            content.Status.Should().NotBeNull();
            content.Status.Should().Be((int)httpStatusCode);
            content.Title.Should().NotBeNull();
            content.Type.Should().NotBeNull();   

            // specific checks
            if (endpoint != null)       
            {
                if (endpoint == "500custom")
                {
                    content.Detail.Should().NotBeNull();
                }
                else if (endpoint == "500custom2")
                {
                    content.Detail.Should().BeNull();
                }
            }
        }    

       [Fact]
        public async Task TestSwagger()
        {
            var jsonFacade = Factory.GetService<IJsonFacade>();
            var client = Factory.CreateClient();           
            var response = await client.GetAsync("/api/sharedlib/swagger/v1/swagger.json");
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var content = await response.Content.ReadAsStringAsync();    
            content.Should().NotBeEmpty();
            var reader = new OpenApiStringReader(new OpenApiReaderSettings()
            {
            });
            var doc = reader.Read(content, out var diagnostic);

            doc.Should().NotBeNull();
            doc.Paths.Should().NotBeNull();
          
            // Some hidden actions
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/3");
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/4");
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/5");
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/6");
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/7");
            doc.Paths.Keys.Should().NotContain("/v1/internalonlytest/8");            

            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestResponseDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestRequestDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestResponseActionResultDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestResponseActionResultNestedDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestResponseActionResultNestedChildDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestResponseActionResultNestedChildLevel2Dto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestCollectionParentGetResponseDto");
            doc.Components.Schemas.Keys.Should().NotContain("InternalOnlyTestCollectionGetResponseDto");
            doc.Components.Schemas.Keys.Should().NotContain("TestDto");
       }  

        [Fact]
        public async Task TestCSPViolationReportEndpoint()
        {                                 
            var client = Factory.CreateClient();
            var content = new StringContent(@"
                {""csp-report"": {
                    ""document-uri"": ""http://example.com/signup.html"",
                    ""referrer"": """",
                    ""blocked-uri"": ""http://example.com/css/style.css"",
                    ""violated-directive"": ""style-src cdn.example.com"",
                    ""original-policy"": ""default-src 'none'; style-src cdn.example.com; report-uri /_/csp-reports"",
                    ""disposition"": ""report""
                }}");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync(SecurityOptions.CSPViolationReportUrl, content);
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(HttpStatusCode.OK);           
        }  

        [Fact(Skip = "Requires setup of Redis, please ensure your IP is set in the Whitelist")]
        [Trait("Category", "ExcludeTeamCity")]            
        public async Task TestRedisMiddlewareEndpoints()
        {
            var jsonFacade = Factory.GetService<IJsonFacade>();
            var client = Factory.CreateClient();
            var response = await client.GetAsync("/redis/connectionInfo");
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(HttpStatusCode.OK); 
            var data = await response.Content.ReadAsAsync<ConnectionPoolInformation>(jsonFacade, JsonOptions).ConfigureAwait(false);
            data.Should().NotBeNull();   

            response = await client.GetAsync("/redis/info");
            response.Should().NotBeNull();
            response.StatusCode.Should().Be(HttpStatusCode.OK); 
            var data2 = await response.Content.ReadAsAsync<Dictionary<string, string>>(jsonFacade, JsonOptions).ConfigureAwait(false);
            data2.Should().NotBeNull();    
        }   
        
        #endregion
    }
}
using System;
using IAZI.Common.Service.Test.Mocks;
using IAZI.Common.Service.Test.Services.Web.Controllers.V1;
using IAZI.Common.Service.Test.Services.Web.Models;
using IAZI.Common.Service.Web.Init;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class CustomServiceStartup : ServiceStartup
    {
        public CustomServiceStartup(IConfiguration configuration, IWebHostEnvironment env) : base(configuration, env)
        {
        }

        protected override void InitIoC(IServiceCollection services)
        {
            base.InitIoC(services);

            services.AddSingleton<IHttpContextAccessor>(provider =>
            {                
                return HttpContextAccessorMock.CreateMock();
            });  
        }

        protected override void InitOptions(IServiceCollection services)
        {
            base.InitOptions(services);

            base.InitCustomOptions<MyCustomOptions>(services, MyCustomOptions.ValidateSettings, (services, options) => { return; }, (services, options) => { return; });
        }

        protected override IMvcBuilder InitMVC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            var mvcBuilder = base.InitMVC(services);
            
            mvcBuilder.AddApplicationPart(typeof(TestProblemDetailsController).Assembly);         
            
            return mvcBuilder;
        }
    }
}
using IAZI.Common.Test.IntegrationAndComponents.Shared;

namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class WebTestWebApplicationFactory : TestWebApplicationFactoryBase<TestWebStartup>
    {
        #region Constructor

        public WebTestWebApplicationFactory() : base(overrideContentRootPathUseCurrentDirectory: true)
        {
        }
            
        #endregion              
    }
}
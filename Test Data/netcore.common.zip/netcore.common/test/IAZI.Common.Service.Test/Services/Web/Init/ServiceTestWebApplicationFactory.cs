using IAZI.Common.Test.IntegrationAndComponents.Shared;
namespace IAZI.Common.Service.Test.Services.Web.Init
{
    public class ServiceTestWebApplicationFactory : TestWebApplicationFactoryBase<TestServiceStartup>
    {
        #region Constructor

        public ServiceTestWebApplicationFactory() : base(overrideContentRootPathUseCurrentDirectory: true)
        {
        }
            
        #endregion 
    }
}
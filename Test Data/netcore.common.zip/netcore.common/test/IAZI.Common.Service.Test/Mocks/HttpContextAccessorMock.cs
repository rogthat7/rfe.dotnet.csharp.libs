using System;
using System.Collections.Generic;
using System.Net;
using IAZI.Common.Service.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Moq;

namespace IAZI.Common.Service.Test.Mocks
{
    public class HttpContextAccessorMock
    {
        private static string DummyIpAddress = "192.1.1.1";
        
        public static IHttpContextAccessor CreateMock(string dummyIpAddress = null)
        {
            if (string.IsNullOrEmpty(dummyIpAddress))
            {
                dummyIpAddress = DummyIpAddress;
            }

            var mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            
            var context = new DefaultHttpContext
            {
                RequestServices = ServiceProviderMock.CreateMock()
            };
           
            context.Request.Headers[HttpContextExtensions.RequestClientIPkey] = dummyIpAddress;

            mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(context);            

            mockHttpContextAccessor.Setup(_ => _.HttpContext.Connection.RemoteIpAddress).Returns(IPAddress.Parse(DummyIpAddress));

            mockHttpContextAccessor.Setup(_ => _.HttpContext.Request.Path).Returns("/api/test");

            mockHttpContextAccessor.Setup(_ => _.HttpContext.Request.Headers).Returns(new HeaderDictionary(new Dictionary<String, StringValues>
                                                                            {
                                                                                { "dummyHeaderKey", "dummyHeaderValue"}
                                                                            }) as IHeaderDictionary);           
            return mockHttpContextAccessor.Object;
        }
    }
}
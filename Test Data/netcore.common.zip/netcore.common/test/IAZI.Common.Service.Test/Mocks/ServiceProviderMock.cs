using System;
using Microsoft.AspNetCore.Authentication;
using Moq;

namespace IAZI.Common.Service.Test.Mocks
{
    public class ServiceProviderMock
    {
        public static IServiceProvider CreateMock()
        {
            var serviceProviderMock = new Mock<IServiceProvider>();
            return serviceProviderMock.Object;
        }
    }
}
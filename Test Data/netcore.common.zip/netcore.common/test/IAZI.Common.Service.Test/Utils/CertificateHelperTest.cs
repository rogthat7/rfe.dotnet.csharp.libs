using System.Security.Cryptography.X509Certificates;
using Xunit;

namespace IAZI.Common.Service.Utils.Test
{
    public class CertificateHelperTest
    {
         [Fact(Skip = "Requires setup of certificate")]
         [Trait("Category", "ExcludeTeamCity")]
         public void LookUpCertificateInWindowsCertStore()
         {
             var cert = CertificateHelper.LookUpCertificateInCertStore("28ad9b2a3cc33bacffde75e00d27ae26d50cbbeb", StoreLocation.CurrentUser);
             Assert.NotNull(cert);
         }

        [Theory]
        [InlineData("‎28 ad 9b 2a 3c c3 3b ac ff de 75 e0 0d 27 ae 26 d5 0c bb eb", "28ad9b2a3cc33bacffde75e00d27ae26d50cbbeb")]
        public void SafelyConvertCertThumbprint(string certThumbprint, string expectedThumbprint)
        {            
            Assert.Equal(CertificateHelper.SafelyConvertCertThumbprint(certThumbprint), expectedThumbprint);
        }

        [Fact(Skip = "Requires setup of certificate")]  
        [Trait("Category", "ExcludeTeamCity")]
        public void LoadCertificateFromFile()
        {
            const string certPath = @"T:\TBU\Certs\IdentityServer\identityserver_iazi_local.crt";
            const string keyPath = @"T:\TBU\Certs\IdentityServer\identityserver_iazi_local.key";
            Assert.NotNull(CertificateHelper.LoadCertificateFromFiles(certPath, keyPath));
        }

        [Fact]
        public void CreateCertFromString()
        {
            const string cert = "MIIC5jCCAc6gAwIBAgIQOWI8IQVvUZJE4sYANDWs8TANBgkqhkiG9w0BAQsFADAvMS0wKwYDVQQDEyRBREZTIFNpZ25pbmcgLSBhZGZzLmltbW9pbmZvdGVjaC5jb20wHhcNMTkwMjE4MTI1MjQ2WhcNMjAwMjE4MTI1MjQ2WjAvMS0wKwYDVQQDEyRBREZTIFNpZ25pbmcgLSBhZGZzLmltbW9pbmZvdGVjaC5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC7pVbSl1FhGky8u+vUj/Xp3HSpH1e1Q8dhzg/dt9R1iNzhvV92nwATYSS/IGFlkaz/XPYZDG3tXcTulzRZTLBsAVy3GI8bO8Zlh/Ql+DxYOA3/v1r3b7RyGPPqUJ/Z0tRaK6e7Q8Yb8fGzopGN+WJZUGhA96zJFApulKCzdzMfyOguVjQaVB8j8gA0K96MuIfhtTB3TsCQ4TlVoszv+upK9/ZXE4P06UQxFGlYbIQ8kzUWmFFLpSESbWwi0FBzooUUCM6cBDPl4UQD6uS+fQbcffz6GQcy+P6qF84k7wUA561b8YC3oVFh7ybTyjEVO17lS2Dioti2GG7es++06o4BAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAD6Ok5LAGSMP8hS1S2hMwYry1AA1wBrydsCXpHpR6LHBmVdR7FwxP3DtJyXkVnLq6Lh13upI9e72JHeLjGE7a5KeKQhfkHQRhqcMvCag6Z6nuT23m7Ozkne87cnLL9xRA3JJyitZ030xHC/typ/eB7DQolpCLkkRkMt6Taxawbv3tNVkGouepp2uNnTVIOUZWyNIQKimWF28YRSHVBk2BMtEt0b0jjB6Q/irk54Kb+Rbg2JQ+/y/FDB5M+X791AxpgrGAUayzDv0on0SIgErJlX6k2AuN3wN+brvJti9ZTiJfjNTA605PjMvQEan60rJnKunZiOON/bDmOXE6ERWoFY=";
             Assert.NotNull(CertificateHelper.CreateCertFromString(cert));
        }

    }
}
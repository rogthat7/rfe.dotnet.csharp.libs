using System.Collections.Generic;
using System.Threading;
using IAZI.Common.Core.Infrastructure.Interfaces.Data.Concurrency;

namespace IAZI.Common.Infrastructure.Data.Concurrency
{   
    /// <summary>
    /// https://stackoverflow.com/questions/3039724/blockingcollectiont-performance/29269149#29269149
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class FastConcurrentDictionary<T, TU> : IFastConcurrentDictionary<T, TU>
    {
        private SpinLock _lock = new SpinLock(false);
        private Dictionary<T, TU> _collection = new Dictionary<T, TU>();

        public void AddOrUpdate(T key, TU value)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                if (_collection.ContainsKey(key))
                {
                    _collection[key] = value;
                }
                else
                {
                    _collection.Add(key, value);                
                }                
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }   

        public void Remove(T key)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                if (_collection.ContainsKey(key))
                {
                    _collection.Remove(key);
                }            
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }       

        public bool TryGetValue(T key, out TU result)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _collection.TryGetValue(key, out result);                
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }            
        }

        public TU GetValue(T key)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _collection[key];
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }            
        }

        public bool ContainsKey(T key)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _collection.ContainsKey(key);
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }            
        }

        public void Clear()
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                _collection.Clear();
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }

        public int Count()
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _collection.Count;
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }

        public bool IsEmpty()
        {
            return Count() == 0;
        }       
    }
}
using System.Collections.Generic;
using System.Threading;
using IAZI.Common.Core.Infrastructure.Interfaces.Data.Concurrency;

namespace IAZI.Common.Infrastructure.Data.Concurrency
{
    /// <summary>
    /// https://stackoverflow.com/questions/3039724/blockingcollectiont-performance/29269149#29269149
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class BlockingColleFastConcurrentQueue<T> : IFastConcurrentQueue<T>
    {
        private SpinLock _lock = new SpinLock(false);
        private Queue<T> _queue = new Queue<T>();

        public void Add(T item)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                _queue.Enqueue(item);
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }

        public bool TryPeek(out T result)
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                if (_queue.Count > 0)
                {
                    result = _queue.Peek();
                    return true;
                }
                else
                {
                    result = default(T);
                    return false;
                }
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }

        public T Take(int maxTicks = 0)
        {
            var spin = new SpinWait();
            var ticks = 0;
            do
            {
                bool gotLock = false;
                try
                {
                    _lock.Enter(ref gotLock);
                    if (_queue.Count > 0)
                    {
                        var result = _queue.Dequeue();
                        if (result != null)
                        {
                            return result;                        
                        }  
                    }                                            
                }
                finally
                {
                    if (gotLock) _lock.Exit(false);
                }
                spin.SpinOnce();
                if (maxTicks > 0)
                {
                    ticks++;
                    if (ticks >= maxTicks)
                    {
                        break;
                    }
                }                
            } 
            while (true);

            return default(T);
        }

        public bool TryTake(out T result)
        {
            result = default(T);
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                if (_queue.Count > 0)
                {
                    result = _queue.Dequeue();
                    return true;
                }                   
                return false;                     
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }            
        }

        public int Count()
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _queue.Count;
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }
        }

        public bool IsEmpty()
        {
            return Count() == 0;
        }

        public IEnumerable<T> CreateSnapshot()
        {
            bool gotLock = false;
            try
            {
                _lock.Enter(ref gotLock);
                return _queue?.ToArray();
            }
            finally
            {
                if (gotLock) _lock.Exit(false);
            }            
        }
    }
}
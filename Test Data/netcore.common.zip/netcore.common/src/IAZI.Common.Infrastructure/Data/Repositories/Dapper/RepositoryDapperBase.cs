using System;
using System.Data;
using Dapper;
using System.Threading.Tasks;
using System.Collections.Generic;
using IAZI.Common.Core.Infrastructure.Interfaces.Data.Repositories.Dapper;
using IAZI.Common.Core.Models.Data.Repositories.Dapper;
using static Dapper.SqlMapper;
using IAZI.Common.Core.Models.Shared;

namespace IAZI.Common.Infrastructure.Data.Repositories.Dapper
{
    ///<summary>
    /// RepositoryDapperBase
    ///</summary>
    public abstract class RepositoryDapperBase
    {
        
        #region Constants

        protected const string UserTableTypeList = "ADM.dt_ListId";

        protected const string UserTableTypeList2 = "ADM.dt_ListId3";

        protected const string UserTableTypeAttributesIn = "ADM.dt_AttributesIn2";  

        protected const string UserTableTypeListIdExternalId = "ADM.dt_ListIdExternalId";
        
        #endregion
        
        #region Properties

        protected int? ReturnCode;
        protected string ReturnMessage = string.Empty;

        protected readonly IUnitOfWork UnitOfWork;
            
        #endregion
        
        #region Constructor

        ///<summary>
        /// Constructor
        ///</summary>
        public RepositoryDapperBase(IUnitOfWork unitOfWork)
        {                  
            UnitOfWork = unitOfWork;
        }
            
        #endregion

        #region Protected methods

        /// <summary>
        /// Creates default parameters incl. RequestBase parameters
        /// </summary>
        /// <param name="requestBase"></param>
        /// <returns></returns>
        protected DynamicParameters CreateDefaultParameters(RequestBase requestBase)
        {
            if (requestBase is null)
            {
                throw new ArgumentNullException(nameof(requestBase));
            }

            var parameters = CreateDefaultParameters();
            parameters.Add("@requestCustomerId", requestBase.RequestCustomerId, dbType: DbType.Int32);
            parameters.Add("@requestEmployeeId", requestBase.RequestUserId, dbType: DbType.Int32);
            parameters.Add("@requestCulture", requestBase.Culture, dbType: DbType.String, size: 5);
            return parameters;
        }

        /// <summary>
        /// Default parameters for Stored Procedure calls
        /// </summary>
        /// <returns></returns>
        protected virtual DynamicParameters CreateDefaultParameters()
        {
            var parameters = new DynamicParameters();
            parameters.Add("@returnCode", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@returnMessage", dbType: DbType.String, size:int.MaxValue, direction: ParameterDirection.Output);
            return parameters;
        }

        protected virtual async Task<ResponseContainer<IEnumerable<T>>> ExecuteStoredProcedureListResult<T>(string storedProcedureName, DynamicParameters parameters) where T: class
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentNullException(nameof(storedProcedureName));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            var commandDefinition = new CommandDefinition(storedProcedureName, parameters, commandType: CommandType.StoredProcedure);
            
            return await ExecuteStoredProcedureListResult<T>(commandDefinition);
        }

        protected virtual async Task<ResponseContainer<IEnumerable<T>>> ExecuteStoredProcedureListResult<T>(CommandDefinition commandDefinition) where T: class
        {
            if (commandDefinition.Equals(default(CommandDefinition)))            
            {
                throw new ArgumentNullException(nameof(commandDefinition));
            }
            
            var response = await UnitOfWork.DbConnection.QueryAsync<T>(commandDefinition);
            
            return CreateResponseContainer<IEnumerable<T>>(response, commandDefinition.Parameters as DynamicParameters);            
        }


        protected virtual async Task<ResponseContainer<T>> ExecuteStoredProcedureCreateResult<T>(string storedProcedureName, DynamicParameters parameters) where T: CreateResponseBase
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentNullException(nameof(storedProcedureName));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            var commandDefinition = new CommandDefinition(storedProcedureName, parameters, commandType: CommandType.StoredProcedure);
            
            return await ExecuteStoredProcedureCreateResult<T>(commandDefinition);
        }

        protected virtual async Task<ResponseContainer<T>> ExecuteStoredProcedureCreateResult<T>(CommandDefinition commandDefinition) where T: CreateResponseBase
        {
            if (commandDefinition.Equals(default(CommandDefinition)))            
            {
                throw new ArgumentNullException(nameof(commandDefinition));
            }
            
            var response = Activator.CreateInstance<T>();
            response.CreatedEntityId = await UnitOfWork.DbConnection.ExecuteScalarAsync<int>(commandDefinition);            
            
            return CreateResponseContainer<T>(response, commandDefinition.Parameters as DynamicParameters);            
        }

        protected virtual async Task<ResponseContainer<T>> ExecuteStoredProcedureUpdateDeleteResult<T>(string storedProcedureName, DynamicParameters parameters) where T: UpdateDeleteResponseBase
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentNullException(nameof(storedProcedureName));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }
            
            var commandDefinition = new CommandDefinition(storedProcedureName, parameters, commandType: CommandType.StoredProcedure);
            
            return await ExecuteStoredProcedureUpdateDeleteResult<T>(commandDefinition);                         
        }

        protected virtual async Task<ResponseContainer<T>> ExecuteStoredProcedureUpdateDeleteResult<T>(CommandDefinition commandDefinition) where T: UpdateDeleteResponseBase
        {
            if (commandDefinition.Equals(default(CommandDefinition)))            
            {
                throw new ArgumentNullException(nameof(commandDefinition));
            }
            
            var response = Activator.CreateInstance<T>();
            response.RowsAffected = await UnitOfWork.DbConnection.ExecuteAsync(commandDefinition);
            
            return CreateResponseContainer<T>(response, commandDefinition.Parameters as DynamicParameters);            
        }

        /// <summary>
        /// Create a response container
        /// </summary>
        /// <typeparam name="T"></typeparam>
        protected virtual ResponseContainer<T> CreateResponseContainer<T>(T response, DynamicParameters parameters) where T: class
        {
            return new ResponseContainer<T>
            {
                Response = response,
                ReturnCode = parameters.Get<int?>("@returnCode"),
                ReturnMessage = parameters.Get<string>("@returnMessage")
            };
        }

        protected virtual async Task<GridReader> ExecuteStoredProcedureMultipleResult(string storedProcedureName, DynamicParameters parameters)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
            {
                throw new ArgumentNullException(nameof(storedProcedureName));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            var commandDefinition = new CommandDefinition(storedProcedureName, parameters, commandType: CommandType.StoredProcedure);
            
            return await ExecuteStoredProcedureMultipleResult(commandDefinition);
        }

        protected virtual async Task<GridReader> ExecuteStoredProcedureMultipleResult(CommandDefinition commandDefinition)
        {
            if (commandDefinition.Equals(default(CommandDefinition)))            
            {
                throw new ArgumentNullException(nameof(commandDefinition));
            }
            
            return await UnitOfWork.DbConnection.QueryMultipleAsync(commandDefinition);            
        }
            
        #endregion             
    }
}
using Microsoft.EntityFrameworkCore;

namespace IAZI.Common.Infrastructure.Data.Repositories.EF
{
    public abstract class RepositoryDbContextBase<T> where T: DbContext
    {
        #region Properties 

        protected readonly T Context;  

        #endregion
        
        #region Constructor

        public RepositoryDbContextBase(T context)
        {
            Context = context;
        }

        #endregion
    }
}
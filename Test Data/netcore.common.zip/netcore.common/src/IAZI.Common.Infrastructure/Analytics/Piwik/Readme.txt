This code is based on:
https://github.com/MichaelHeerklotz/piwik-dotnet-core-tracker


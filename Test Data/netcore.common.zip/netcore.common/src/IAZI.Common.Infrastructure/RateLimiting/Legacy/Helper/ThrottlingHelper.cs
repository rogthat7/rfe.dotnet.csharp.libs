﻿using IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy;
using System;

namespace IAZI.Common.Infrastructure.RateLimiting.Legacy.Helper
{
    public static class ThrottlingHelper
    {
        public static string ComputeCounterKey(string identityKey, ThrottlePolicy rule)
        {

            var key = string.Concat(rule.Period, "-", identityKey);

            var idBytes = System.Text.Encoding.UTF8.GetBytes(key);

            byte[] hashBytes;

            using (var algorithm = System.Security.Cryptography.SHA1.Create())
            {
                hashBytes = algorithm.ComputeHash(idBytes);
            }

            return BitConverter.ToString(hashBytes).Replace("-", string.Empty);
        }

        public static TimeSpan ConvertToTimeSpan(string timeSpan)
        {
            var l = timeSpan.Length - 1;
            var value = timeSpan.Substring(0, l);
            var type = timeSpan.Substring(l, 1);

            switch (type)
            {
                case "d": return TimeSpan.FromDays(double.Parse(value));
                case "h": return TimeSpan.FromHours(double.Parse(value));
                case "m": return TimeSpan.FromMinutes(double.Parse(value));
                case "s": return TimeSpan.FromSeconds(double.Parse(value));
                default: throw new FormatException(string.Format("{0} can't be converted to TimeSpan, unknown type {1}", timeSpan, type));
            }
        }
    }
}

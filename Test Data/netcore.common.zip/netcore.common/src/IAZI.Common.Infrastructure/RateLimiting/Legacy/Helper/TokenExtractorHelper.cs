﻿using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Infrastructure.RateLimiting.Legacy.Helper
{
    public static class TokenExtractorHelper
    {
        /// <summary>
        /// To get email id from request token key
        /// </summary>
        /// <param name="request">Http request object</param>
        /// <returns></returns>
        public static string GetEmail(this HttpRequest request)
        {
            try
            {
                var principal = request.HttpContext.User as ClaimsPrincipal;
                return principal.Claims.First(c => c.Type.Contains("emailaddress")).Value;
            }
            catch { return null; }
        }

        /// <summary>
        /// To get customer name from request token key
        /// </summary>
        /// <param name="request">Http request object</param>
        /// <returns></returns>
        public static string GetCustomerName(this HttpRequest request)
        {
            var principal = request.HttpContext.User as ClaimsPrincipal;
            if (principal.Claims.Any(c => c.Type == ("customerName")))
                return principal.Claims.First(c => c.Type.Contains("customerName")).Value;
            else
                return null;
        }

        /// <summary>
        /// To get user id from request token key
        /// </summary>
        /// <param name="request">Http request object</param>
        /// <returns></returns>
        public static string GetUserId(this HttpRequest request)
        {
            var principal = request.HttpContext.User as ClaimsPrincipal;
            if (principal.Claims.Any(c => c.Type == ("userId")))
                return principal.Claims.First(c => c.Type.Contains("userId")).Value;
            else
                return null;
        }

        /// <summary>
        /// To get customer id from request token key
        /// </summary>
        /// <param name="request">Http request object</param>
        /// <returns></returns>
        public static string GetCustomerId(this HttpRequest request)
        {
            var principal = request.HttpContext.User as ClaimsPrincipal;
            if (principal.Claims.Any(c => c.Type == ("customerId")))
                return principal.Claims.First(c => c.Type.Contains("customerId")).Value;
            else
                return null;
        }

    }
}

using Serilog;
using Serilog.Configuration;

namespace IAZI.Common.Infrastructure.Logging
{
    public static class OperationIdEnricherExtension
    {
        public static LoggerConfiguration WithOperationId(
            this LoggerEnrichmentConfiguration enrichmentConfiguration)
        {
            return enrichmentConfiguration.With<OperationIdEnricher>();
        }
    }
}
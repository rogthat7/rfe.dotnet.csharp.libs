using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Configuration;

namespace IAZI.Common.Infrastructure.Logging
{
    public static class EnvironmentLoggingEnricherExtension
    {
        public static LoggerConfiguration WithEnvironmentLogging(
            this LoggerEnrichmentConfiguration enrichmentConfiguration, IConfiguration configuration)
        {
            var envLogging = new EnvironmentLoggingEnricher(configuration);
            return enrichmentConfiguration.With(envLogging);
        }
    }
}
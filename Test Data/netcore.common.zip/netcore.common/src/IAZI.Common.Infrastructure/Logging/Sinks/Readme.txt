This code is based on:
https://github.com/serilog/serilog-sinks-console

Because at the times writing this, the console serilog sink was not that flexible to remove line breaks from
any message that was a requirement for the System-wide logging in Rancher.
Therefore the entire code had to be imported.

The only changed class is the "ThemedMessageTemplateRenderer.cs" and "ExceptionTokenRenderer.cs" (check comments there)
Besides, the namespace of the classes have been changed by using the prefix "IAZI."
using Serilog;
using Serilog.Configuration;

namespace IAZI.Common.Infrastructure.Logging
{
    public static class LogExceptionEnricherExtension
    {
        public static LoggerConfiguration WithEscapedException(
            this LoggerEnrichmentConfiguration enrichmentConfiguration)
        {
            return enrichmentConfiguration.With<LogExceptionEnricher>();
        }
    }
}
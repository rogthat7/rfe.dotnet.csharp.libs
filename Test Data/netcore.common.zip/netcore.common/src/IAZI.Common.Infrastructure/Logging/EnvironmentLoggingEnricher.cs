using IAZI.Common.Core.Interfaces.Services.Utils.Logging;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Configuration;
using Serilog.Core;
using Serilog.Events;

namespace IAZI.Common.Infrastructure.Logging
{
    public class EnvironmentLoggingEnricher : IEnvironmentLoggingEnricher
    {
        private const string Environment = "Environment";
        private readonly IConfiguration _configuration;

        public EnvironmentLoggingEnricher(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {           
            // ServiceOptions cannot be injected to logging middleware
            var env = _configuration[ServiceOptions.ConfigurationEnvironment];
            if (string.IsNullOrEmpty(env))
            {
                env = string.Empty;
            }
            var logEventProperty = propertyFactory.CreateProperty(Environment, env.ToUpperInvariant());
            logEvent.AddPropertyIfAbsent(logEventProperty);
        }   
    }
}
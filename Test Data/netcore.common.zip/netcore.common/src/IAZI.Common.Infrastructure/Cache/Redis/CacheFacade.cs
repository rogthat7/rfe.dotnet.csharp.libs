using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Infrastructure.Cache.Redis;
using StackExchange.Redis;
using StackExchange.Redis.Extensions.Core.Abstractions;

namespace IAZI.Common.Infrastructure.Cache.Redis
{
    /// <summary>
    /// Class to implement ICacheFacade which accesses e.g. Redis behind the scenes
    /// </summary>
    public class CacheFacade : ICacheFacade
    {
        #region Properties

        private readonly IRedisCacheClient _client;        
            
        #endregion

        #region Constructor

        public CacheFacade(IRedisCacheClient client)
        {
            _client = client;            
        }
            
        #endregion

        #region Public methods

        public async Task<bool> AddAllAsync<T>(IList<Tuple<string, T>> items, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().AddAllAsync<T>(items, When.Always, flag);
        }

        public async Task<bool> AddAsync<T>(string key, T value, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().AddAsync<T>(key, value, When.Always, flag);
        }
        
        public async Task<bool> ExistsAsync(string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().ExistsAsync(key, flag);
        }
        
        public async Task<IDictionary<string, T>> GetAllAsync<T>(IEnumerable<string> keys)
        {
            return await GetRedisDb().GetAllAsync<T>(keys);
        }
        
        public async Task<T> GetAsync<T>(string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().GetAsync<T>(key, flag);
        }       

        public async Task<bool> HashDeleteAsync(string hashKey, string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashDeleteAsync(hashKey, key, flag);
        }
        
        public async Task<long> HashDeleteAsync(string hashKey, IEnumerable<string> keys, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashDeleteAsync(hashKey, keys, flag);
        }
        
        public async Task<bool> HashExistsAsync(string hashKey, string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashExistsAsync(hashKey, key, flag);
        }

        public async Task<Dictionary<string, T>> HashGetAllAsync<T>(string hashKey, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashGetAllAsync<T>(hashKey, flag);
        }

        public async Task<T> HashGetAsync<T>(string hashKey, string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashGetAsync<T>(hashKey, key, flag);
        }

        public async Task<Dictionary<string, T>> HashGetAsync<T>(string hashKey, IList<string> keys, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashGetAsync<T>(hashKey, keys, flag);
        }

        public async Task<IEnumerable<string>> HashKeysAsync(string hashKey, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashKeysAsync(hashKey, flag);
        }
        
        public async Task<long> HashLengthAsync(string hashKey, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashLengthAsync(hashKey, flag);
        }
        
        public async Task HashSetAsync<T>(string hashKey, IDictionary<string, T> values, CommandFlags flag = CommandFlags.None)
        {
            await GetRedisDb().HashSetAsync<T>(hashKey, values, flag);
        }
        
        public async Task<bool> HashSetAsync<T>(string hashKey, string key, T value, bool nx = false, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashSetAsync(hashKey, key, value, nx, flag);
        }

        public async Task<IEnumerable<T>> HashValuesAsync<T>(string hashKey, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().HashValuesAsync<T>(hashKey, flag);
        }

        public async Task<long> RemoveAllAsync(IEnumerable<string> keys, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().RemoveAllAsync(keys, flag);
        }

        public async Task<bool> RemoveAsync(string key, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().RemoveAsync(key, flag);
        }

        public async Task<bool> ReplaceAsync<T>(string key, T value, CommandFlags flag = CommandFlags.None)
        {
            return await GetRedisDb().ReplaceAsync<T>(key, value, When.Always, flag);
        }
        
        public async Task<IEnumerable<string>> SearchKeysAsync(string pattern)
        {
            return await GetRedisDb().SearchKeysAsync(pattern);
        }
            
        #endregion

        #region Protected methods
       
        private IRedisDatabase GetRedisDb()
        {
            return _client.GetDbFromConfiguration();
        }
            
        #endregion
    }
}
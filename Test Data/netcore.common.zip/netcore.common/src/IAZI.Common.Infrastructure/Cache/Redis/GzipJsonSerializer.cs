using IAZI.Common.Core.Utils;
using StackExchange.Redis.Extensions.Core;
using StackExchange.Redis.Extensions.System.Text.Json;

namespace IAZI.Common.Infrastructure.Cache.Redis
{
    public class GzipJsonSerializer : ISerializer
    {
        #region Properties

        /// <summary>
        /// Decorator pattern to use internal features of existing SystemTextJsonSerializer
        /// </summary>
        /// <returns></returns>
        private readonly SystemTextJsonSerializer _systemTextJsonSerializer;

        #endregion

        #region Constructor

        public GzipJsonSerializer()
        {  
            _systemTextJsonSerializer = new SystemTextJsonSerializer();          
        }
            
        #endregion

        #region Public methods

         /// <inheritdoc/>
        public T Deserialize<T>(byte[] serializedObject)
        {
            // Unzip data first
            var output = GzipHelper.Unzip(serializedObject);

            // Use original logic to deserialize data
            return _systemTextJsonSerializer.Deserialize<T>(output);                        
        }

        /// <inheritdoc/>
        public byte[] Serialize(object item)
        {            
            // Original logic
            var serializedObject = _systemTextJsonSerializer.Serialize(item);

            // Gzip output
            return GzipHelper.Zip(serializedObject);
        }
            
        #endregion
         
        
    }
}
using System;
using IAZI.Common.Core.Infrastructure.Interfaces.Cache.Simple;
using Microsoft.Extensions.Caching.Memory;

namespace IAZI.Common.Infrastructure.Cache.Simple
{
    public class MemoryCacheService : IMemoryCacheService
    {
        #region Constants

        #endregion
        
        #region Properties

        private readonly IMemoryCache _memoryCache;

        #endregion

        #region Constructor

        public MemoryCacheService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        #endregion

        #region Public Methods

        public bool SetCachedValue<T>(string cacheKey, T cacheEntry, TimeSpan? absoluteExpiration = null, TimeSpan? slidingExpiration = null, bool replace = true) where T: class
        {            
            if (string.IsNullOrEmpty(cacheKey))
            {
                throw new ArgumentNullException(nameof(cacheKey));
            }

            if (absoluteExpiration == null && slidingExpiration == null)
            {
                // absoluteExpiration = TimeSpan.FromHours(12);
                // Temporary disable the Caching because of Docker environment -> requires a different approach
                absoluteExpiration = TimeSpan.FromSeconds(1);
            }

            // Look for cache key.
            T currentCacheEntry;
            if (!_memoryCache.TryGetValue(cacheKey, out currentCacheEntry) || replace)
            {
                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions();

                if (absoluteExpiration != null)
                {
                    cacheEntryOptions.SetAbsoluteExpiration(absoluteExpiration.Value);
                }
                else
                {
                    cacheEntryOptions.SetSlidingExpiration(slidingExpiration.Value);
                }                    

                // Save data in cache.
                _memoryCache.Set(cacheKey, cacheEntry, cacheEntryOptions);
            }                        
            return true;            
        }

        public T GetCachedValue<T>(string cacheKey) where T: class
        {            
            if (string.IsNullOrEmpty(cacheKey))
            {
                throw new ArgumentNullException(nameof(cacheKey));
            }

            T cacheEntry;

             // Look for cache key.           
            if (_memoryCache.TryGetValue(cacheKey, out cacheEntry))
            {
                return cacheEntry;
            }                        
            
            // TODO: Throw exception?
            return default(T);
        }

        public void RemoveCachedValue(string cacheKey)
        {
            if (string.IsNullOrEmpty(cacheKey))
            {
                throw new ArgumentNullException(nameof(cacheKey));
            }

            _memoryCache.Remove(cacheKey);            
        }

        #endregion

    }
}
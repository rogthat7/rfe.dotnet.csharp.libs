using System.Collections.Generic;

namespace IAZI.Common.Core.Infrastructure.Interfaces.Data.Concurrency
{
    public interface IFastConcurrentQueue<T>
    {
        void Add(T item);        

        bool TryPeek(out T result);        

        T Take(int maxTicks);        

        bool TryTake(out T result);        

        int Count();

        bool IsEmpty();

        IEnumerable<T> CreateSnapshot();
    }
}
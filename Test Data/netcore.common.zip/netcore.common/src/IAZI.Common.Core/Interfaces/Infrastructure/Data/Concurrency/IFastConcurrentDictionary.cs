namespace IAZI.Common.Core.Infrastructure.Interfaces.Data.Concurrency
{
    public interface IFastConcurrentDictionary<T, TU>
    {
        void AddOrUpdate(T key, TU value);        

        void Remove(T key);
       
        bool TryGetValue(T key, out TU result);
       
        TU GetValue(T key);
        
        bool ContainsKey(T key);        

        void Clear();
       
        int Count();       

        bool IsEmpty();
    }
}
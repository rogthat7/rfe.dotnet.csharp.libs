using System;
using System.Data;

namespace IAZI.Common.Core.Infrastructure.Interfaces.Data.Repositories.Dapper
{
    public interface IUnitOfWork : IDisposable
    {
         IDbConnection DbConnection
         {
             get;
         }
    }
}
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using StackExchange.Redis;

namespace IAZI.Common.Core.Interfaces.Infrastructure.Cache.Redis
{
    public interface ICacheFacade 
    {         
        Task<bool> AddAllAsync<T>(IList<Tuple<string, T>> items, CommandFlags flag = CommandFlags.None);

        Task<bool> AddAsync<T>(string key, T value, CommandFlags flag = CommandFlags.None);
        
        Task<bool> ExistsAsync(string key, CommandFlags flag = CommandFlags.None);
        
        Task<IDictionary<string, T>> GetAllAsync<T>(IEnumerable<string> keys);
        
        Task<T> GetAsync<T>(string key, CommandFlags flag = CommandFlags.None);        

        Task<bool> HashDeleteAsync(string hashKey, string key, CommandFlags flag = CommandFlags.None);
        
        Task<long> HashDeleteAsync(string hashKey, IEnumerable<string> keys, CommandFlags flag = CommandFlags.None);
        
        Task<bool> HashExistsAsync(string hashKey, string key, CommandFlags flag = CommandFlags.None);

        Task<Dictionary<string, T>> HashGetAllAsync<T>(string hashKey, CommandFlags flag = CommandFlags.None);

        Task<T> HashGetAsync<T>(string hashKey, string key, CommandFlags flag = CommandFlags.None);

        Task<Dictionary<string, T>> HashGetAsync<T>(string hashKey, IList<string> keys, CommandFlags flag = CommandFlags.None);

        Task<IEnumerable<string>> HashKeysAsync(string hashKey, CommandFlags flag = CommandFlags.None);
        
        Task<long> HashLengthAsync(string hashKey, CommandFlags flag = CommandFlags.None);
        
        Task HashSetAsync<T>(string hashKey, IDictionary<string, T> values, CommandFlags flag = CommandFlags.None);
        
        Task<bool> HashSetAsync<T>(string hashKey, string key, T value, bool nx = false, CommandFlags flag = CommandFlags.None);

        Task<IEnumerable<T>> HashValuesAsync<T>(string hashKey, CommandFlags flag = CommandFlags.None);

        Task<long> RemoveAllAsync(IEnumerable<string> keys, CommandFlags flag = CommandFlags.None);

        Task<bool> RemoveAsync(string key, CommandFlags flag = CommandFlags.None);

        Task<bool> ReplaceAsync<T>(string key, T value, CommandFlags flag = CommandFlags.None);
        
        Task<IEnumerable<string>> SearchKeysAsync(string pattern);       
    }
}
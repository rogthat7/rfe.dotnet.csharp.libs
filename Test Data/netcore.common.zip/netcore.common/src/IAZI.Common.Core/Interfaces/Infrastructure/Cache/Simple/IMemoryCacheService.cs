using System;

namespace IAZI.Common.Core.Infrastructure.Interfaces.Cache.Simple
{
    public interface IMemoryCacheService
    {
         bool SetCachedValue<T>(string cacheKey, T cacheEntry, TimeSpan? absoluteExpiration = null, TimeSpan? slidingExpiration = null, bool replace = true) where T: class;

         T GetCachedValue<T>(string cacheKey) where T: class;

         void RemoveCachedValue(string cacheKey);
    }
}
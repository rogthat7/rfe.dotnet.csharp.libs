namespace IAZI.Common.Core.Interfaces.Models.Shared
{
    public interface IDomainModel
    {
         // Just a marker interface
    }
}
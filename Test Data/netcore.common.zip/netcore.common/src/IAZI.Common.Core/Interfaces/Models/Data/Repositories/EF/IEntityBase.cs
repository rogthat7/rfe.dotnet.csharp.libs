using System;

namespace IAZI.Common.Core.Interfaces.Models.Data.Repositories.EF
{
    public interface IEntityBase
    {
        DateTime? ModDate { get; set; }

        int? ModUserId { get; set; }

        DateTime? CreateDate { get; set; }
    }
}
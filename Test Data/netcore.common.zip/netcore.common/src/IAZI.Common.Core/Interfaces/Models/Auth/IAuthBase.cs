namespace IAZI.Common.Core.Interfaces.Models.Auth
{
    public interface IAuthBase
    {
         // Marker interface for e.g. AppData / Auth classes
    }
}
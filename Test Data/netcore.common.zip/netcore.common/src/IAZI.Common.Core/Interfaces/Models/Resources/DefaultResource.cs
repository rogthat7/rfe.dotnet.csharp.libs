namespace IAZI.Common.Core.Models.Resources
{
    public class DefaultResource
    {
        
    }
}
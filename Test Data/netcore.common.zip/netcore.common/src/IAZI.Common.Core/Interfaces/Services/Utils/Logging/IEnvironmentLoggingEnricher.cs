using Serilog.Core;

namespace IAZI.Common.Core.Interfaces.Services.Utils.Logging
{
    public interface IEnvironmentLoggingEnricher : ILogEventEnricher
    {
         // simple marker interface
    }
}
using System.Threading;
using System.Threading.Tasks;

namespace IAZI.Common.Core.Interfaces.Services.Utils
{
    public interface IStartupTask
    {
        Task ExecuteAsync(CancellationToken cancellationToken = default);
    }
}
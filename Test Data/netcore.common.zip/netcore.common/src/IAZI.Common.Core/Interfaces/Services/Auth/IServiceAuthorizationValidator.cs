using IAZI.Common.Core.Interfaces.Models.Auth;
using IAZI.Common.Core.Models.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface IServiceAuthorizationValidator
    {
        bool ValidateRequirement(AuthorizationHandlerContext context, HttpContext httpContext, out IAuthBase authBase, out UserClaimInfo userClaimInfo);
    }
}
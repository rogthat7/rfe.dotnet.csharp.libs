using Microsoft.Extensions.Logging;

namespace IAZI.Common.Core.Interfaces.Services.Auth.Token
{
    public interface IHttpClientTokenHandlerFactory
    {
        IHttpClientTokenHandler CreateAuthHttpClientTokenHandler(IAuthHttpClient authHttpClient, ILogger logger, ITokenContainer tokenContainer);
        
        IHttpClientTokenHandler CreateLegacyHttpClientTokenHandler(ILegacyAuthHttpClient legacyAuthHttpClient, ILogger logger, ITokenContainer tokenContainer);
    }
}
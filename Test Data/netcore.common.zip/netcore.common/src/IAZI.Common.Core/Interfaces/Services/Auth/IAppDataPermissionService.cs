﻿using System.Collections.Generic;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface IAppDataPermissionService
    {
        bool ValidateAppDataPermissions<T>(IEnumerable<string> appData, List<string> permiCheckList, out T auth) where T : class;
    }
}

using System.Threading.Tasks;
using IAZI.Common.Core.Models.Auth.Token;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface IAuthHttpClient
    {
        Task<string> RequestAccessTokenDelegationAsync(HttpClientTokenCreateRequest httpClientTokenCreateRequest);

        Task<string> RequestAccessTokenClientCredentialsAsync(HttpClientTokenCreateRequest httpClientTokenCreateRequest);       
    }
}
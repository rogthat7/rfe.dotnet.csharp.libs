using System.Net;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface ITokenContainer
    {
        string TryGetToken(string authClientName, string subject, IPAddress requesterIpAddress);

        void SetToken(string authClientName, string subject, IPAddress requesterIpAddress, string token); 
    }
}
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Auth.Legacy;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface ILegacyAuthHttpClient
    {       
        /// <summary>
        /// Call IdentityServer endpoint to request an app token
        /// </summary>
        /// <param name="appTokenRequest"></param>
        /// <returns></returns>
        Task<AppTokenResponseDto> RequestAppToken(AppTokenClientRequestDto appTokenClientRequest);    
    }
}
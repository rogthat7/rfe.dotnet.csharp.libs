using System.Net;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Auth.Token;

namespace IAZI.Common.Core.Interfaces.Services.Auth.Token
{
    public interface IHttpClientTokenHandler
    {
       Task EnsureBearerTokenIsCreated(HttpClientTokenCreateRequest httpClientTokenCreateRequest);

       Task RefreshBearerToken(HttpClientTokenCreateRequest httpClientTokenCreateRequest);

       string GetCreatedToken(string clientName, string subjectReference, IPAddress requesterIpAddress);
    }
}
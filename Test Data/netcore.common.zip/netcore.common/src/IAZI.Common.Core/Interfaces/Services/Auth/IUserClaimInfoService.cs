﻿using IAZI.Common.Core.Models.Auth;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Security.Claims;

namespace IAZI.Common.Core.Interfaces.Services.Auth
{
    public interface IUserClaimInfoService
    {
        UserClaimInfo ExtractUserClaimInfo(IEnumerable<Claim> claims, IHeaderDictionary requestHeaders);
    }
}

namespace IAZI.Common.Core.Interfaces.Web.Shared
{
    public interface IServiceModel
    {
         // Just a marker interface
    }
}
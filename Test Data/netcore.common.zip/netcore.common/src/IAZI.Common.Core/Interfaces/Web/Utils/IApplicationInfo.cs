using System.Collections.Generic;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Models.Web.Utils;

namespace IAZI.Common.Core.Interfaces.Web.Utils
{
    public interface IApplicationInfo
    {
         #region Properties

        /// <summary>
        /// ASP.net core specific hosting environment, normally Development for local development and Production for deployed instances
        /// </summary>
        /// <value></value>
        string HostingEnvironment { get; set; }
        string HostName { get; set; }
        string Database { get; set; }        
        string Version { get; set; }
        string VersionDate { get; set; }
        string SharedLibraryVersion { get; set; }
        string SharedLibraryVersionDate { get; set; }        
        string TCBuildNumber { get; set; }

        string GitHash { get; set; }

        string DockerImageTag { get; set; }

        ICollection<string> ServerAddresses { get; set; }

        string ContentRootPath { get; set; }
        string WebRootPath { get; set; }
        string ServerAddressList { get; }

        X509Certificate2 ServerCertificate { get; set; }  

        IEnumerable<ComplexIPAddress> InternalIPWhitelist { get; set; }
            
        #endregion        

        #region Public methods

        string GetAssemblyInfoDate(Assembly assembly, bool isDeterministicProjectBuild = true);
        
        /// <summary>
        /// Factory method to apply the data 
        /// </summary>
        /// <param name="serviceOptions"></param>
        /// <param name="callingAssembly"></param>
        /// <param name="dbContext"></param>
        /// <param name="isDeterministicProjectBuild"></param>
        /// <returns></returns>
        void InitApplicationInfo(ServiceOptions serviceOptions, Assembly callingAssembly = null, bool isDeterministicProjectBuild = true);
        

        bool IsDevelopmentHostingEnvironment();
        
        bool IsProductionHostingEnvironment();

        bool IsTestingHostingEnvironment();

        int GetHttpsPort();
        
        #endregion

    }
}
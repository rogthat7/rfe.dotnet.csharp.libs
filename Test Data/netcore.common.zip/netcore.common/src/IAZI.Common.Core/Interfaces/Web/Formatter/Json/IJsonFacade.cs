using System;
using System.IO;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Core.Interfaces.Web.Formatter.Json
{
    /// <summary>
    /// Interface for a facade logic of a Json library
    /// </summary>
    public interface IJsonFacade
    {
        #region Public methods

        /// <summary>
        /// Sync Serialization of a .NET Core object to string
        /// </summary>
        /// <param name="value">object to be serialized</param>
        /// <param name="jsonOptions">json options</param>               
        /// <typeparam name="TValue">type of object</typeparam>
        /// <returns></returns>
        string Serialize<TValue>(TValue value, JsonOptions jsonOptions);

        /// <summary>
        /// Async Serialization of a .NET Core object to string
        /// </summary>
        /// <param name="value">object to be serialized</param>
        /// <param name="jsonOptions">json options</param>     
        /// <typeparam name="TValue">type of object</typeparam>
        /// <returns></returns>
        Task<string> SerializeAsync<TValue>(TValue value, JsonOptions jsonOptions);

        /// <summary>
        /// Async deserialization of a json string to a .NET Core object
        /// </summary>
        /// <param name="json">json value</param>
        /// <typeparam name="T">type of expected .NET Core type</typeparam>
        /// <returns>.NET Core instance</returns>
        Task<T> DeserializeObjectAsync<T>(string json, JsonOptions jsonOptions);

        /// <summary>
        /// Sync deserialization of a json string to a .NET Core object, type of object can be passed as a generic
        /// </summary>
        /// <param name="json">json value</param>
        /// <typeparam name="T">type of expected .NET Core type</typeparam>
        /// <returns>.NET Core instance</returns>

        T DeserializeObject<T>(string json, JsonOptions jsonOptions);

        /// <summary>
        /// Async deserialization of a json stream
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="jsonOptions"></param>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        Task<T> DeserializeStreamAsync<T>(Stream stream, JsonOptions jsonOptions);

        /// <summary>
        /// Sync deserialization of a json string to a .NET Core object, type of object can be passed as a parameter
        /// </summary>
        /// <param name="json">json value</param>
        /// <param name="type">type of expected .NET Core type</param>
        /// <returns>Type of object</returns>
        object DeserializeObject(string json, Type type, JsonOptions jsonOptions);

        /// <summary>
        /// Replacement for JObject.Parse and GetValue
        /// Parses a JSON string a gets the value for the given property as a string
        /// </summary>
        /// <param name="json">json value</param>
        /// <param name="propertyName">name of property</param>
        /// <param name="throwException">set to true to throw an Exception if the propertyName is not found</param>
        /// <returns>found string value</returns>
        string ParseAndGetValue(string json, string propertyName, bool throwException, JsonOptions jsonOptions);
            
        /// <summary>
        /// Replacement for JObject.Parse and SelectToken
        /// Unfortuantely the feature is not yet implemented in .NET Core
        /// according to https://github.com/dotnet/runtime/issues/31068
        /// so we need parse each token part and try to get it like this
        /// </summary>
        /// <param name="json">json value</param>
        /// <param name="searchToken">JPath compatibile search token, e.g. address.modbase</param>
        /// <param name="throwException">set to true to throw an Exception if the propertyName is not found</param>
        /// <returns>found value</returns>
        string SelectTokenValue(string json, string searchToken, bool throwException, JsonOptions jsonOptions);

        
        
        #endregion
    }
}
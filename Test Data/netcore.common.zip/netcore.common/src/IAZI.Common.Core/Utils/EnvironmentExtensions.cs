using System;

namespace IAZI.Common.Core.Utils
{
    public static class EnvironmentExtensions
    {
        #region Constants

        private static readonly string EnvSwitchToCertModeNoneIfConfigInvalid = "SwitchToCertModeNoneIfConfigInvalid";

        private static readonly string EnvEnableRedisCache = "EnableRedisCache";
        
        #endregion
        
        #region Public Properties

        public static bool? SwitchToCertModeNoneIfConfigInvalid
        {
            get
            {
                var value = Get(EnvSwitchToCertModeNoneIfConfigInvalid);
                if (value == null)
                {
                    return null;
                }

                if (Boolean.TryParse(value, out bool result))
                {
                    return result;
                }

                return false;
            }
            set
            {
                if (value == null)
                {
                    return;
                }

                Set(EnvSwitchToCertModeNoneIfConfigInvalid, value.Value ? Boolean.TrueString : Boolean.FalseString);
            }
        }

        public static bool? EnableRedisCache
        {
            get
            {
                var value = Get(EnvEnableRedisCache);
                if (value == null)
                {
                    return null;
                }
                
                if (Boolean.TryParse(value, out bool result))
                {
                    return result;
                }

                return false;
            }
            set
            {
                if (value == null)
                {
                    return;
                }

                Set(EnvEnableRedisCache, value.Value ? Boolean.TrueString : Boolean.FalseString);
            }
        }  

        public static string HostingEnvironment
        {
            get
            {
                return Get("ASPNETCORE_ENVIRONMENT") ?? "Unknown";
            }
        }

        public static string HostName
        {
            get
            {
                return Get("HOSTNAME") ?? Environment.MachineName ?? "Unknown";
            }
        }

        public static string GitHash
        {
            get
            {
                return Get("GITHASH") ?? string.Empty;
            }
        }

        public static string TCBuildNumber
        {
            get
            {
                return Get("TCBUILDNUMBER") ?? string.Empty;
            }
        }

        public static string DockerImageTag
        {
            get
            {
                return Get("DOCKER_IMAGE_TAG") ?? string.Empty;
            }
        }

        public static string AspnetCoreUrls
        {
            get
            {
                return Get("ASPNETCORE_URLS") ?? string.Empty;
            }
        }             
        
        #endregion

        #region Public methods

        public static string Get(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException(nameof(key));
            }

            return Environment.GetEnvironmentVariable(key);
        }

        public static void Set(string key, string value)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException(nameof(key));
            }
            
            Environment.SetEnvironmentVariable(key, value);
        }
    
        #endregion
    }
}
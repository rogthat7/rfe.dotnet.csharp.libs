using System;
using System.Text;

namespace IAZI.Common.Core.Utils
{
    /// <summary>
    /// ExceptionExtensions
    /// </summary>
    public static class ExceptionExtensions
    {
        /// <summary>
        /// Gets the exception message.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <param name="recursive">if set to <c>true</c> [recursive].</param>
        /// <param name="addStracktrace">if set to <c>true</c> [add stracktrace].</param>
        /// <returns></returns>
        public static string GetExceptionMessage(this Exception ex, bool recursive = false, bool addStracktrace = false)
        {
            if (ex == null)
                return null;

            var sb = new StringBuilder();
            sb.Append(ex.Message);

            if (recursive)
            {
                while (ex.InnerException != null)
                {
                    sb.Append(Environment.NewLine);
                    sb.Append(" / ");
                    sb.Append(ex.InnerException.Message);
                    ex = ex.InnerException;
                }
            }
            else if (ex.InnerException != null)
            {
                sb.Append(Environment.NewLine);
                sb.Append(" Inner exception:");
                sb.Append(ex.InnerException.Message);
            }

            if (addStracktrace)
            {
                sb.Append(Environment.NewLine);
                sb.Append(" Trace:");
                sb.Append(ex.StackTrace);
            }

            return sb.ToString();
        }
    }
}
using System;
using System.Text.RegularExpressions;

namespace IAZI.Common.Core.Utils
{
    public static class UrlHelper
    {
        /// <summary>
        /// Gets the port number for a given url like http://localhost:60775/ or even http://localhost:60775;https://*:5001
        /// </summary>
        /// <param name="url">url to be parsed</param>
        /// <param name="separator">separator when having multiple urls</param>
        /// <param name="protocol">desired protocol</param>
        /// <returns></returns>
        public static int ExtractPortNumberFromUrl(string url, string separator = ";", string protocol = "https")
        {
            if (string.IsNullOrEmpty(url))
            {
                throw new ArgumentNullException(nameof(url));
            }

            var r = new Regex(@"^(?<proto>\w+)://[^/]+?[:]?(?<port>\d+)[/]?[^/]*", RegexOptions.None, TimeSpan.FromMilliseconds(150));
            var urls = url.Split(separator, StringSplitOptions.RemoveEmptyEntries);

            foreach(var urlItem in urls)
            {
                var urlItemTrimmed = urlItem.Trim('/',' ');
                Match m = r.Match(urlItemTrimmed);
                if (m.Success)
                {
                    var p = m.Result("${proto}");
                    if (p.Equals(protocol, StringComparison.InvariantCultureIgnoreCase))
                    {
                        var port = m.Result("${port}");
                        return Convert.ToInt32(port);
                    }                   
                }                    
            }

            return 0;
        }
    }
}
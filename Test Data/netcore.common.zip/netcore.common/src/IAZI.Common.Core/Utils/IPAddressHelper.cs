using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using IAZI.Common.Core.Models.Web.Utils;

namespace IAZI.Common.Core.Utils
{
    public static class IPAddressHelper
    {
        public static bool IPAddressIsInIPSafeList(IPAddress ipAddress, IEnumerable<ComplexIPAddress> safelist)
        {            
            if (safelist == null)
            {
                return false;
            }

            var safelistBytes = new List<byte[]>();
            foreach (var ip in safelist)
            {
                if (ip.IsCIDRAddress)
                {
                    if (IPAddressIsInCIDRRange(ipAddress, ip.IPAddressText))
                    {
                        return true;
                    }
                }
                else
                {
                    safelistBytes.Add(ip.IPAddress.GetAddressBytes());
                }                
            }

            var bytes = ipAddress.GetAddressBytes();
            
            foreach (var address in safelistBytes)
            {
                if (address.SequenceEqual(bytes))
                {
                    return true;
                }
            }

            return false;
        }
        
        
        public static bool IPAddressIsInSimpleIPSafeList(IPAddress ipAddress, IEnumerable<IPAddress> safelist)
        {            
            if (safelist == null)
            {
                return false;
            }

            var safelistBytes = new List<byte[]>(safelist.Count());
            foreach (var ip in safelist)
            {
                safelistBytes.Add(ip.GetAddressBytes());
            }

            var bytes = ipAddress.GetAddressBytes();
            
            foreach (var address in safelistBytes)
            {
                if (address.SequenceEqual(bytes))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool IPAddressIsInCIDRRange(string checkIp, string cidrIp)
        {
            if (string.IsNullOrEmpty(checkIp))
            {
                throw new ArgumentNullException(nameof(checkIp));
            }

            if (string.IsNullOrEmpty(cidrIp))
            {
                throw new ArgumentNullException(nameof(cidrIp));
            }

            var ipAddress = ParseIPv4AddressesFromText(checkIp)[0];

            return IPAddressIsInCIDRRange(ipAddress, cidrIp);
        }

        public static bool IsCIDRIPAddress(string ipAddress)
        {
            if (string.IsNullOrEmpty(ipAddress))
            {
                throw new ArgumentNullException(nameof(ipAddress));
            }

            var parts = ipAddress.Split('/');
            return parts.Length == 2;
        }

        public static bool IPAddressIsInCIDRRange(IPAddress checkIp, string cidrIp)
        {
            if (string.IsNullOrEmpty(cidrIp))
            {
                throw new ArgumentNullException(nameof(cidrIp));
            }

            var cidrAddress = ParseIPv4AddressesFromText(cidrIp)[0];

            var parts = cidrIp.Split('/');
            if (parts.Length != 2)
            {
                throw new FormatException($"cidrMask was not in the correct format:\nExpected: a.b.c.d/n\nActual: {cidrIp}");
            }
            
            if (!Int32.TryParse(parts[1], out var netmaskBitCount))
            {
                throw new FormatException($"Unable to parse netmask bit count from {cidrIp}");
            }

            if (0 > netmaskBitCount || netmaskBitCount > 32)
            {
                throw new ArgumentOutOfRangeException($"Netmask bit count value of {netmaskBitCount} is invalid, must be in range 0-32");
            }

            var ipAddressBytes = BitConverter.ToInt32(checkIp.GetAddressBytes(), 0);
            var cidrAddressBytes = BitConverter.ToInt32(cidrAddress.GetAddressBytes(), 0);
            var cidrMaskBytes = IPAddress.HostToNetworkOrder(-1 << (32 - netmaskBitCount));

            var ipIsInRange = (ipAddressBytes & cidrMaskBytes) == (cidrAddressBytes & cidrMaskBytes);

            return ipIsInRange;
        }

        // THis method can be used to parse all IP addresses from an arbitrary block of text, if you
        // know that your input is a single IPv4 address in a.b.c.d format, use ParseSingleIPv4Address()
        public static List<IPAddress> ParseIPv4AddressesFromText(string input)
        {
            const string ipV4Pattern =
                @"(?:(?:1\d\d|2[0-5][0-5]|2[0-4]\d|0?[1-9]\d|0?0?\d)\.){3}(?:1\d\d|2[0-5][0-5]|2[0-4]\d|0?[1-9]\d|0?0?\d)";

            if (string.IsNullOrEmpty(input))
            {
                throw new ArgumentException("Input string must not be null", input);
            }

            var ips = new List<IPAddress>();
            
            var regex = new Regex(ipV4Pattern);
            foreach (Match match in regex.Matches(input))
            {
                var ip = ParseSingleIPv4Address(match.Value);
                ips.Add(ip);
            }            

            return ips;
        }

        // This method is used multiple times by the other methods in this class.
        // The input string must contain ONLY a single IPv4 address in a.b.c.d format.
        // If the format of the input is unknown or you are attempting to parse
        // an IP address from an arbitrary block of text, use ParseIPv4Addresses().
        public static IPAddress ParseSingleIPv4Address(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new ArgumentException("Input string must not be null", input);
            }

            var addressBytesSplit = input.Trim().Split('.').ToList();
            if (addressBytesSplit.Count != 4)
            {
                throw new ArgumentException("Input string was not in valid IPV4 format \"a.b.c.d\"", input);
            }

            var addressBytes = new byte[4];
            foreach (var i in Enumerable.Range(0, addressBytesSplit.Count))
            {
                if (!int.TryParse(addressBytesSplit[i], out var parsedInt))
                {
                    throw new FormatException($"Unable to parse integer from {addressBytesSplit[i]}");
                }
                
                if (0 > parsedInt || parsedInt > 255)
                {
                    throw new ArgumentOutOfRangeException($"{parsedInt} not within required IP address range [0,255]");
                }

                addressBytes[i] = (byte)parsedInt;
            }

            return new IPAddress(addressBytes);               
        }      
    }
}
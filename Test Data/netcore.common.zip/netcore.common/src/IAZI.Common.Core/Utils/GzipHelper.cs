using System.IO;
using System.IO.Compression;
using System.Text;

namespace IAZI.Common.Core.Utils
{
    /// <summary>
    /// Based on https://dejanstojanovic.net/aspnet/2017/december/using-gzip-compression-for-large-text-values-in-redis/
    /// </summary>
    public static class GzipHelper
    {
        private static void CopyTo(Stream sourceStream, Stream destinationStream)
        {
            byte[] bytes = new byte[4096];
            int cnt;
            while ((cnt = sourceStream.Read(bytes, 0, bytes.Length)) != 0)
            {
                destinationStream.Write(bytes, 0, cnt);
            }
        }
        
        public static byte[] Zip(string stringValue)
        {
            var bytes = Encoding.UTF8.GetBytes(stringValue);
            return Zip(bytes);
        }

        public static byte[] Zip(byte[] bytes)
        {            
            using (var inputStream = new MemoryStream(bytes))
            {
                using (var outputStream = new MemoryStream())
                {
                    using (var gzipStream = new GZipStream(outputStream, CompressionMode.Compress))
                    {
                        CopyTo(inputStream, gzipStream);
                    }
                    return outputStream.ToArray();
                }
            }
        }
        
        public static string UnzipToString(byte[] bytes)
        {
            return Encoding.UTF8.GetString(Unzip(bytes));  
        } 

        public static byte[] Unzip(byte[] bytes)
        {
            using (var inputStream = new MemoryStream(bytes))
            {
                using (var outputStream = new MemoryStream())
                {
                    using (var gzipStream = new GZipStream(inputStream, CompressionMode.Decompress))  
                    {  
                        CopyTo(gzipStream, outputStream);  
                    }  
  
                    return outputStream.ToArray();  
                }  
            }  
        }  
    } 
}
using System;

namespace IAZI.Common.Core.Utils
{
    /// <summary>
    /// Helper to generate an OTP token (One-Time Password)
    /// </summary>
    public static class OTPGenerator
    {      
        #region Public Methods

         /// <summary>
        /// Generate OTP for login
        /// </summary>
        /// <returns></returns>
        public static string GenerateRandomOTP(int iOTPLength)
        {
            if (iOTPLength <= 0)
            {
                throw new ArgumentNullException(nameof(iOTPLength));
            }
            
            string[] saAllowedCharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };             

            string sOTP = String.Empty;
            string sTempChars = String.Empty;
            Random rand = new Random();

            for (int i = 0; i < iOTPLength; i++)
            {
                int p = rand.Next(0, saAllowedCharacters.Length);
                sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];
                sOTP += sTempChars;
            }
            return sOTP;
        }

        #endregion
        
       
    }
}
using System;
using System.Globalization;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.AspNetCore.Localization;

namespace IAZI.Common.Core.Utils
{
    
    public static class CultureHelper
    {           
        public static string legacyCookieName = "culture";   

        public static readonly char[] CultureCookieSeparator = new[] { '|' };
        public static readonly string CultureCookieCulturePrefix = "c=";
        public static readonly string CultureCookieUICulturePrefix = "uic=";
        
        /// <summary>
        /// Should return e.g. de-CH simply in case provided culture is null or they are identical, if not complex string is provided similar to cookie handling
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="uiCulture"></param>
        /// <returns></returns>
        public static string CreateCultureString(CultureInfo uiCulture, CultureInfo culture = null, bool allowSimpleFormat = true)
        {
            if (uiCulture is null)
            {
                throw new ArgumentNullException(nameof(uiCulture));
            }

            if (!allowSimpleFormat && culture == null)
            {
                culture = uiCulture;
            }

            if (culture != null && (!culture.Equals(uiCulture) || !allowSimpleFormat))
            {
                return CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture, uiCulture));
            }

            return uiCulture.Name;
        }

        public static bool IsSimpleCultureCookieFormat(string value)
        {
            var parts = value.Split(CultureCookieSeparator, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length == 2)
            {
                return false;
            }
            else 
            {
                return true;
            }
        }
        
        public static string ConvertTwoLetterCultureString(string culture)
        {
            if (string.IsNullOrEmpty(culture))
            {
                throw new ArgumentNullException(nameof(culture));
            }
            
            if (culture.Length != 2)
            {
                throw new ArgumentOutOfRangeException(nameof(culture));
            }
            
            culture = culture.ToLowerInvariant();
            
            switch (culture) {
                case "de":
                    culture = CultureOptions.DefaultGermanCulture;
                    break;
                case "fr":
                    culture = CultureOptions.DefaultFrenchCulture;
                    break;
                case "it":
                    culture = CultureOptions.DefaultItalianCulture;
                    break;
                case "en":
                    culture = CultureOptions.DefaultEnglishCulture;
                    break;
                default:
                    throw new NotSupportedException($"Culture {culture} is not supported");
                }
            return culture;
        }
    }
}
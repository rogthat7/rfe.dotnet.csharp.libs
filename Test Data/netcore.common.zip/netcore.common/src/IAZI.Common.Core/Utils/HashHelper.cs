using System;
using System.Text;

namespace IAZI.Common.Core.Utils
{
    public static class HashHelper
    {
         public static readonly string BCryptPepper = "6E44BE34-2A18-4E09-AEFD-D90BA7742581-769C67F3-1999-4E8C-8438-169B832C12A1";

        /// <summary>
        /// Pepperify string
        /// </summary>
        /// <param name="password">String to be pepperified</param>
        /// <returns></returns>
        public static string Pepperify(string password)
        {
            return string.IsNullOrEmpty(password) ? string.Empty : string.Concat(password, BCryptPepper);
        }

         public static string ConvertPasswordFormat(string passwordHash, byte formatMarker)
        {
            var bytes = Encoding.UTF8.GetBytes(passwordHash);
            var bytesWithMarker = new byte[bytes.Length + 1];
            bytesWithMarker[0] = formatMarker;
            bytes.CopyTo(bytesWithMarker, 1);
            return Convert.ToBase64String(bytesWithMarker);
        }
    }
}
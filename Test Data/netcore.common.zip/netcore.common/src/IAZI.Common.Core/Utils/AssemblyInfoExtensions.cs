using System;
using System.IO;
using System.Reflection;

namespace IAZI.Common.Core.Utils
{
    public static class AssemblyInfoExtensions
    {
        /// <summary>
        /// Gets the linker date of the assembly.
        /// Warning: This method doesn't work if you compile your application with /deterministic flag which is the default
        /// </summary>
        /// <param name="assembly"></param>
        /// <returns></returns>
        /// <remarks>https://blog.codinghorror.com/determining-build-date-the-hard-way/</remarks>
        public static DateTime GetLinkerTimeUtcForUndeterministicBuilds(this Assembly assembly)
        {
            var filePath = assembly.Location;
            const int c_PeHeaderOffset = 60;
            const int c_LinkerTimestampOffset = 8;

            var buffer = new byte[2048];

            using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                stream.Read(buffer, 0, 2048);

            var offset = BitConverter.ToInt32(buffer, c_PeHeaderOffset);
            var secondsSince1970 = BitConverter.ToInt32(buffer, offset + c_LinkerTimestampOffset);
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

            var linkTimeUtc = epoch.AddSeconds(secondsSince1970);

            return linkTimeUtc;
        } 

        public static DateTime GetLinkerTimeUtcForDeterministicBuilds(this Assembly assembly)
        {
            var filePath = assembly.Location;
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists)
            {
                throw new Exception($"Error locating assembly at {fileInfo.FullName}");
            }

            return fileInfo.CreationTimeUtc;
        }      
    }
}
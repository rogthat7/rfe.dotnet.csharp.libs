using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace IAZI.Common.Core.Utils
{
    public static class ReflectionHelper
    {
        /// <summary>
        /// Get Static Key Value From Class
        /// </summary>
        /// <param name="obj">Class Object to get it's static key value</param>
        /// <returns></returns>
        public static Dictionary<string, string> GetStaticKeyValueFromClass(object obj)
        {
            return obj.GetType()
                      .GetFields(BindingFlags.Public | BindingFlags.Static)
                      .Where(f => f.FieldType == typeof(string))
                      .ToDictionary(f => f.Name,
                                    f => (string)f.GetValue(null));
        }

    }
}

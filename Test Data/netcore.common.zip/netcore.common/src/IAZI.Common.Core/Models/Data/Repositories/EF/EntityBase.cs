using System;
using IAZI.Common.Core.Interfaces.Models.Data.Repositories.EF;

namespace IAZI.Common.Core.Models.Data.Repositories.EF
{
    public class EntityBase : IEntityBase
    {
        public DateTime? CreateDate { get; set; }

        public DateTime? ModDate { get; set; }

        public int? ModUserId { get; set; }
              
        protected EntityBase()
        {
            CreateDate = DateTime.UtcNow;            
            ModDate = DateTime.UtcNow;                        
        }
    }
}
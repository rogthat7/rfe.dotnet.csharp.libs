namespace IAZI.Common.Core.Models.Data.Repositories.Dapper
{
    public abstract class CreateResponseBase
    {
        #region Properties

        public int CreatedEntityId { get; set; }
            
        #endregion
    }
}
namespace IAZI.Common.Core.Models.Data.Repositories.Dapper
{
    public abstract class UpdateDeleteResponseBase
    {
        #region Properties

        public int RowsAffected { get; set; }
            
        #endregion
    }
}
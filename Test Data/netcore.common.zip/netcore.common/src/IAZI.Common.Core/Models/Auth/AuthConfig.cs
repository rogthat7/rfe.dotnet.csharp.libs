﻿namespace IAZI.Common.Core.Models.Auth
{
    public class AuthConfig
    {
        #region Enums

        public enum ServerAuthModes
        {
            None = 0,
            LegacyAuth = 1,
            IdentityServer = 2,
            Both = 3
        }

        public enum ClientAuthModes
        {           
            LegacyAuth = 1,
            IdentityServer = 2         
        }

        public enum GrantTypeModes
        {
            ClientCredentials = 1,
            Delegation = 2
        }

        public enum LegacyAuthModes
        {           
            Token = 1,
            Credentials = 2         
        }

        #endregion               
    }
}

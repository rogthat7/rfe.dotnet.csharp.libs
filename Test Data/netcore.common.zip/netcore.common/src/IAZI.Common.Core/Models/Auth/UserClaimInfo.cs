﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace IAZI.Common.Core.Models.Auth
{
    [Serializable]
    [DataContract]
    public class UserClaimInfo
    {
        #region Properties

        [DataMember]
        public int UserId { get; set; }

        [DataMember]
        public string UserName { get; set; }

        [DataMember]
        public string ClientId { get; set; }

        [DataMember]
        public string Scope { get; set; }

        [DataMember]
        public string UserEmail { get; set; }

        [DataMember]
        public string CustomerName { get; set; }

        [DataMember]
        public int? BankId { get; set; }

        [DataMember]
        public int? AppFamily { get; set; }

        [DataMember]
        public int? LoginId { get; set; }

        [DataMember]
        public string AppName { get; set; }

        [DataMember]
        public string DeviceId { get; set; }

        [DataMember]
        public int? AppCustomerId { get; set; }
        
        [DataMember]
        public int CustomerId { get; set; }

        [DataMember]
        public int CustomerIdOverwrite { get; set; }

        [DataMember]
        public IEnumerable<string> AppData { get; set; }

        [DataMember]
        public IEnumerable<string> Groups { get; set; }

        [DataMember]
        public bool IsLegacyToken { get; set; }

        [DataMember]
        public string ApplicationExternalId { get; set; }

        #endregion

        #region Public methods

        /// <summary>
        /// Returns the correct customerId for several operations
        /// </summary>
        /// <returns></returns>
        public int GetCurrentCustomerId()
        {
            if (CustomerIdOverwrite != 0)
            {
                return CustomerIdOverwrite;
            }

            return CustomerId;
        }

        #endregion

    }
}

namespace IAZI.Common.Core.Models.Auth.Token
{
    public class AuthHttpClientTokenRequestDto : HttpClientTokenRequestDtoBase
    {
        #region Properties


        #endregion
    }
}
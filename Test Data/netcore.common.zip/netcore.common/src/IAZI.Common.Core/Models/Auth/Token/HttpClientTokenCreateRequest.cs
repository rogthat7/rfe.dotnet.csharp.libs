using System;
using System.Globalization;
using System.Net;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Core.Models.Auth.Token
{
    public class HttpClientTokenCreateRequest
    {
        #region Properties

        private string _clientName;
        
        /// <summary>
        /// It is possible to override ClientName, if not set the Service Interface will be used
        /// </summary>
        /// <value></value>
        public string ClientName
        {
            get
            {
                if (!string.IsNullOrEmpty(_clientName))
                {
                    return _clientName;
                }

                if (ServiceInterface != null)
                {
                    return ServiceInterface.Name;
                }

                return null;
            }
            set
            {
                _clientName = value;
            }
        }
        
        public ServiceInterface ServiceInterface
        {
            get;
            set;
        }

        public IPAddress RequesterIpAddress
        {
            get;
            set;
        }

        public string SubjectReference
        {
            get;
            set;
        }
        
        public HttpClientTokenRequestDtoBase TokenRequest
        {
            get;
            set;
        }

        public string RequesterCulture
        {
            get;
            set;
        }               

        #endregion

        #region Constructor

        public HttpClientTokenCreateRequest(ServiceInterface serviceInterface, HttpClientTokenRequestDtoBase httpClientTokenRequest)
        {
            if (serviceInterface is null)
            {
                throw new ArgumentNullException(nameof(serviceInterface));
            }

            if (httpClientTokenRequest is null)
            {
                throw new ArgumentNullException(nameof(httpClientTokenRequest));
            }

            ServiceInterface = serviceInterface;
            TokenRequest = httpClientTokenRequest;
        }
        
        #endregion

    }
}
using System.Net.Http;
using IAZI.Common.Core.Models.Web.Exceptions;

namespace IAZI.Common.Core.Models.Auth.Token
{
    public class HttpClientTokenResponseDto<T> where T : class
    {
        #region Properties

        public HttpMethod RequestHttpMethod
        {
            get;
            set;
        }
        
        public T Response 
        { 
            get; 
            set; 
        }

        public ProblemDetailsDto ProblemDetailsResult
        {
            get;
            set;
        }        

        #endregion
    }
}
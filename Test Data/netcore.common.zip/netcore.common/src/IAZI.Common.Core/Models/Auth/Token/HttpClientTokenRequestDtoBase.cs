namespace IAZI.Common.Core.Models.Auth.Token
{
    public abstract class HttpClientTokenRequestDtoBase
    {
        #region Properties

        /// <summary>
        /// Override subject reference which is used for token caching, if not set, the subject from context will be used (if available)
        /// </summary>
        /// <value></value>
        public int? SubjectReference { get; set; }

        #endregion
    }
}
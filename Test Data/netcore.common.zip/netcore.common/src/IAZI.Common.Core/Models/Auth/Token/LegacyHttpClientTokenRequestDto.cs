using IAZI.Common.Core.Models.Auth.Legacy;

namespace IAZI.Common.Core.Models.Auth.Token
{
    public class LegacyHttpClientTokenRequestDto : HttpClientTokenRequestDtoBase
    {
        #region Properties

        public AppTokenClientRequestDto  AppTokenClientRequest
        {
            get; set;
        }

        #endregion
    }
}
namespace IAZI.Common.Core.Models.Auth
{
    public static class IAZIHeader
    {
        /// <summary>
        /// Name of custom request header to provide the culture
        /// </summary>
        public const string XCultureRequestHeader = "X-Culture"; 

        /// <summary>
        /// Name of custom request header to provide the application (externalId of application)
        /// </summary>
        public const string XApplicationRequestHeader = "X-Application"; 

        /// <summary>
        /// Name of custom request header to provide the request customer Id
        /// </summary>
        public const string XCustomerIdRequestHeader = "X-CustomerId"; 

        /// <summary>
        /// Name of custom request header to provide the request user Id
        /// </summary>
        public const string XUserIdRequestHeader = "X-UserId";             
    }
}
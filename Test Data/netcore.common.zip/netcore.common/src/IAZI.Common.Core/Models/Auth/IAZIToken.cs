namespace IAZI.Common.Core.Models.Auth
{
    public static class IAZIToken
    {
        public static readonly string ClientPrefix = "client_";
                                
        public static readonly string LegacyAppData =  "appData";   

        public static readonly string LegacyCustomerId =  "customerId";   

        public static readonly string LegacyUserId =  "userId";   

        public static readonly string LegacyEmailAddress =  "emailaddress";   

        public static readonly string LegacyEmail =  "email";   

        public static readonly string LegacyCustomerName =  "customerName";   
        
        public static readonly string LegacyGroups =  "groups";   

        public static readonly string LegacyBankId = "bankId";

        public static readonly string LegacyAppFamily = "appFamily";

        public static readonly string LegacyLoginId = "loginId";

        public static readonly string LegacyAppName = "appName";

        public static readonly string LegacyDeviceId = "deviceId";

        public static readonly string LegacyAppCustomerId = "appCustomerId";
        
        public static readonly string AdditionalClaimType = "additionalClaim";

        public static readonly string IssuerNameClaimType = "issName";

        public static readonly string IssuerClaimType = "iss";

        public static readonly string IssuerClaimEnvironment = "env";

        public static readonly string TokenExpirationClaimType = "exp";

        public static readonly string AudienceClaimType = "aud";

        public static readonly string Scope = "scope";

        public static readonly string TokenIssuedAtTypeClaimType = "iat";

        public static readonly string TokenNotBeforeClaimType = "nbf";

        public static readonly string IdentityClaimTypeSubject = "sub";

        public static readonly string IdentityClaimTypeClientId = "client_id";
        
        public static readonly string IdentityClaimTypeCustomerId = "customer_id";

        public static readonly string IdentityClaimTypeCustomerName = "customer_name";

        public static readonly string IdentityClaimTypePreferredUserName = "preferred_username";

        public static readonly string IdentityClaimTypeEmail = "email";

        public static readonly string IdentityClaimTypeEmailVerified = "email_verified";

        public static readonly string IdentityClaimTypeGivenName = "given_name";

        public static readonly string IdentityClaimTypeFamilyName = "family_name";

        // TODO: Should be removed once AdminUI for IDSRV is no longer in use
        public static readonly string IdentityClaimTypeApp = "IAZI.App";     
        
        public static readonly string IdentityClaimTypeAppData = "app_data";     
        public static readonly string IdentityNameClaimType = "name";         
        public static readonly string IdentityRoleClaimType = "group";         

        
        // TODO: Remove once IDSRV with latest code has been deployed to PROD

        #region Constants for backward compatibility

        public static readonly string ObsoleteUserName = "IAZI.UserName";
        
        public static readonly string ObsoleteEmail = "IAZI.Email";
        
        public static readonly string ObsoleteCustomerId = "IAZI.CustomerId";

        public static readonly string ObsoleteCustomerName = "IAZI.CustomerName";        
        
        public static readonly string ObsoleteApp = "IAZI.App";     
              
        public static readonly string ObsoleteAppData = "IAZI.AppData";  
        
        #endregion         
     
    }

}
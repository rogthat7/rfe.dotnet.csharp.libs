using System.ComponentModel.DataAnnotations;

namespace IAZI.Common.Core.Models.Auth.Legacy
{
    /// <summary>
    /// Client Request to get a legacy app token
    /// </summary>
    public class AppTokenClientRequestDto : AppTokenRequestDto
    {              
        /// <summary>
        /// Ip Address of requester
        /// </summary>
        /// <value></value>
        [Required]
        public string IpAddress { get; set; }

        /// <summary>
        /// Portal token that is used to authenticate the caller for app token request
        /// </summary>
        /// <value></value>        
        public string PortalToken { get; set; }       
    }
}
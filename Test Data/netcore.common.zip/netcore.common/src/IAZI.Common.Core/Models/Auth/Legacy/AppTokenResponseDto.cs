using System.Text.Json.Serialization;

namespace IAZI.Common.Core.Models.Auth.Legacy
{
    public class AppTokenResponseDto
    {
        [JsonPropertyName("token")]
        public string AppToken { get; set; }

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; }
    }
}
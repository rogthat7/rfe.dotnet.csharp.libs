using System.ComponentModel.DataAnnotations;

namespace IAZI.Common.Core.Models.Auth.Legacy
{
    /// <summary>
    /// Request for an App token 
    /// </summary>
    public class AppTokenRequestDto
    {
        /// <summary>
        /// Name of application for which an app token should be requested
        /// </summary>
        /// <value></value>       
        [Required]
        public string App { get; set; }

         /// <summary>
        /// In case for service app token request where no PortalToken is available, the userName needs to be provided to request the token
        /// </summary>
        /// <value></value>
        public string UserName { get; set; }

        /// <summary>
        /// In case for service app token request where no PortalToken is available, the password needs to be provided to request the token
        /// </summary>
        /// <value></value>
        public string Password { get; set; }
    }
}
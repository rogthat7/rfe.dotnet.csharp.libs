﻿using System.Collections.Generic;

namespace IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy
{
    public class ThrottleData
    {
        public string[] whiteListClients { get; set; }
        public List<ClientRateLimiting> clientRateLimiting { get; set; }
    }
    public class ClientRateLimiting
    {
        public string key { get; set; }
        public string keyType { get; set; }
        public List<ThrottlePolicy> policy { get; set; }
    }
}

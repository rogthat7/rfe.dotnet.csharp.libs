﻿using System;

namespace IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy
{
    public class ThrottlePolicy
    {
        public string Period { get; set; }
        public int Limit { get; set; }
        public TimeSpan PeriodTimespan { get; set; }
    }

    public enum KeyType
    {
        email,
        customerId,
        ip,
        mobileAppLoginId
    }
}

﻿using System;

namespace IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy
{
    [Serializable]
    public struct ThrottleCounter
    {
        public DateTime Timestamp { get; set; }
        public long TotalRequests { get; set; }
    }
}

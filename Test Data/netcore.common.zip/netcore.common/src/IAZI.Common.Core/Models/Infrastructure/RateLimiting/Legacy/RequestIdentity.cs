﻿
namespace IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy
{
    public class RequestIdentity
    {
        public string CustomerId { get; set; }
        public string EmailId { get; set; }
        public string IpAddress { get; set; }
        public string CustomerName { get; set; }
        public string MobileAppLoginId { get; set; }
    }
}

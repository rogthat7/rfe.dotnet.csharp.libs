using System;
using StackExchange.Redis.Extensions.Core.Abstractions;
using StackExchange.Redis.Extensions.Core.Configuration;

namespace IAZI.Common.Core.Models.Infrastructure.Cache.Redis
{
    /* public class RedisCacheClient
    {
        #region Properties Singleton

        private static IRedisCacheClient _redisCacheClient;


        /// <summary>
        /// Returns single instance of Bootstrapper
        /// </summary>
        /// <returns></returns>
        public static IRedisCacheClient GetInstance(RedisConfiguration redisConfiguration)
        {
            if (redisConfiguration == null)
            {
                throw new ArgumentNullException(nameof(redisConfiguration));
            }
        }

        #endregion

        #region Properties


        #endregion

        #region Constructor

        /// <summary>
        /// Singleton
        /// </summary>
        private RedisCacheClient()
        {            
        }
            
        #endregion

        #region Public methods



        #endregion


    } */
}


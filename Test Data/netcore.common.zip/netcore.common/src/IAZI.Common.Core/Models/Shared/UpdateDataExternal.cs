using System.ComponentModel.DataAnnotations;

namespace IAZI.Common.Core.Models.Shared
{
    /// <summary>
    /// The underlying data layer uses a user defined table type which is a general one and is used in multiple
    /// context. That's why we don't see Datafilter specific property names here
    /// Additionally to UpdateData we can work with ExternalIds here
    /// </summary>
    public class UpdateDataExternal
    {
        #region Properties

        /// <summary>
        /// Set to true to add  / false means to unassign 
        /// </summary>
        /// <value></value>
        [Required]
        public bool? IsIn { get; set; }

        /// <summary>
        /// In this context the parent Id 
        /// </summary>
        /// <value></value>
        public int? Id1 { get; set; }

        /// <summary>
        /// Parent External Id
        /// </summary>
        /// <value></value>
        public string ExternalId1 { get; set; }

        /// <summary>
        /// In this context the child Id to be added or removed
        /// </summary>
        /// <value></value>
        public int? Id2 { get; set; }

        /// <summary>
        /// Child External Id
        /// </summary>
        /// <value></value>
        public string ExternalId2 { get; set; }

        #endregion                
    }
}
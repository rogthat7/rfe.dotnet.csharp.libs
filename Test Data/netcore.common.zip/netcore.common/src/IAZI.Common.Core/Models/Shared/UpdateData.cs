using System.ComponentModel.DataAnnotations;

namespace IAZI.Common.Core.Models.Shared
{
    /// <summary>
    /// The underlying data layer uses a user defined table type which is a general one and is used in multiple
    /// context. That's why we don't see Datafilter specific property names here
    /// </summary>
    public class UpdateData
    {
        #region Properties

        /// <summary>
        /// Set to true to add  / false means to unassign 
        /// </summary>
        /// <value></value>
        [Required]
        public bool? IsIn { get; set; }

        /// <summary>
        /// In this context the parent Id 
        /// </summary>
        /// <value></value>
        [Required]   
        public int? Id1 { get; set; }

        /// <summary>
        /// In this context the child Id to be added or removed
        /// </summary>
        /// <value></value>
        [Required]
        public int? Id2 { get; set; }

        #endregion                
    }
}
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Core.Models.Shared
{
    /// <summary>
    /// RequestBase for domain services
    /// </summary>
    public abstract class RequestBase
    {        
        #region Properties

        /// <summary>
        /// Culture
        /// </summary>
        /// <value></value>
        [Required]
        [MaxLength(5)]
        [DefaultValue(CultureOptions.DefaultGermanCulture)]        
        public virtual string Culture { get; set; } = CultureOptions.DefaultGermanCulture;

        /// <summary>
        /// EmployeeId
        /// </summary>
        /// <value></value>        
        [Required]
        [Range(1, int.MaxValue)]
        [DefaultValue(DefaultValues.DefaultRequestSystemUserId)]        
        public virtual int? RequestUserId { get; set; } = DefaultValues.DefaultRequestSystemUserId;

        /// <summary>
        /// CustomerId
        /// </summary>
        /// <value></value>
        [Required]
        [Range(1, int.MaxValue)]
        [DefaultValue(DefaultValues.DefaultRequestSystemCustomerId)]        
        public virtual int? RequestCustomerId { get; set; } = DefaultValues.DefaultRequestSystemCustomerId;    
              
        #endregion
    }
}
namespace IAZI.Common.Core.Models.Shared
{
    public class DefaultValues
    {
        #region Constants
       
        /// <summary>
        /// DefaultRequestSystemCustomerId
        /// </summary>
        public const int DefaultRequestSystemCustomerId = -1;

        /// <summary>
        /// DefaultRequestSystemUserId
        /// </summary>
        public const int DefaultRequestSystemUserId = -1;                      

        #endregion
    }
}
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IAZI.Common.Core.Models.Shared
{
    /// <summary>
    /// UpdateRequest
    /// </summary>
    public class UpdateRequest
    {
        /// <summary>
        /// inList
        /// </summary>
        /// <value></value>
        [Required]
        public IEnumerable<int> inList { get; set; } = new List<int>();


        /// <summary>
        /// outList
        /// </summary>
        /// <value></value>
        [Required]
        public IEnumerable<int> outList { get; set; } = new List<int>();
    }
}
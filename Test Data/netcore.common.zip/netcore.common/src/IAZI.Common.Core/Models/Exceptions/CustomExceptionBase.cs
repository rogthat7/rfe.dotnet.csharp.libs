using System;

namespace IAZI.Common.Core.Models.Exceptions
{
    public abstract class CustomExceptionBase : Exception
    {
        #region Properties

        public string ErrorCode
        {
            get
            {
                return CreateErrorCode();
            }            
        }

        public int ErrorCodeNumber
        {
            get;
            set;
        }

        public abstract string ErrorCodePrefix
        {
            get;
        }
        
        #endregion
        
        #region Constructor
        
        public CustomExceptionBase(int errorCodeNumber, string errorMessage) : base(errorMessage)
        {
            if (errorCodeNumber < 0)
            {
                throw new ArgumentException("errorCodeNumber needs to be >= 0");
            }

            if (errorCodeNumber > 9999)
            {
                throw new ArgumentException("errorCodeNumber needs to be < 10000");
            }

            ErrorCodeNumber = errorCodeNumber;
        }

        #endregion

        #region Methods

        private string CreateErrorCode()
        {            
            return $"{ErrorCodePrefix}{ErrorCodeNumber.ToString("0000")}";            
        }

        #endregion
    }
}
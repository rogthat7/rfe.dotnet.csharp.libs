namespace IAZI.Common.Core.Models.Exceptions
{
    public class BusinessException : CustomExceptionBase
    {
        #region Constants

        private const string errorCodePrefix = "BE";
        
        #endregion
        
        #region Properties

        public override string ErrorCodePrefix => errorCodePrefix;

        #endregion
        
        #region Constructor
        
        public BusinessException(int errorCodeNumber, string errorMessage) : base(errorCodeNumber, errorMessage)
        {            
        }

        #endregion

        #region Methods


        #endregion
    }
}
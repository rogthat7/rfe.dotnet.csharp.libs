namespace IAZI.Common.Core.Models.Exceptions
{
    public class TechnicalException : CustomExceptionBase
    {
        #region Constants

        private const string errorCodePrefix = "TE";
        
        #endregion
        
        #region Properties

        public override string ErrorCodePrefix => errorCodePrefix;

        #endregion
        
        #region Constructor

        public TechnicalException(int errorCodeNumber, string errorMessage) : base(errorCodeNumber, errorMessage)
        {            
        }

        

        #endregion

        #region Methods


        #endregion
    }
}
using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace IAZI.Common.Core.Models.Web.Converter
{
    public class CustomBooleanJsonConverter : JsonConverter<bool>
    {
        public override bool Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.True || reader.TokenType == JsonTokenType.False)
            {
                return reader.GetBoolean();                
            }
            else
            {
                var value = reader.GetInt32();
                if (value == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            
            throw new JsonException();
        }

        public override void Write(Utf8JsonWriter writer, bool value, JsonSerializerOptions options)
        {
            writer.WriteBooleanValue(value);
        }
    }
}
using System.Text.Json.Serialization;

namespace IAZI.Common.Core.Models.Web.Security
{
    public class CspReportRequest
    {
        [JsonPropertyName("csp-report")]
        public CspReport CspReport { get; set; }
    }
}
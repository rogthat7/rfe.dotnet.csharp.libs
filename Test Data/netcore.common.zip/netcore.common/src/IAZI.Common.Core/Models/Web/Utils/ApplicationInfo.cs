using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using IAZI.Common.Core.Interfaces.Web.Utils;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Models.Web.Utils;
using IAZI.Common.Core.Utils;

namespace IAZI.Common.Core.Models.Utils
{
    public class ApplicationInfo : IApplicationInfo
    {
        #region Constants

        public const string EnvironmentTesting = "Testing";
        
        #endregion
        
        #region Properties

        /// <summary>
        /// ASP.net core specific hosting environment, normally Development for local development and Production for deployed instances
        /// </summary>
        /// <value></value>
        public string HostingEnvironment { get; set; }
        public string HostName { get; set; }
        public string Database { get; set; }        
        public string Version { get; set; }
        public string VersionDate { get; set; }

        public string SharedLibraryVersion { get; set; }
        public string SharedLibraryVersionDate { get; set; }
        
        public string TCBuildNumber { get; set; }

        public string GitHash { get; set; }

        public string DockerImageTag { get; set; }

        public ICollection<string> ServerAddresses { get; set; } = new List<string>();

        public string ContentRootPath { get; set; }

        public string WebRootPath { get; set; }

        public X509Certificate2 ServerCertificate { get; set; }
        
        public string ServerAddressList
        {
            get
            {
                return ServerAddresses == null ? null : string.Join(',', ServerAddresses);
            }            
        }

        public IEnumerable<ComplexIPAddress> InternalIPWhitelist { get; set; }
            
        #endregion        

        #region Public methods

        public string GetAssemblyInfoDate(Assembly assembly, bool isDeterministicProjectBuild = true)
        {
            if (assembly == null)
            {
                throw new ArgumentNullException(nameof(assembly));
            }
            
            return isDeterministicProjectBuild ? 
                  assembly.GetLinkerTimeUtcForDeterministicBuilds().ToString("yyyy-MM-dd HH:mm")
                : assembly.GetLinkerTimeUtcForUndeterministicBuilds().ToString("yyyy-MM-dd HH:mm");
        }

        /// <summary>
        /// Factory method to apply the data 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="callingAssembly"></param>
        /// <param name="dbContext"></param>
        /// <param name="isDeterministicProjectBuild"></param>
        /// <returns></returns>
        public void InitApplicationInfo(ServiceOptions serviceOptions, Assembly callingAssembly = null, bool isDeterministicProjectBuild = true)
        {
            if (serviceOptions is null)
            {
                throw new ArgumentNullException(nameof(serviceOptions));
            }

            HostingEnvironment = EnvironmentExtensions.HostingEnvironment;
            HostName = EnvironmentExtensions.HostName;
            GitHash = EnvironmentExtensions.GitHash;
            TCBuildNumber = EnvironmentExtensions.TCBuildNumber;
            DockerImageTag = EnvironmentExtensions.DockerImageTag;
            
            var sbDbs = new StringBuilder();
            if (serviceOptions.Data.ConnectionStrings != null)
            {
                foreach(var connectionString in serviceOptions.Data.ConnectionStrings)                
                {
                    if (serviceOptions.Data.GetDbConnectionString(connectionString.Key) != null)
                    {
                        serviceOptions.Data.ExtractDatabaseInfoFromDbConnectionString(out string server, out string database, connectionString.Key);
                        if (!string.IsNullOrEmpty(server) && !string.IsNullOrEmpty(database))
                        {
                            if (sbDbs.Length > 0)
                            {
                                sbDbs.Append(", ");
                            }
                            sbDbs.Append(server + " / " + database);
                        }
                    }
                }
                Database = sbDbs.ToString();
            }            

            if (callingAssembly != null)
            {
                VersionDate = GetAssemblyInfoDate(callingAssembly, isDeterministicProjectBuild);
                Version = callingAssembly.GetName().Version.ToString();                
            }

            var sharedLibraryAssembly = this.GetType().Assembly;
            SharedLibraryVersionDate = GetAssemblyInfoDate(sharedLibraryAssembly, isDeterministicProjectBuild);
            SharedLibraryVersion = sharedLibraryAssembly.GetName().Version.ToString(); 

            if (serviceOptions.Security.ServiceInternalIPWhitelist != null)
            {
                InternalIPWhitelist = serviceOptions.Security.ParseServiceInternalIpWhitelist();
            }
        }

        public bool IsDevelopmentHostingEnvironment()
        {
            return IsEnvironment(Microsoft.Extensions.Hosting.Environments.Development);
        }

        public bool IsProductionHostingEnvironment()
        {
            return IsEnvironment(Microsoft.Extensions.Hosting.Environments.Production);
        }

        public bool IsTestingHostingEnvironment()
        {
            return IsEnvironment(ApplicationInfo.EnvironmentTesting);
        }

        public int GetHttpsPort()
        {
            var aspnetCoreUrl = EnvironmentExtensions.AspnetCoreUrls;
            if (!String.IsNullOrWhiteSpace(aspnetCoreUrl))
            {
                return UrlHelper.ExtractPortNumberFromUrl(aspnetCoreUrl);               
            } 

            return 0;    
        }

        #endregion

        #region Private methods

        private bool IsEnvironment(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(nameof(environmentName));
            }

            return string.Equals(
                HostingEnvironment,
                environmentName,
                StringComparison.OrdinalIgnoreCase);
        }

        #endregion
    }
}
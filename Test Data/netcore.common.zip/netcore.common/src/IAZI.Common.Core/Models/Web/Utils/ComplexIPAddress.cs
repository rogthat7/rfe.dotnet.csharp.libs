using System;
using System.Net;
using IAZI.Common.Core.Utils;

namespace IAZI.Common.Core.Models.Web.Utils
{
    public class ComplexIPAddress
    {
        #region Properties

        public string IPAddressText { get; set; }

        public bool IsCIDRAddress { get; set; }

        public IPAddress IPAddress { get; set; }
            
        #endregion

        #region Constructor

        public ComplexIPAddress(string ipAddressText)
        {
            if (string.IsNullOrEmpty(ipAddressText))
            {
                throw new ArgumentNullException(nameof(ipAddressText));
            }

            IPAddressText = ipAddressText;
            IsCIDRAddress = IPAddressHelper.IsCIDRIPAddress(ipAddressText);
                       
            if (!IsCIDRAddress)
            {
                if (IPAddress.TryParse(ipAddressText, out var parsedIPAddress))
                {
                    IPAddress = parsedIPAddress;
                }    
            }  
        }
            
        #endregion        
    }
}
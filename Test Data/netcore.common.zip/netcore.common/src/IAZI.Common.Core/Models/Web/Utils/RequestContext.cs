using System;
using System.Globalization;
using System.Net;
using System.Runtime.CompilerServices;
using IAZI.Common.Core.Interfaces.Models.Auth;
using IAZI.Common.Core.Models.Auth;

[assembly: InternalsVisibleTo("IAZI.Common.Service")]
namespace IAZI.Common.Core.Models.Utils
{
    public class RequestContext<T> where T: class, IAuthBase
    {
        #region Properties

        /// <summary>
        /// Request UI Culture set via Culture Providers
        /// </summary>
        /// <value></value>
        public CultureInfo RequestUICulture { get; private set; }

        /// <summary>
        /// Request Culture set via Culture Providers
        /// </summary>
        /// <value></value>
        public CultureInfo RequestCulture { get; private set; }

        /// <summary>
        /// Culture string based on RequestUICulture and RequestCulture, should be used e.g. for DB calls
        /// </summary>
        /// <value></value>
        public string Culture { get; private set; }
      
        public UserClaimInfo UserClaimInfo { get; private set; }

        public IPAddress RequestIpAddress { get; private set; }

        public string AccessToken { get; private set; }

        public T LegacyAuthData { get; private set; }
            
        #endregion

        #region Constructor

        public RequestContext(CultureInfo requestUICulture, CultureInfo requestCulture, string culture,
            UserClaimInfo userClaimInfo, IPAddress requestIpAddress, string accessToken)
        {
            if (requestUICulture == null)
            {
                throw new ArgumentNullException(nameof(requestUICulture));
            }

            if (requestCulture == null)
            {
                throw new ArgumentNullException(nameof(requestCulture));
            }

            if (string.IsNullOrWhiteSpace(culture))
            {
                throw new ArgumentNullException(nameof(culture));
            }
      
            if (userClaimInfo == null)
            {
                throw new ArgumentNullException(nameof(userClaimInfo));
            }    

            if (requestIpAddress == null)
            {
                throw new ArgumentNullException(nameof(requestIpAddress));
            }       

            RequestCulture = requestCulture;
            RequestUICulture = requestUICulture;
            Culture = culture;
            UserClaimInfo = userClaimInfo;
            RequestIpAddress = requestIpAddress;
            AccessToken = accessToken;            
        }
            
        #endregion

        #region Internal methods

        internal void SetLegacyAuthData(T legacyAuthData)
        {
            if (legacyAuthData == default(T))
            {
                throw new ArgumentNullException(nameof(legacyAuthData));            
            }

            LegacyAuthData = legacyAuthData;
        }

        #endregion
    }
}
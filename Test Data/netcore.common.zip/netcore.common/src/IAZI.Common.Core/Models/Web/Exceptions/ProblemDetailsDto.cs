using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace IAZI.Common.Core.Models.Web.Exceptions
{   
    /// <summary>
    /// A machine-readable format for specifying errors in HTTP API responses based on
    //     https://tools.ietf.org/html/rfc7807.
    /// </summary>
    public class ProblemDetailsDto : ProblemDetails
    {
        public override string ToString()
        {
            return $"status={this.Status?.ToString() ?? string.Empty},title={this.Title ?? string.Empty},instance={this.Instance ?? string.Empty},type={this.Type ?? string.Empty},detail={this.Detail ?? string.Empty}";                      
        }        
    }
}
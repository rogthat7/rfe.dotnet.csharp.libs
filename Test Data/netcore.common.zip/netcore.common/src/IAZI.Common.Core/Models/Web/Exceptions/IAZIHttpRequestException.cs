using System;
using System.Net.Http;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Core.Models.Web.Exceptions
{
    /// <summary>
    /// Custom Http Request Exception that should be used if
    /// a) a different Status Code than 500 should be returned to the consumer
    /// b) to be able to pass the exception message to the consumer (be careful not to expose technical details)
    /// </summary>
    public class IAZIHttpRequestException : HttpRequestException
    {
        #region Properties

        public int StatusCode { get; private set; } = StatusCodes.Status500InternalServerError;

        /// <summary>
        /// If set to true, the passed message will be included as "Details" in the ProblemDetails result for the consumer        
        /// </summary>
        /// <value></value>
        public bool ExposeMessageToConsumer { get; private set; } = false;
            
        #endregion

        #region Constructor

        public IAZIHttpRequestException(string message, bool exposeMessageToConsumer = false, int statusCode = StatusCodes.Status500InternalServerError, Exception inner = null) : base(message, inner)
        {
            StatusCode = statusCode;           
            ExposeMessageToConsumer = exposeMessageToConsumer;
        }                       
            
        #endregion
    }
}
using System.Net;
using IAZI.Common.Core.Models.Exceptions;

namespace IAZI.Common.Core.Models.Web.Exceptions
{
    /// <summary>
    /// Status Code related errors are handled via the build-in StatusCodePage Middleware
    /// However, this will only visualize status code based issues when the content is e.g. empty
    /// So return NotFound() will display the page but not NotFound("Message")
    /// This is done to avoid issues with responses that are not determined for web viewing
    /// In our case we need simply to avoid NotFound("Message") and instead throw an instance of this class
    /// to view the error page including the StatusCode
    /// </summary>
    public class BusinessWebException : BusinessException
    {
        #region Properties

        public HttpStatusCode StatusCode
        {
            get;
            set;
        }
        
        #endregion
        
        #region Constructor
        
        public BusinessWebException(HttpStatusCode statusCode, int errorCodeNumber, string errorMessage, bool setUserLogDetails = true) : base(errorCodeNumber, errorMessage)
        {
            StatusCode = statusCode;          
        }

        #endregion

        #region Methods
      

        #endregion
    }
}
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace IAZI.Common.Core.Models.Web.Exceptions
{
    /// <summary>
    /// A machine-readable format for specifying errors in HTTP API responses based on
    //     https://tools.ietf.org/html/rfc7807.
    /// </summary>
    public class ValidationProblemDetailsDto : ValidationProblemDetails
    {        
        /// <summary>
        /// Initializes a new instance of <see cref="ValidationProblemDetails"/>.
        /// </summary>
        public ValidationProblemDetailsDto() : base()
        {            
        }

        /// <summary>
        /// Initializes a new instance of <see cref="ValidationProblemDetails"/> using the specified <paramref name="modelState"/>.
        /// </summary>
        /// <param name="modelState"><see cref="ModelStateDictionary"/> containing the validation errors.</param>
        public ValidationProblemDetailsDto(ModelStateDictionary modelState)
            : base(modelState)
        {           
        }

        /// <summary>
        /// Initializes a new instance of <see cref="ValidationProblemDetails"/> using the specified <paramref name="errors"/>.
        /// </summary>
        /// <param name="errors">The validation errors.</param>
        public ValidationProblemDetailsDto(IDictionary<string, string[]> errors)
            : base(errors)
        {            
        }
    }
}
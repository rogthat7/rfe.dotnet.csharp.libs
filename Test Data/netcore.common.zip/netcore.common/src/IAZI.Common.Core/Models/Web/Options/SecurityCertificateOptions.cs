using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class SecurityCertificateOptions
    {
        #region Enums

        public enum CertMode
        {
            None = 0,
            PEM = 1,
            PFX = 2,
            Store = 3
        }
        
        #endregion
        
        #region Constants

        public static readonly string ConfigurationRoot = SecurityOptions.ConfigurationRoot+":Certificate";
            
        #endregion
        
        #region Properties

        /// <summary>
        /// When set to true, the CertMode will be switched to None in case the config is invalid (e.g. cert is not valid)
        /// Please use this with caution because the service might be starting anyway but not with the 
        /// expected certificate
        /// </summary>
        /// <value></value>
        public bool SwitchToCertModeNoneIfConfigInvalid { get; set; } 

        /// <summary>
        /// If set to PEM, only PathCrt+PathKey are recognized for certificate handling, set to PFX to be able to use PFX or even Store
        /// </summary>
        /// <value></value>
        public CertMode UsedCertMode { get; set; } = CertMode.None;

        /// <summary>
        /// The full path for the Public key certificates in PEM format (only UsedCertMode=PEM)
        /// </summary>
        /// <value></value>
        public string PathCrt { get; set; }

        /// <summary>
        /// The full path for the Private key certificate in PEM format (only UsedCertMode=PEM)
        /// </summary>
        /// <value></value>
        public string PathKey { get; set; }

        /// <summary>
        /// The full path to the PFX certificate (only UsedCertMode=PFX)
        /// </summary>
        /// <value></value>
        public string PathPfx { get; set; } 

        /// <summary>
        /// The Secret for the Pfx file  (only UsedCertMode=PFX)
        /// </summary>
        /// <value></value>
        public string PfxSecret { get; set; }

        /// <summary>
        /// The thumbprint of the certificate to be used (only UsedCertMode=Store)
        /// </summary>
        /// <value></value>
        public string StoreCertThumbprint { get; set; }

        /// <summary>
        /// Location of the cert in the store (only UsedCertMode=Store)
        /// </summary>
        /// <value></value>
        public StoreLocation StoreCertLocation { get; set; } = StoreLocation.LocalMachine;

        /// <summary>
        /// If true the certificates are used for Kestrel SSL
        /// </summary>
        /// <value></value>
        public bool UseServerCertificateForSecuredKestrel { get; set; }
            
        #endregion
                   
        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(SecurityCertificateOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            } 

            var switchToCertModeNoneIfConfigInvalid = false;
            
            if (options.UsedCertMode == CertMode.PEM)
            {
                if (string.IsNullOrEmpty(options.PathCrt))
                {
                    throw new Exception("SecurityCertificateOptions validation error: PathCrt is required");
                }

                if (!File.Exists(options.PathCrt))
                {
                    if (options.SwitchToCertModeNoneIfConfigInvalid)
                    {
                        switchToCertModeNoneIfConfigInvalid = true;
                    }
                    else
                    {
                        throw new Exception($"SecurityCertificateOptions validation error: PathCrt was provided but file ('{options.PathCrt}') doesn't exist");
                    }
                }

                if (string.IsNullOrEmpty(options.PathKey))
                {
                    throw new Exception("SecurityCertificateOptions validation error: PathKey is required");
                }

                if (!File.Exists(options.PathKey))
                {
                    if (options.SwitchToCertModeNoneIfConfigInvalid)
                    {
                        switchToCertModeNoneIfConfigInvalid = true;
                    }
                    else
                    {
                        throw new Exception($"SecurityCertificateOptions validation error: PathKey was provided but file ('{options.PathKey}') doesn't exist");
                    }
                }
            }
            else if (options.UsedCertMode == CertMode.PFX)
            {
                if (string.IsNullOrEmpty(options.PathPfx))
                {
                    throw new Exception("SecurityCertificateOptions validation error: PathPfx is required");
                }

                if (!File.Exists(options.PathPfx))
                {
                    if (options.SwitchToCertModeNoneIfConfigInvalid)
                    {
                        switchToCertModeNoneIfConfigInvalid = true;
                    }
                    else
                    {
                        throw new Exception($"SecurityCertificateOptions validation error: PathPfx was provided but file ('{options.PathPfx}') doesn't exist");
                    }
                }

                if (string.IsNullOrEmpty(options.PfxSecret))
                {
                    throw new Exception("SecurityCertificateOptions validation error: PfxSecret is required");
                }
            }
            else if (options.UsedCertMode == CertMode.Store)
            {
                if (string.IsNullOrEmpty(options.StoreCertThumbprint))
                {
                    throw new Exception("SecurityCertificateOptions validation error: StoreCertThumbprint is required");
                }
            }
            
            // Setting this to None because of invalid arguments
            if (switchToCertModeNoneIfConfigInvalid)
            {
                options.UsedCertMode = CertMode.None;
            }

            return true;
        }
        
        #endregion
    }
}
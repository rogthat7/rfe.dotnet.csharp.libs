namespace IAZI.Common.Core.Models.Web.Options
{
    public enum DeployEnvironment
    {
        LOCAL = 0,
        DEV = 1,
        INT = 2,
        TEST = 3,
        PROD = 4
    }
}
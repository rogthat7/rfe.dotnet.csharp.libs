using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Models.Web.Utils;
using IAZI.Common.Core.Utils;
using Microsoft.IdentityModel.Tokens;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class SecurityOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Security";

        public static string CSPViolationReportUrl = "/cspviolationreport";        
            
        #endregion
        
        #region Properties

        /// <summary>
        /// Defines the Cors access to the service from Web applications
        /// </summary>
        /// <value></value>        
        public string CorsOrigins { get; set; }     
        
        /// <summary>
        /// The ApiName, used as ClientName for IdentityServer when calling other services and also in Swagger
        /// Also it is used as the used "Scope" that is required in IdentityServer based security mode when another 
        /// service tries to access 
        /// </summary>
        /// <value></value>
        [Required]
        public string ApiName { get; set; }

        /// <summary>
        /// Secret to be used with IdentityServer, is not mandatory to allow services without security
        /// </summary>
        /// <value></value>
        public string ApiSecret { get; set; }

        /// <summary>
        /// Used to identity the authorization section in app tokens, e.g. "authadmin"
        /// </summary>
        /// <value></value>
        public string AppName { get; set; }

        /// <summary>
        /// The Authentication mode the service should use
        /// </summary>
        /// <value></value>
        public AuthConfig.ServerAuthModes ServerAuthMode { get; set; } = AuthConfig.ServerAuthModes.IdentityServer;

        /// <summary>
        /// Issuer name for V1 Service.Auth legacy tokens, only required if ServerAuthMode = Legacy/Both
        /// </summary>
        /// <value></value>
        public string TokenIssuerV1 { get; set; }

        /// <summary>
        /// Issuer name for V2 Service.Auth legacy tokens, only required if ServerAuthMode = Legacy/Both
        /// </summary>
        /// <value></value>
        public string TokenIssuerV2 { get; set; }

        /// <summary>
        /// Static Audience client id for Service.Auth legacy tokens, only required if ServerAuthMode = Legacy/Both
        /// </summary>
        /// <value></value>
        public string LegacyAudienceClientId { get; set; }

        /// <summary>
        /// Static Client secret for Service.Auth legacy tokens, only required if ServerAuthMode = Legacy/Both
        /// </summary>
        /// <value></value>
        public string LegacyClientSecret { get; set; }    

        /// <summary>
        /// Collection of endpoints that will get a custom CSP header
        /// </summary>
        /// <value></value>
        public List<CSPExcludedEndpoint> CSPExcludedEndpoints { get; set; } = new List<CSPExcludedEndpoint>
        {
        };         

        /// <summary>
        /// Should be set when certificates have to be used, e.g. for Kestrel based SSL or for signing tokens in IdentityServer project
        /// </summary>
        /// <returns></returns>
        public SecurityCertificateOptions Certificate { get; set; } = new SecurityCertificateOptions();        

        /// <summary>
        /// If true the dataProtection setup will take place which requires to store some encryption keys 
        /// Will not be executed when ServerAuthMode is None even when set to true
        /// </summary>
        /// <value></value>
        public bool InitDataProtection { get; set; } = true;

        /// <summary>
        /// If true Redis will be used to store the DataProtection keys, please ensure Redis is also enabled
        /// </summary>
        /// <value></value>
        public bool UseDataProtectionRedisStore { get; set; } = false;

        /// <summary>
        /// If set to true in combination with InitDataProtection=true, the NullDataProtectionProvider is used
        /// which basically overwrites the behaviour of existing DataProtectionProvider doing nothing.
        /// It is rather recommended to use InitDataProtection=false instead (e.g. for ZKB scenario)
        /// </summary>
        /// <value></value>
        public bool UseNullDataProtectionProvider { get; set; } = false;

        public string DataProtectionFolder { get; set; } = "/dataprotection";

        public int DataProtectionKeyLifeTimeInDays { get; set; } = 90;
               
        /// <summary>
        /// If the connection requires Https, should be kept true and only changed for local development
        /// </summary>        
        public bool RequireHttpsMetadata { get; set; } = true;

         /// <summary>
        /// Specifies whether caching is enabled for introspection responses (requires a distributed cache implementation)
        /// </summary>
        public bool EnableAccessTokenCaching { get; set; }

         /// <summary>
        /// Specifies ttl for introspection response caches
        /// </summary>
        public TimeSpan AccessTokenCacheDuration { get; set; } = TimeSpan.FromMinutes(10);

        /// <summary>
        /// Specifies the prefix of the cache key (token).
        /// </summary>
        public string AccessTokenCacheKeyPrefix { get; set; } = string.Empty;        

        /// <summary>
        /// Class reference for AuthToken of Legacy Authorization setup
        /// </summary>
        /// <value></value>
        public string AuthTokenClass { get; set; }

        /// <summary>
        /// The permission set based payload of old Service.Auth is always required when using legacy tokens
        /// In some rare cases it can also be required when working with new tokens
        /// Authorization will fail and return 403 if legacy app data is required but not provided
        /// </summary>
        /// <value></value>
        public bool RequiresLegacyAppData { get; set; }

        /// <summary>
        /// If true the a new default authorization policy will be set that is used with the [Authorize] attribute
        /// </summary>
        /// <value></value>
        public bool CreateAuthorizationDefaultPolicy { get; set; } = true;

        /// <summary>
        /// Add IP addresses here to hide certain features of the service to external requesters that are not in this list
        /// (e.g. this is used to hide Swagger endpoints or to hide Properties in the Info Controller)
        /// </summary>
        /// <value></value>
        public List<string> ServiceInternalIPWhitelist { get; set; } = new List<string>();       
    
        #endregion

        #region Properties not to be set via config
       
        /// <summary>
        /// IdentityServer Authority Url, will be set via Interfaces -> Service.Auth.IdentityServer BaseUrl and doesn't need to be set in Security section again
        /// </summary>
        /// <value></value>
        public string Authority { get; set; }
       
        private Type _authTokenType;
        public Type AuthTokenType 
        { 
            get
            {
                if (!string.IsNullOrEmpty(AuthTokenClass))
                {
                    return Type.GetType(AuthTokenClass, true, true);
                }                
                else if (_authTokenType != null)
                {
                    return _authTokenType;
                }
                else
                {
                    return null;        
                }
            }
            set
            {
                _authTokenType = value;
            }
        }    
            
        #endregion

        #region Public methods

        /// <summary>
        /// Creates the issuer signin keys for Legacy Auth
        /// </summary>
        /// <returns></returns>
        public SymmetricSecurityKey CreateLegacyIssuerSigningKey()
        {            
            if (string.IsNullOrEmpty(LegacyClientSecret))
            {
                throw new NullReferenceException($"{ConfigurationRoot}:LegacyClientSecret is not configured in appsettings!");
            }
            var key = Convert.FromBase64String(LegacyClientSecret);
            return new SymmetricSecurityKey(key);
        }

        /// <summary>
        /// Creates the Token Validation parameters for Legacy Auth
        /// </summary>
        /// <returns></returns>
        public TokenValidationParameters CreateLegacyTokenValidationParameters()
        {
            if (string.IsNullOrEmpty(TokenIssuerV1))
            {
                throw new NullReferenceException($"{ConfigurationRoot}:TokenIssuerV1 is not configured in appsettings!");
            }
            
            if (string.IsNullOrEmpty(TokenIssuerV2))
            {
                throw new NullReferenceException($"{ConfigurationRoot}:TokenIssuerV2 is not configured in appsettings!");
            }

            if (string.IsNullOrEmpty(LegacyAudienceClientId))
            {
                throw new NullReferenceException($"{ConfigurationRoot}:LegacyAudienceClientId is not configured in appsettings!");
            }
            
            var issuerList = new List<string>()
            {
                TokenIssuerV1,
                TokenIssuerV2
            };
            
            return new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = CreateLegacyIssuerSigningKey(),
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidIssuers = issuerList,
                ValidAudiences = new[] { LegacyAudienceClientId }
            };
        }


        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(SecurityOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (options.ServerAuthMode == ServerAuthModes.LegacyAuth || options.ServerAuthMode == ServerAuthModes.Both)
            {
                if (string.IsNullOrEmpty(options.TokenIssuerV1))
                {
                    throw new Exception("SecurityOptions validation error: TokenIssuerV1 is required");
                }

                if (string.IsNullOrEmpty(options.TokenIssuerV2))
                {
                    throw new Exception("SecurityOptions validation error: TokenIssuerV2 is required");
                }

                if (string.IsNullOrEmpty(options.LegacyAudienceClientId))
                {
                    throw new Exception("SecurityOptions validation error: LegacyAudienceClientId is required");
                }

                if (string.IsNullOrEmpty(options.LegacyClientSecret))
                {
                    throw new Exception("SecurityOptions validation error: LegacyClientSecret is required");
                }
            }  

            if (options.ServerAuthMode == ServerAuthModes.IdentityServer || options.ServerAuthMode == ServerAuthModes.Both)        
            {
                if (string.IsNullOrEmpty(options.ApiSecret))
                {
                    throw new Exception("SecurityOptions validation error: ApiSecret is required");
                }                

                if (string.IsNullOrEmpty(options.Authority))
                {
                    throw new Exception($"SecurityOptions validation error: Authority is required, please check Interfaces setup for key {InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer} and BaseUrl");
                }  
            }

            if (string.IsNullOrEmpty(options.DataProtectionFolder))
            {
                throw new Exception("SecurityOptions validation error: DataProtectionFolder is required");
            }  

            if (options.DataProtectionKeyLifeTimeInDays <= 0)
            {
                throw new Exception("SecurityOptions validation error: DataProtectionKeyLifeTimeInDays is required and must be > 0");
            }         

            if (options.ServiceInternalIPWhitelist != null)
            {
                var parsedIp = options.ParseServiceInternalIpWhitelist();
                if (parsedIp == null)
                {
                    throw new Exception("SecurityOptions validation error: ServiceInternalIpWhitelist could not be parsed!");
                }

                if (options.ServiceInternalIPWhitelist.Count() != parsedIp.Count())
                {
                    throw new Exception("SecurityOptions validation error: Not all IPs from ServiceInternalIpWhitelist could be parsed!");
                }
            }

            return true;
        }

        public IEnumerable<ComplexIPAddress> ParseServiceInternalIpWhitelist()
        {
            if (ServiceInternalIPWhitelist == null)
            {
                return null;
            }
           
            var ipAdrSafeList = new List<ComplexIPAddress>();

            foreach(var ip in ServiceInternalIPWhitelist)
            { 
                var complex = new ComplexIPAddress(ip);
                ipAdrSafeList.Add(complex);              
            }
            
            return ipAdrSafeList;
        }
            
        #endregion
        
    }
}
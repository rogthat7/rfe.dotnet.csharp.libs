using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using IAZI.Common.Core.Interfaces.Web.Utils;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class ServiceOptions 
    {
        #region Constants

        public static readonly string ConfigurationRoot = "ServiceConfiguration";

        
        /// <summary>
        /// Required to retrieve Environment from Configuration for e.g. logging middleware because ServiceOptions
        /// cannot be injected
        /// </summary>
        public static readonly string ConfigurationEnvironment = ConfigurationRoot + ":Environment";
            
        #endregion
        
        #region Properties set via appsettings

        /// <summary>
        /// Base Path of service, if empty the service is available on root level
        /// </summary>
        /// <value></value>
        public string BasePath { get; set; } = string.Empty;

        /// <summary>
        /// Makes use of the custom  ProblemDetailsMiddleware to produce standardized about in case of issues
        /// </summary>
        /// <value></value>
        public bool EnableCustomProblemDetailsMiddleware { get; set; } = true;

        [Required]
        public DeployEnvironment Environment { get; set; } 
        
        /// <summary>
        /// Setting to true will initialize Automapper to map between domain and service models
        /// </summary>
        /// <value></value>
        public bool UseAutomapper { get; set; } = true;  

        /// <summary>
        /// Setting to true will enable the X-Fowarded Headers in the midleware
        /// see https://docs.microsoft.com/en-us/aspnet/core/host-and-deploy/proxy-load-balancer?view=aspnetcore-5.0
        /// </summary>
        /// <value></value>
        public bool UseForwardHeaders { get; set; } = true;                                               
                       
        public SecurityOptions Security { get; set; } = new SecurityOptions();

        public CultureOptions Culture { get; set; } = new CultureOptions();        

        public LoggingOptions Logging { get; set; } = new LoggingOptions();        

        public JsonOptions Json { get; set; } = new JsonOptions();        

        public SwaggerOptions Swagger { get; set; } = new SwaggerOptions();        

        public DataOptions Data { get; set; } = new DataOptions();      

        public AnalyticsOptions Analytics { get; set; } = new AnalyticsOptions();      

        public RateLimitingOptions RateLimiting { get; set; } = new RateLimitingOptions();    
        

        public Dictionary<string, ServiceInterface> Interfaces { get; set; } = new Dictionary<string, ServiceInterface>();
        
        #endregion            

        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(ServiceOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }     

            if (options.BasePath == null)      
            {
                options.BasePath = string.Empty;
            }

            return true;
        }

        public bool IsLocalEnvironment()
        {
            return Environment == DeployEnvironment.LOCAL;
        }

        public bool IsDevEnvironment()
        {
            return Environment == DeployEnvironment.DEV;
        }

        public bool IsIntEnvironment()
        {
            return Environment == DeployEnvironment.INT;
        }

        public bool IsTestEnvironment()
        {
            return Environment == DeployEnvironment.TEST;
        }

        public bool IsProdEnvironment()
        {
            return Environment == DeployEnvironment.PROD;
        }

         /// <summary>
        /// Info message about the service
        /// </summary>
        /// <value></value>
        public virtual string CreateServiceInfoMessage(IApplicationInfo applicationInfo)
        {              
            if (applicationInfo is null)
            {
                throw new ArgumentNullException(nameof(applicationInfo));
            }
            
            return $"{Security.ApiName}, Environment={Environment}, Addresses='{applicationInfo.ServerAddressList}', HostingEnvironment={applicationInfo.HostingEnvironment}, BasePath={BasePath}, HostName={applicationInfo.HostName}, Version={applicationInfo.Version}, VersionDate={applicationInfo.VersionDate}, TCBuildNumber={applicationInfo.TCBuildNumber}, GitHash={applicationInfo.GitHash}, DockerImageTag={applicationInfo.DockerImageTag}, RequestCulture={Culture.Default}, RequestCultureUI={Culture.DefaultUI}, Cultures='{string.Join(',', Culture.Supported)}', ContentRootPath={applicationInfo.ContentRootPath}, WebRootPath={applicationInfo.WebRootPath}, ServerAuthMode={Security.ServerAuthMode}";    
        }   

        public ServiceInterface GetServiceInterface(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException(nameof(key));
            }

            Interfaces.TryGetValue(key, out ServiceInterface serviceInterface);

            if (serviceInterface == null)
            {
                throw new Exception($"The service interface key {key} was not found in the current service interface collection, please check the appsettings.");
            }

            return serviceInterface;
        }     

        #endregion       
    }
}
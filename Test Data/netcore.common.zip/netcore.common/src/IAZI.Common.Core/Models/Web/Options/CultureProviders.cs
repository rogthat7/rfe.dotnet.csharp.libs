namespace IAZI.Common.Core.Models.Web.Options
{
    /// <summary>
    /// This enumeration controlls the culture providers applied in the framework
    /// </summary>
    public enum CultureProviderModes
    {
        // No culture providers will be applied, everything has to be controlled by the service itself
        Empty = 0,
        // In this mode it is said that the service e.g. is not used by a web application directly meaning any cookie based provider will be removed
        CoreService = 1,        
        // An appservice that is used by a web application should make use of cookie providers and all others
        AppService = 2        
    }
}
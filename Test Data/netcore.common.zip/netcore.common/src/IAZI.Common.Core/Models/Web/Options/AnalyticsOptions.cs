using System;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class AnalyticsOptions
    {        
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Analytics";        
     
        #endregion
        
        #region Properties
        
        /// <summary>
        /// Set to true to enable the middleware
        /// </summary>
        /// <value></value>
        public bool Enable { get; set; } 

        /// <summary>
        /// The Base url of the Analytics server
        /// </summary>
        /// <value></value>
        public string AnalyticsBaseUrl { get; set; } 

        /// <summary>
        /// The token to access the Analytics server
        /// </summary>
        /// <value></value>
        public string Token { get; set; } 

         /// <summary>
        /// The site identifier for the Analytics server
        /// </summary>
        /// <value></value>
        public int SiteId { get; set; } 

            
        #endregion      

        #region Public methods        
        
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(AnalyticsOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }   

            if (options.Enable)
            {
                if (string.IsNullOrEmpty(options.AnalyticsBaseUrl))
                {
                    throw new Exception($"AnalyticsOptions validation error: AnalyticsBaseUrl is required.");
                } 

                if (string.IsNullOrEmpty(options.Token))
                {
                    throw new Exception($"AnalyticsOptions validation error: Token is required.");
                }

                if (options.SiteId == 0)
                {
                    throw new Exception($"AnalyticsOptions validation error: SiteId is required.");
                }
            }

            return true;
        }
        
        #endregion
    }
}
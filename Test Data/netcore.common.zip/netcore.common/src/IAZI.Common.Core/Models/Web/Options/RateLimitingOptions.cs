using System;
using AspNetCoreRateLimit;
using IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class RateLimitingOptions
    {        
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":RateLimiting";        

        public static readonly string ConfigurationIpRateLimiting = ConfigurationRoot+":IpRateLimiting";        

        public static readonly string ConfigurationIpRateLimitPolicies = ConfigurationRoot+":IpRateLimitPolicies";        

        public static readonly string ConfigurationClientRateLimiting = ConfigurationRoot+":ClientRateLimiting";        

        public static readonly string ConfigurationClientRateLimitPolicies = ConfigurationRoot+":ClientRateLimitPolicies";        
     
        #endregion
        
        #region Properties

        /// <summary>
        /// Set flag to enable legacy based Rate limiting
        /// </summary>
        /// <value></value>
        public bool EnableLegacy { get; set; }

        /// <summary>
        /// Set flag to enable modern Rate limiting
        /// </summary>
        /// <value></value>
        public bool Enable { get; set; }
        
        public ThrottleData LegacyThrottling  { get; set; }    

        public IpRateLimitOptions IpRateLimiting { get; set; }

        public IpRateLimitPolicies IpRateLimitPolicies { get; set; }

        public ClientRateLimitOptions ClientRateLimiting { get; set; }

        public ClientRateLimitPolicies ClientRateLimitPolicies { get; set; }

        #endregion      

        #region Public methods        
        
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(RateLimitingOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }             

            return true;
        }
        
        #endregion
    }
}
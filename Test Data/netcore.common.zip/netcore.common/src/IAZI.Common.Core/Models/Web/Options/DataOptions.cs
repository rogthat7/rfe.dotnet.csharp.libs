using System;
using System.Collections.Generic;
using System.Data.Common;
using IAZI.Common.Core.Utils;
using StackExchange.Redis.Extensions.Core.Configuration;

namespace IAZI.Common.Core.Models.Web.Options
{   
    public class DataOptions
    {
        #region Constants

        private const string defaultConnectionName = "DefaultConnection";
        
        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Data";
            
        #endregion

        #region Properties

        public string DefaultConnectionName { get; set; } = defaultConnectionName;

        /// <summary>
        /// Will be filled based on actual Connection Strings from root config, so the default place is used here 
        /// </summary>
        /// <value></value>
        public Dictionary<string, string> ConnectionStrings { get; set; }

        /// <summary>
        /// If true Redis Cache should be activated
        /// </summary>
        /// <value></value>
        public bool EnableRedisCache { get; set; }

        /// <summary>
        /// Options to connect to Redis
        /// </summary>
        /// <value></value>
        public RedisOptions Redis { get; set; } = new RedisOptions();  

        #endregion

        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(DataOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }    

            return true;
        }  

        public string GetDbConnectionString(string connectionName = null)
        {
            if (connectionName == null)
            {
                connectionName = defaultConnectionName;
            }

            var dbConnection = EnvironmentExtensions.Get(connectionName);
            if (string.IsNullOrEmpty(dbConnection))
            {
                if (!ConnectionStrings.ContainsKey(connectionName))
                {
                    throw new Exception($"There's no DB connection defined for name {connectionName}");
                }

                dbConnection = ConnectionStrings[connectionName];
            }
            return dbConnection;
        }

        public void ExtractDatabaseInfoFromDbConnectionString(out string server, out string database, string connectionName = null)
        {
            server = string.Empty;
            database = string.Empty;
            var connectionString = GetDbConnectionString(connectionName);
            if (string.IsNullOrEmpty(connectionString))
            {
                return;
            }

            var builder = new DbConnectionStringBuilder();
            builder.ConnectionString = connectionString;

            if (builder.ContainsKey("server"))
            {
                server = builder["server"] as string;
            }
            
            if (builder.ContainsKey("database"))
            {
                database = builder["database"] as string;
            }            
        }
     
        #endregion     
        
    }
}
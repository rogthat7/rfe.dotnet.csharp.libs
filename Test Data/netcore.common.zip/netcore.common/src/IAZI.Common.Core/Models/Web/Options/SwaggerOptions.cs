using System;
using System.Reflection;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class SwaggerOptions
    {        
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Swagger";        


        #endregion
        
        #region Properties

         /// <summary>
        /// Set to true in order to create also a Swagger UI page for the service
        /// Should be removed once a central SwaggerUI application is available
        /// </summary>
        /// <value></value>
        public bool UseSwaggerUI { get; set; } = true;

        /// <summary>
        /// If true an option to login to the service via IdentityServer/Service.Auth (Depending on ServerAuthMode) will be enabled
        /// If ServerAuthMode is None setting this to true doesn't have any impact
        /// </summary>
        /// <value></value>
        public bool UseSwaggerUIAuth { get; set; } = true;

        /// <summary>
        /// Set the index stream to be used for SwaggerUI (Stream function for retrieving the swagger-ui page)
        /// </summary>
        /// <value></value>
        public string SwaggerUIIndexStream { get; set; }
               
        /// <summary>
        /// Configures Swagger UI to prevent the enums to be shown in the bottom model list again
        /// </summary>
        /// <value></value>
        public bool UseInlineDefinitionsForEnums { get; set; } = true;

        /// <summary>
        /// when set to true all endpoints in Swagger will get an extra X-Culture header, only makes sense if the service also uses the X-CultureCultureProvider
        /// </summary>
        /// <value></value>
        public bool ApplyXCultureHeader { get; set; }

        /// <summary>
        /// when set to true all endpoints in Swagger will get an extra X-CustomerId header
        /// </summary>
        /// <value></value>
        public bool ApplyXCustomerIdHeader { get; set; }

        /// <summary>
        /// when set to true all endpoints in Swagger will get an extra X-Application header
        /// </summary>
        /// <value></value>
        public bool ApplyXApplicationHeader { get; set; }
               
        /// <summary>
        /// Set this flag to use HideInternalEndpointsIpWhitelist to hide internal endpoints in Swagger
        /// </summary>
        /// <value></value>
        public bool UseHideInternalEndpoints { get; set; } = true;        

        #endregion

        #region Constructor

        public SwaggerOptions()
        {
            // The wwwroot content is accessible in the executing assembly which we set as a default
            var executingAssemblyName = Assembly.GetEntryAssembly().GetName().Name;
            SwaggerUIIndexStream = executingAssemblyName + ".wwwroot.swaggerindex.html";
        }
            
        #endregion

        #region Public methods
       
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(SwaggerOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }               

            return true;
        }
        
        #endregion
    }
}
using System;
using StackExchange.Redis.Extensions.Core.Configuration;

namespace IAZI.Common.Core.Models.Web.Options
{
    /// <summary>
    /// Redis Configuration options based on original StackExchange.Redis.ConfigurationOptions properties
    /// </summary>
    public class RedisOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = DataOptions.ConfigurationRoot+":Redis";
            
        #endregion

        #region Enum

        public enum SerializerType
        {
            Json = 0,
            GzipJson = 1,
            ProtoBuf = 2
        }
            
        #endregion
        
        #region Properties

        /// <summary>
        /// If true a middleware will be added to provided redis related endpoints
        /// </summary>
        /// <value></value>
        public bool EnableRedisInformationMiddleware { get; set; }

        /// <summary>
        /// Serializer type
        /// </summary>
        /// <value></value>
        public SerializerType Serializer { get; set; } = SerializerType.Json;

        /// <summary>
        /// Options to connect to Redis
        /// </summary>
        /// <value></value>
        public RedisConfiguration Config { get; set; } = new RedisConfiguration();  
            
        #endregion
        
        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(RedisOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }    

            return true;
        }  

        public string GetRedisPrefixKey(string serviceApiName)
        {
            var keyPrefix = serviceApiName != null ? serviceApiName.Replace("IAZI.Service.", string.Empty) : string.Empty;
            
            return $"{keyPrefix}|";
        }

        #endregion
    } 
}
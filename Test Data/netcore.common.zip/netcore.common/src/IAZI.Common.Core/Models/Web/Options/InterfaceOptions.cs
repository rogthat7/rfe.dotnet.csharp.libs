using System;
using System.Collections.Generic;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Core.Models.Web.Options
{
    /// <summary>
    /// Since Interface Options are made available via a Dictionary, this class only contains
    /// some constants and static methods for validation 
    /// </summary>
    public sealed class InterfaceOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Interfaces";

        public static readonly string InterfaceOptionKeyServiceAuthIdentityServer = "Service.Auth.IdentityServer";

        public static readonly string InterfaceOptionKeyIAZISwagger = "IAZI.Swagger";        

        public static readonly string InterfaceOptionKeyWebPortal = "Web.AppPortal"; 
            
        #endregion

        #region Properties
       
        #endregion

        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(Dictionary<string, ServiceInterface> interfaces, ServerAuthModes serverAuthMode, bool useSwaggerUIAuth)
        {
            if (interfaces is null)
            {
                throw new ArgumentNullException(nameof(interfaces));
            } 

            foreach (var item in interfaces)
            {
                if (item.Value == null)
                {
                    throw new Exception($"InterfaceOptions validation error: ServiceInterface was null for key {item.Key}");
                }  

                if (string.IsNullOrEmpty(item.Value.Name))
                {
                    throw new Exception($"InterfaceOptions validation error: A name is required for key {item.Key}");
                }  

                if (item.Value.AuthMode == ClientAuthModes.LegacyAuth)       
                {
                    if (string.IsNullOrEmpty(item.Value.AuthAppName))
                    {
                        throw new Exception($"InterfaceOptions validation error: A AuthAppName is required for key {item.Key} because AuthMode=LegacyAuth");
                    } 

                    if (item.Value.LegacyAuthMode == LegacyAuthModes.Credentials)
                    {
                        if (string.IsNullOrEmpty(item.Value.LegacyAuthUserName))
                        {
                            throw new Exception($"InterfaceOptions validation error: A LegacyAuthUserName is required for key {item.Key} because LegacyAuthModes=Credentials");
                        }  

                        if (string.IsNullOrEmpty(item.Value.LegacyAuthPassword))
                        {
                            throw new Exception($"InterfaceOptions validation error: A LegacyAuthPassword is required for key {item.Key} because LegacyAuthModes=Credentials");
                        }                        
                    }
                }
            }   

            if (serverAuthMode == ServerAuthModes.Both
                || serverAuthMode == ServerAuthModes.IdentityServer)
            {
                if (!interfaces.TryGetValue(InterfaceOptionKeyServiceAuthIdentityServer, out ServiceInterface serviceInterface))
                {
                    throw new Exception($"InterfaceOptions validation error: Because of the given ServerAuthMode ({serverAuthMode}) you need to specify the interface for {InterfaceOptionKeyServiceAuthIdentityServer}");
                }

                if (string.IsNullOrEmpty(serviceInterface.BaseUrl))
                {
                    throw new Exception($"InterfaceOptions validation error: Because of the given ServerAuthMode ({serverAuthMode}) you need to specify the BaseUrl for the interface {InterfaceOptionKeyServiceAuthIdentityServer}");
                }
            }

            if (useSwaggerUIAuth && serverAuthMode != ServerAuthModes.None)
            {
                if (!interfaces.TryGetValue(InterfaceOptionKeyIAZISwagger, out ServiceInterface serviceInterface))
                {
                    throw new Exception($"InterfaceOptions validation error: Because of the given ServerAuthMode ({serverAuthMode}) and the flag useSwaggerUIAuth={useSwaggerUIAuth} you need to specify the interface for {InterfaceOptionKeyIAZISwagger}");
                }                
            }            

            return true;
        }  
     
        #endregion 
    }
}
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Core.Models.Web.Options
{
    /// <summary>
    /// entity describes an external service interface the current service should connect to
    /// </summary>
    public class ServiceInterface
    {
        #region Properties
       
        /// <summary>
        /// Name of service interface, normally the one defined in IDSRV, e.g. IAZI.Service.AuthQlikSense
        /// </summary>
        /// <value></value>
        public string Name { get; set; }

        /// <summary>
        /// Base url to service, e.g. https://dev.iazi.ch/api/authqliksense
        /// </summary>
        /// <value></value>
        public string BaseUrl { get; set; }

        /// <summary>
        /// The Auth Mode the current service should use to connect to the service interface
        /// </summary>
        /// <value></value>
        public ClientAuthModes AuthMode { get; set; } = ClientAuthModes.IdentityServer;

        /// <summary>
        /// Sets the legacy auth mode of the interface connection
        /// Default is Token which requires a portal token to request the app token
        /// When set to Credentials the properties LegacyAuthUserName + LegacyAuthPassword are required
        /// </summary>
        /// <value></value>
        public LegacyAuthModes LegacyAuthMode { get; set; } = LegacyAuthModes.Token;


        /// <summary>
        /// Sets the desired grant type for the communication with the service
        /// </summary>
        /// <value></value>
        public GrantTypeModes GrantType { get; set; } = GrantTypeModes.ClientCredentials;

        /// <summary>
        /// Auth app name for legacy Auth mode, e.g. 'qliksense'
        /// </summary>
        /// <value></value>
        public string AuthAppName { get; set; }

        /// <summary>
        /// Username to request a service app token in Legacy Auth Mode with type Credentials
        /// </summary>
        /// <value></value>
        public string LegacyAuthUserName { get; set; }

        /// <summary>
        /// Passoword to request a service app token in Legacy Auth Mode with type Credentials
        /// </summary>
        /// <value></value>
        public string LegacyAuthPassword { get; set; }
            
        #endregion
    }
}
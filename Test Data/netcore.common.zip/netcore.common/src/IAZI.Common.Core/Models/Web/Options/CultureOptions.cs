using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using IAZI.Common.Core.Models.Resources;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class CultureOptions
    {        
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Culture";        

        public const string DefaultEnglishCulture = "en-US";
        public const string DefaultGermanCulture = "de-CH";
        public const string DefaultFrenchCulture = "fr-CH";
        public const string DefaultItalianCulture = "it-CH";
            
        #endregion
        
        #region Properties

        /// <summary>
        /// Supported cultures
        /// Default values are all Cultures from above, we cannot set them here 
        /// because otherwise the values set by configuration would be added on top of the default list
        /// so the defaults are set in the postconfiguration in StartupBase
        /// </summary>
        /// <value></value>
        [Required]
        [MinLength(1)]
        public List<string> Supported { get; set; } = new List<string>();

        /// <summary>
        /// Default Request Culture
        /// </summary>
        /// <value></value>
        [Required]
        public string Default { get; set; } = DefaultEnglishCulture;

        /// <summary>
        /// Default Request UI Culture
        /// </summary>
        /// <value></value>
        [Required]
        public string DefaultUI { get; set; } = DefaultEnglishCulture;

        /// <summary>
        /// Reference to the Resource class containing translations
        /// </summary>
        /// <value></value>
        public string ResourceClass { get; set; } 

        public CultureProviderModes ProviderMode { get; set; } = CultureProviderModes.AppService;               
            
        #endregion       

        #region Public methods

        
        public IList<CultureInfo> SupportedCultures
        {
            get
            {
                return Supported?.Select(c => new CultureInfo(c)).ToList();
            }
        }

        public CultureInfo DefaultRequestCulture
        {
            get
            {
                return new CultureInfo(Default);
            }
        }

        public CultureInfo DefaultRequestUICulture
        {
            get
            {
                return new CultureInfo(DefaultUI);
            }
        }

        private Type _resourceType;
        public Type ResourceType 
        { 
            get
            {
                if (!string.IsNullOrEmpty(ResourceClass))
                {
                    return Type.GetType(ResourceClass, true, true);
                }                
                else if (_resourceType != null)
                {
                    return _resourceType;
                }
                else
                {
                    return typeof(DefaultResource);        
                }
            }
            set
            {
                _resourceType = value;
            }
        } 
        
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(CultureOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }   

            return true;
        }
        
        #endregion
    }
}
namespace IAZI.Common.Core.Models.Web.Options
{
    /// <summary>
    /// The class is for handling the custom configuration of the app/service
    /// This class should contain the properties that cannot be made available in the shared library and that 
    /// are app/service specific. Via the Options pattern, this class will be made available via the 
    /// ServiceConfiguration to avoid that the entire IConfiguration needs to be passed around.
    /// The custom settings need to be within the main ServiceConfguration section called 'CustomConfiguration'
    /// </summary>
    /// <value></value>
    public class CustomServiceOptions<T> : ServiceOptions where T: CustomOptions
    {
         public T Custom { get; set; } = default(T);   
    }
}
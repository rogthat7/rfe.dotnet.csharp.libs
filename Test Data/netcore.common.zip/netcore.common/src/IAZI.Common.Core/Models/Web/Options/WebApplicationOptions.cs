using System;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class WebApplicationOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = "WebApplication";
            
        #endregion
        
        #region Properties

        public string ErrorPage { get; set; }

        public string StatusCodePage { get; set; }

        public bool EnableCookiePolicy { get; set; } = true;

        public bool UseRazorPages { get; set; } = true;

        public bool UseControllerViews { get; set; } = true;

        /// <summary>
        /// If set to true Swagger will also be initialized for the WebApplication (maybe there are also APIs), default is false
        /// </summary>
        /// <value></value>
        public bool UseSwagger { get; set; } = false;

        public bool EnableAuthorization { get; set; } = true;

        #endregion

        #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        public static bool ValidateSettings(WebApplicationOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }            

            return true;
        }
            
        #endregion
    }
}
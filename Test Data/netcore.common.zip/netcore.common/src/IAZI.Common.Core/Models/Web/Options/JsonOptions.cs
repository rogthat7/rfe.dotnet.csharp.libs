using System;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using IAZI.Common.Core.Models.Web.Converter;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class JsonOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Json";
            
        #endregion
        
        #region Properties

        //
        // Summary:
        //     Get or sets a value that indicates whether an extra comma at the end of a list
        //     of JSON values in an object or array is allowed (and ignored) within the JSON
        //     payload being deserialized.
        //
        // Returns:
        //     true if an extra comma at the end of a list of JSON values in an object or array
        //     is allowed (and ignored); false otherwise.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     This property was set after serialization or deserialization has occurred.
        public bool AllowTrailingCommas { get; set; } = false;             
       
        //
        // Summary:
        //     Gets or sets a value that determines whether null values are ignored during serialization
        //     and deserialization. The default value is false.
        //
        // Returns:
        //     true to ignore null values during serialization and deserialization; otherwise,
        //     see langword="false" />.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     This property was set after serialization or deserialization has occurred.
        public bool IgnoreNullValues { get; set; } = true;
        //
        // Summary:
        //     Gets a value that determines whether read-only properties are ignored during
        //     serialization. The default value is false.
        //
        // Returns:
        //     true to ignore read-only properties during serialization; otherwise, false.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     This property was set after serialization or deserialization has occurred.
        public bool IgnoreReadOnlyProperties { get; set; } = false;    
        
        //
        // Summary:
        //     Gets or sets a value that determines whether a property's name uses a case-insensitive
        //     comparison during deserialization. The default value is false.
        //
        // Returns:
        //     true to compare property names using case-insensitive comparison; otherwise,
        //     false.
        public bool PropertyNameCaseInsensitive { get; set; } = true;

        //
        // Summary:
        //     Gets or sets a value that specifies the policy used to convert a property's name
        //     on an object to another format, such as camel-casing, or null to leave property
        //     names unchanged.
        //
        // Returns:
        //     A property naming policy, or null to leave property names unchanged.
        public bool UsePropertyNamingPolicyCamelCase { get; set; } = true;
      
        //
        // Summary:
        //     Gets or sets a value that defines whether JSON should use pretty printing. By
        //     default, JSON is serialized without any extra white space.
        //
        // Returns:
        //     true if JSON should pretty print on serialization; otherwise, false. The default
        //     is false.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     This property was set after serialization or deserialization has occurred.
        public bool WriteIndented { get; set; } = false;

        /// <summary>
        /// If true the JsonStringEnumConverter will be added to the options to use enum names instead of the int values
        /// </summary>
        /// <value></value>
        public bool UseJsonStringEnumConverter { get; set; } = true;

        /// <summary>
        /// If true the CustomBooleanJsonConverter will be added to the options to use int values 1/0 along with of true/false (both is supported, but no strings)
        /// </summary>
        /// <value></value>
        public bool UseJsonCustomBoolConverter { get; set; } = false;
     
        /// <summary>
        /// setting this to true will ensure compatibility with Newtonsoft.Json serialization
        /// which converts e.g. quotation marks as \" rather than \u0022.
        /// This will also return correctly all German Umlaute like ä,ö,ü
        /// Via the Encoder option it could be possible to set a precise Encoding but escape HTML-sensitive characters such as <, > will be encoded anyway
        /// So if the service requires to return those characters there's no other option than setting this flag
        /// Newtonsoft.Json always returned text without encoding
        /// see: https://docs.microsoft.com/en-us/dotnet/api/system.text.encodings.web.javascriptencoder.unsaferelaxedjsonescaping?view=netcore-3.1
        /// also: https://docs.microsoft.com/en-us/dotnet/standard/serialization/system-text-json-how-to#serialize-all-characters
        /// </summary>
        /// <value></value>
        public bool UseRelaxedEncoding { get; set; } = true;        

        private JsonSerializerOptions _jsonSerializerOptions;
            
        #endregion

        #region Public methods

        public void ApplyJsonSettings(JsonSerializerOptions targetOptions)
        {
            if (targetOptions is null)
            {
                throw new ArgumentNullException(nameof(targetOptions));
            }

            targetOptions.AllowTrailingCommas = AllowTrailingCommas;
            targetOptions.IgnoreNullValues = IgnoreNullValues;
            targetOptions.IgnoreReadOnlyProperties = IgnoreReadOnlyProperties;
            targetOptions.PropertyNameCaseInsensitive = PropertyNameCaseInsensitive;
            targetOptions.WriteIndented = WriteIndented;
            targetOptions.Encoder = UseRelaxedEncoding ? JavaScriptEncoder.UnsafeRelaxedJsonEscaping : JavaScriptEncoder.Default;                                                               
            
            if (UsePropertyNamingPolicyCamelCase)
            {
                targetOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            }
            
            if (UseJsonStringEnumConverter)
            {
                targetOptions.Converters.Add(new JsonStringEnumConverter());     
            }  

            if (UseJsonCustomBoolConverter)            
            {
                targetOptions.Converters.Add(new CustomBooleanJsonConverter());     
            }
        }
        
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(JsonOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }            

            return true;
        }
       
        /// <summary>
        /// Creates default settings for Json serializer based on configuration
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        public JsonSerializerOptions CreateJsonSerializerOptions(bool forceRefresh = false)
        {
            if (_jsonSerializerOptions == null || forceRefresh)
            {                               
                _jsonSerializerOptions = new JsonSerializerOptions
                {
                    AllowTrailingCommas = AllowTrailingCommas,
                    IgnoreNullValues = IgnoreNullValues,
                    IgnoreReadOnlyProperties = IgnoreReadOnlyProperties,                
                    PropertyNameCaseInsensitive = PropertyNameCaseInsensitive,                    
                    WriteIndented = WriteIndented,                    
                    Encoder = UseRelaxedEncoding ? JavaScriptEncoder.UnsafeRelaxedJsonEscaping : JavaScriptEncoder.Default,                                                                
                };

                if (UsePropertyNamingPolicyCamelCase)
                {
                    _jsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                }
                
                if (UseJsonStringEnumConverter)
                {
                    _jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());     
                }      

                if (UseJsonCustomBoolConverter)            
                {
                    _jsonSerializerOptions.Converters.Add(new CustomBooleanJsonConverter());     
                }
            }

            return _jsonSerializerOptions;             
        }
            
        #endregion
    }
}
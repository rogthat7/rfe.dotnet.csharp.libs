using System;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class CustomOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Custom";
            
        #endregion

         #region Public methods

        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(CustomOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }                 

            return true;
        }  
     
        #endregion     
        
    }
}
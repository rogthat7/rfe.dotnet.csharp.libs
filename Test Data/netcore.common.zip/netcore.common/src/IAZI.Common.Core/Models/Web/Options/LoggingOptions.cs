using System;

namespace IAZI.Common.Core.Models.Web.Options
{
    public class LoggingOptions
    {
        #region Constants

        public static readonly string ConfigurationRoot = ServiceOptions.ConfigurationRoot+":Logging";
            
        #endregion
        
        #region Properties

        /// <summary>
        /// Enable Request logging, true by default
        /// </summary>
        /// <value></value>
        public bool UseSerilogRequestLoggging { get; set; } = true;

        /// <summary>
        /// Enable UserInfo details injection into logs, true by default
        /// </summary>
        /// <value></value>
        public bool UseSerilogUserInfoLogging { get; set; } = true; 
        
        /// <summary>
        /// Flag which indicates whether or not PII (Personally Identifiable Information) is shown in logs. False by default.
        /// </summary>
        /// <value></value>
        public bool ShowPII { get; set; } = false;     
            
        #endregion

        #region Public methods
        
        /// <summary>
        /// Is used to validate the settings when options are constructed
        /// </summary>
        public static bool ValidateSettings(LoggingOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }            

            return true;
        }
            
        #endregion
    }
}
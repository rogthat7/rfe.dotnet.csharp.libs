namespace IAZI.Common.Core.Models.Web.Init
{
    public abstract class RootStartupBase
    {
    }
}
namespace IAZI.Common.Core.Models.Web.Init
{
    public class CSPExcludedEndpoint
    {
        #region Enums

        public enum ComparisonModeEnum
        {
            Equals = 0,
            StartsWith = 1
        }

        /// <summary>
        /// Replace = Replaces existing CSP with the Custom one, please bear in mind that the order of the middleware can have an impact on the availability of already available CSPs
        /// Append = Instead of replacing, simply add the AlternativeCSP to the existing CSP   
        /// AddAdditional = Keeps the existin CSP and adds an additional one, check https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy and section "Multiple content security policies"        
        /// </summary>
        public enum ActionModeEnum
        {
            Replace = 0,
            Append = 1,
            AddAdditional = 2
        }

        #endregion    
        
        #region Properties

        /// <summary>
        /// name of the relative path
        /// </summary>
        /// <value></value>
        public string Name 
        {
            get; set;
        }

        /// <summary>
        /// Former "Mode" Property to express comparison style of incoming end points
        /// </summary>
        /// <value></value>
        public ComparisonModeEnum ComparisonMode 
        {
            get; set;
        }

        /// <summary>
        /// Decide what to do with the endpoint exception
        /// </summary>
        /// <value></value>
        public ActionModeEnum ActionMode 
        {
            get; set;
        }       

        /// <summary>
        /// In case there's a third party library creating a CSP header anyway (like in Identity Server)
        /// This flag will skip the additional CSP Report Only header creation
        /// </summary>
        /// <value></value>
        public bool SkipReportOnlyCSP 
        {
            get; set; 
        }     

        /// <summary>
        ///  If set to true the added endpoint will be always treated like in non-DEV environments (so not working always with report-only CSP)
        /// </summary>
        /// <value></value>
        public bool UseNonReportOnlyCSPInDEV
        {
            get; set; 
        }   

        /// <summary>
        /// Set this to work as alternativeCSP
        /// </summary>
        /// <value></value>
        public string CustomCSP 
        {
            get; set;
        }

        /// <summary>
        /// if set it will be used for development purposes only
        /// </summary>
        /// <value></value>
        public string CustomCSPLocalDev
        {
            get; set;
        }

        /// <summary>
        /// if set the x-frame-options: SAMEORIGIN that is normally the default can be replaced
        /// </summary>
        /// <value></value>
        public string CustomXFrameOption
        {
            get; set;
        }

         /// <summary>
         /// if set the x-frame-options: SAMEORIGIN that is normally the default can be replaced for DEV purposes
         /// </summary>
         /// <value></value>
        public string CustomXFrameOptionLocalDev
        {
            get; set;
        }

        /// <summary>
        /// If set, the default XFrame Options header will be removed without having to set any replacement
        /// </summary>
        /// <value></value>
        public bool RemoveXFrameOptionsHeader
        {
             get; set;
        }

        #endregion
    }
}
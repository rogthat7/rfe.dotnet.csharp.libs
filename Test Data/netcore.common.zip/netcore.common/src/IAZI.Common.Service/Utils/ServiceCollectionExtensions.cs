using System;
using System.Collections.Generic;
using System.Linq;
using IAZI.Common.Core.Interfaces.Services.Utils;
using Microsoft.Extensions.DependencyInjection;

namespace IAZI.Common.Service.Utils
{
    public static class ServiceCollectionExtensions
    {
       #region Public methods 
        
        public static IServiceCollection ReplaceService<TService, TImplementation>(this IServiceCollection services)
            where TImplementation : TService
        {
            return services.ReplaceService<TService>(typeof(TImplementation));
        }

        public static IServiceCollection ReplaceService<TService>(this IServiceCollection services, Type implementationType)
        {
            return services.ReplaceService(typeof(TService), implementationType);
        }

        public static IServiceCollection ReplaceService(this IServiceCollection services, Type serviceType, Type implementationType)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (serviceType == null)
            {
                throw new ArgumentNullException(nameof(serviceType));
            }

            if (implementationType == null)
            {
                throw new ArgumentNullException(nameof(implementationType));
            }

            if (!services.TryGetDescriptors(serviceType, out var descriptors))
            {
                throw new ArgumentException($"No services found for {serviceType.FullName}.", nameof(serviceType));
            }

            foreach (var descriptor in descriptors)
            {
                var index = services.IndexOf(descriptor);

                services.Insert(index, descriptor.WithImplementationType(implementationType));

                services.Remove(descriptor);
            }

            return services;
        }

        public static IServiceCollection AddStartupTask<T>(this IServiceCollection services) where T : class, IStartupTask
                => services.AddTransient<IStartupTask, T>();

        #endregion
        
        #region Private methods  

        private static bool TryGetDescriptors(this IServiceCollection services, Type serviceType, out ICollection<ServiceDescriptor> descriptors)
        {
            return (descriptors = services.Where(service => service.ServiceType == serviceType).ToArray()).Any();
        }

        private static ServiceDescriptor WithImplementationType(this ServiceDescriptor descriptor, Type implementationType)
        {
            return new ServiceDescriptor(descriptor.ServiceType, implementationType, descriptor.Lifetime);
        }

        #endregion         
    }
}
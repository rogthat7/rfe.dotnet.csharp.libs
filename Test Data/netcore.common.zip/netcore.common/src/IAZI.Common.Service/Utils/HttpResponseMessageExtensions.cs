using System;
using System.Net.Http;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Utils
{
    public static class HttpResponseMessageExtensions
    {
        /// <summary>
        /// Problem with original EnsureSuccessStatusCode method is that is throws an Exception with just a text containing the status code
        /// This method will throw a derived exception with the status code attached. This can be used to e.g. forward a 401 error of a call inside
        /// a service to another service to a client. Otherwise the client will just get a 500 error.
        /// </summary>
        /// <param name="responseMessage"></param>
        /// <returns></returns>
        public static async Task<(HttpResponseMessage response, ProblemDetailsDto problemDetails)> EnsureSuccessStatusCodeWithStatusCodeException(this HttpResponseMessage responseMessage, IJsonFacade jsonFacade, JsonOptions jsonOptions)
        {
            ProblemDetailsDto problemDetails = null;
            if (!responseMessage.IsSuccessStatusCode)
            {
                // Disposing the content should help users: If users call EnsureSuccessStatusCode(), an exception is
                // thrown if the response status code is != 2xx. I.e. the behavior is similar to a failed request (e.g.
                // connection failure). Users don't expect to dispose the content in this case: If an exception is 
                // thrown, the object is responsible fore cleaning up its state.
                if (responseMessage.Content != null)
                {
                    var mediaType = responseMessage.Content.Headers?.ContentType?.MediaType;
                    if (!string.IsNullOrEmpty(mediaType) && mediaType.Contains("application/problem+", StringComparison.InvariantCultureIgnoreCase))
                    {
                        try
                        {
                            problemDetails = await responseMessage.Content.ReadAsAsync<ProblemDetailsDto>(jsonFacade, jsonOptions);    
                        }
                        finally
                        {
                            // Don't do anything here, ProblemDetails was not in right form so continue and throw exception without further details
                        }                        
                    }                                       
                    else
                    {
                        responseMessage.Content.Dispose();
                    }                    
                } 

                if (problemDetails == null)
                {
                    var statusCode = (int)responseMessage.StatusCode;

                    throw new IAZIHttpRequestException(string.Format(System.Globalization.CultureInfo.InvariantCulture, "Response status code does not indicate success: {0} ({1}).", statusCode,
                        responseMessage.ReasonPhrase), true, statusCode);
                }                
            }
            return (responseMessage, problemDetails);
        }
    }
}
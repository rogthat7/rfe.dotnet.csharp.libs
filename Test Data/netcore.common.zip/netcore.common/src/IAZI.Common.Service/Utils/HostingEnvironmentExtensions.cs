using IAZI.Common.Core.Models.Utils;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace IAZI.Common.Service.Utils
{
    public static class HostingEnvironmentExtensions
    {
        public static bool IsTesting(this IWebHostEnvironment hostingEnvironment)
        {
            return hostingEnvironment.IsEnvironment(ApplicationInfo.EnvironmentTesting);
        }      
    }
}
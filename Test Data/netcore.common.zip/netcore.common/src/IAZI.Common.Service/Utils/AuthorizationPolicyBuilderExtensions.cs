using IAZI.Common.Service.Web.Controllers.Shared;
using Microsoft.AspNetCore.Authorization;

namespace IAZI.Common.Service.Utils
{
    public static class AuthorizationPolicyBuilderExtensions
    {
        public static AuthorizationPolicyBuilder RequireServiceAuthorization(this AuthorizationPolicyBuilder builder)
        {
            return builder.AddRequirements(new ServiceAuthorizationRequirement());
        }
    }
}
using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;

namespace IAZI.Common.Service.Utils
{
    public static class CertificateHelper
    {        
        /// <summary>
        /// Lookup for a certificate inside Cert Store by Thumbprint
        /// </summary>
        /// <param name="certThumbPrint"></param>
        /// <param name="storeLocation"></param>
        /// <returns></returns>
        public static X509Certificate2 LookUpCertificateInCertStore(string certThumbPrint, StoreLocation storeLocation = StoreLocation.LocalMachine)
        {
            if (string.IsNullOrEmpty(certThumbPrint))
            {
                throw new ArgumentNullException(nameof(certThumbPrint));
            }

            using (X509Store certStore = new X509Store(StoreName.My, storeLocation, OpenFlags.ReadOnly))
            {
                var certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, certThumbPrint, false);                
                if (certCollection == null || certCollection.Count == 0)
                {
                    throw new Exception($"Certificate with Thumbprint {certThumbPrint} was not found in Cert Store with location {storeLocation}!");
                }
                return certCollection[0];
            }
        }

        /// <summary>
        /// Removes spaces and also the mean hidden character in front of a certificate thumbprint string which often is added
        /// accidentally when copy+paste it from the Windows cert thumbprint view
        /// </summary>
        /// <param name="certThumbPrint"></param>
        /// <returns></returns>
        public static string SafelyConvertCertThumbprint(string certThumbPrint)
        {
            if (string.IsNullOrEmpty(certThumbPrint))
            {
                throw new ArgumentNullException(nameof(certThumbPrint));
            }

            return certThumbPrint.Replace("\u200e", string.Empty).Replace("\u200f", string.Empty).Replace(" ",string.Empty);                        
        }

        public static X509Certificate2 CreateCertFromString(string cert)
        {
             if (string.IsNullOrEmpty(cert))
             {
                 throw new ArgumentNullException(nameof(cert));
             }

            // var bytes = Encoding.ASCII.GetBytes(res); // doesn't work on Ubuntu 16.04
                    
             var certificateWithoutHeaderAndFooter = cert
                        .Replace("\\n","")
                        .Replace("-----BEGIN CERTIFICATE-----", "") 
                        .Replace("-----END CERTIFICATE-----", "");
                    var certificateBytes = Convert.FromBase64String(certificateWithoutHeaderAndFooter);
            return new X509Certificate2(certificateBytes);
        }       

        /// <summary>
        /// Loads a certificate based on a passed path to a file
        /// </summary>
        /// <param name="cerFile">full path of cer certificate file</param>
        /// <param name="keyFile">full path of key certificate file, is optional</param>
        /// <returns>X509Certificate2</returns>
        public static X509Certificate2 LoadCertificateFromFiles(string cerFile, string keyFile)
        {
            if (string.IsNullOrEmpty(cerFile))
            {
                throw new ArgumentNullException(nameof(cerFile));
            }    

            if (string.IsNullOrEmpty(keyFile))
            {
                throw new ArgumentNullException(nameof(keyFile));
            }         

            if (!File.Exists(cerFile))
            {
                throw new FileNotFoundException($"The certificate key file expected at {cerFile} doesn't exist");
            }

            if (!string.IsNullOrEmpty(keyFile) && !File.Exists(keyFile))
            {
                throw new FileNotFoundException($"The certificate key file expected at {keyFile} doesn't exist");
            }

            var cert = new X509Certificate2(cerFile);
            var privateKey = PrivateKeyFromPemFile(keyFile);           
            return cert.CopyWithPrivateKey(privateKey);          
        }

        // New based on https://dejanstojanovic.net/aspnet/2018/june/loading-rsa-key-pair-from-pem-files-in-net-core-with-c/

        public static void GenerateRsaKeyPair(string privateKeyFilePath, string publicKeyFilePath)  
        {  
            RsaKeyPairGenerator rsaGenerator = new RsaKeyPairGenerator();  
            rsaGenerator.Init(new KeyGenerationParameters(new SecureRandom(), 2048));  
            var keyPair = rsaGenerator.GenerateKeyPair();  
                
            using (TextWriter privateKeyTextWriter = new StringWriter())  
            {          
                PemWriter pemWriter = new PemWriter(privateKeyTextWriter);  
                pemWriter.WriteObject(keyPair.Private);  
                pemWriter.Writer.Flush();  
                File.WriteAllText(privateKeyFilePath, privateKeyTextWriter.ToString());  
            }  
        
            using (TextWriter publicKeyTextWriter = new StringWriter())  
            {          
                PemWriter pemWriter = new PemWriter(publicKeyTextWriter);  
                pemWriter.WriteObject(keyPair.Public);  
                pemWriter.Writer.Flush();  
        
                File.WriteAllText(publicKeyFilePath, publicKeyTextWriter.ToString());  
            }  
        }

        public static RSACryptoServiceProvider PrivateKeyFromPemFile(string filePath)  
        {  
            using (TextReader privateKeyTextReader = new StringReader(File.ReadAllText(filePath)))  
            {  
                AsymmetricCipherKeyPair readKeyPair = (AsymmetricCipherKeyPair)new PemReader(privateKeyTextReader).ReadObject();  
        
        
                RsaPrivateCrtKeyParameters privateKeyParams = ((RsaPrivateCrtKeyParameters)readKeyPair.Private);  
                RSACryptoServiceProvider cryptoServiceProvider = new RSACryptoServiceProvider();  
                RSAParameters parms = new RSAParameters();  
        
                parms.Modulus = privateKeyParams.Modulus.ToByteArrayUnsigned();  
                parms.P = privateKeyParams.P.ToByteArrayUnsigned();  
                parms.Q = privateKeyParams.Q.ToByteArrayUnsigned();  
                parms.DP = privateKeyParams.DP.ToByteArrayUnsigned();  
                parms.DQ = privateKeyParams.DQ.ToByteArrayUnsigned();  
                parms.InverseQ = privateKeyParams.QInv.ToByteArrayUnsigned();  
                parms.D = privateKeyParams.Exponent.ToByteArrayUnsigned();  
                parms.Exponent = privateKeyParams.PublicExponent.ToByteArrayUnsigned();  
        
                cryptoServiceProvider.ImportParameters(parms);  
        
                return cryptoServiceProvider;  
            }  
        }  
        
        public static RSACryptoServiceProvider PublicKeyFromPemFile(string filePath)  
        {  
            using (TextReader publicKeyTextReader = new StringReader(File.ReadAllText(filePath)))  
            {  
                RsaKeyParameters publicKeyParam = (RsaKeyParameters)new PemReader(publicKeyTextReader).ReadObject();  
        
                RSACryptoServiceProvider cryptoServiceProvider = new RSACryptoServiceProvider();  
                RSAParameters parms = new RSAParameters();  
        
                parms.Modulus = publicKeyParam.Modulus.ToByteArrayUnsigned();  
                parms.Exponent = publicKeyParam.Exponent.ToByteArrayUnsigned();  
        
                cryptoServiceProvider.ImportParameters(parms);  
        
                return cryptoServiceProvider;  
            }  
        }
    }
}
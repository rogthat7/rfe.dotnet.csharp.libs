using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Utils
{
    public static class HttpContentExtensions
    {
        public static async Task<T> ReadAsAsync<T>(this HttpContent content, IJsonFacade jsonFacade, JsonOptions jsonOptions) where T: class
        {
            if (jsonFacade is null)
            {
                throw new ArgumentNullException(nameof(jsonFacade));
            }

            if (jsonOptions is null)
            {
                throw new ArgumentNullException(nameof(jsonOptions));
            }

            if (typeof(T) == typeof(string))
            {
                return await content.ReadAsStringAsync().ConfigureAwait(false) as T;
            }
            else if (typeof(T) == typeof(byte[]))
            {
                return await content.ReadAsByteArrayAsync().ConfigureAwait(false) as T;
            }
            else if (typeof(T) == typeof(Stream))
            {
                return await content.ReadAsStreamAsync().ConfigureAwait(false) as T;
            }              
            
            return await jsonFacade.DeserializeStreamAsync<T>(await content.ReadAsStreamAsync().ConfigureAwait(false), jsonOptions).ConfigureAwait(false);
        }            
    }
}
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Utils
{
    public static class HttpClientExtensions
    {
        public static async Task<HttpResponseMessage> PostAsJsonAsync<T>(this HttpClient httpClient, string url, T data, IJsonFacade jsonFacade, JsonOptions jsonOptions)
        {
            if (jsonFacade is null)
            {
                throw new ArgumentNullException(nameof(jsonFacade));
            }

            if (jsonOptions is null)
            {
                throw new ArgumentNullException(nameof(jsonOptions));
            }

            var dataAsString = await jsonFacade.SerializeAsync(data, jsonOptions);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            return await httpClient.PostAsync(url, content);
        }

        public static async Task<HttpResponseMessage> PutAsJsonAsync<T>(this HttpClient httpClient, string url, T data, IJsonFacade jsonFacade, JsonOptions jsonOptions)
        {
            if (jsonFacade is null)
            {
                throw new ArgumentNullException(nameof(jsonFacade));
            }

            if (jsonOptions is null)
            {
                throw new ArgumentNullException(nameof(jsonOptions));
            }
            
            var dataAsString = await jsonFacade.SerializeAsync(data, jsonOptions);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            return await httpClient.PutAsync(url, content);
        }

        public static void AddRequesterClientIpHeader(this HttpClient httpClient, IPAddress requesterIpAddress)
        {
            if (requesterIpAddress is null)
            {
                return;
            }

            httpClient.AddRequesterClientIpHeader(requesterIpAddress.ToString());
        }
        
        public static void AddRequesterClientIpHeader(this HttpClient httpClient, string requesterIpAddress)
        {
            if (string.IsNullOrEmpty(requesterIpAddress))
            {
                return;
            }

            httpClient.DefaultRequestHeaders.Remove(HttpContextExtensions.RequestClientIPkey);                
            httpClient.DefaultRequestHeaders.Add(HttpContextExtensions.RequestClientIPkey, HtmlEncoder.Default.Encode(requesterIpAddress));
        }

        public static void AddRequesterCultureHeader(this HttpClient httpClient, string culture)
        {
            if (string.IsNullOrEmpty(culture))
            {
                return;
            }

            httpClient.DefaultRequestHeaders.Remove(IAZIHeader.XCultureRequestHeader);                
            httpClient.DefaultRequestHeaders.Add(IAZIHeader.XCultureRequestHeader, HtmlEncoder.Default.Encode(culture));
        }

        public static void AddRequesterApplicationHeader(this HttpClient httpClient, string application)
        {
            if (string.IsNullOrEmpty(application))
            {
                return;
            }

            httpClient.DefaultRequestHeaders.Remove(IAZIHeader.XApplicationRequestHeader);                
            httpClient.DefaultRequestHeaders.Add(IAZIHeader.XApplicationRequestHeader, HtmlEncoder.Default.Encode(application));
        }

        public static void AddRequesterCustomerHeader(this HttpClient httpClient, int customerId)
        {
            if (customerId == 0)
            {
                return;
            }

            httpClient.DefaultRequestHeaders.Remove(IAZIHeader.XCustomerIdRequestHeader);                
            httpClient.DefaultRequestHeaders.Add(IAZIHeader.XCustomerIdRequestHeader, customerId.ToString());
        }

        public static void AddRequesterUserHeader(this HttpClient httpClient, int userId)
        {
            if (userId == 0)
            {
                return;
            }

            httpClient.DefaultRequestHeaders.Remove(IAZIHeader.XUserIdRequestHeader);                
            httpClient.DefaultRequestHeaders.Add(IAZIHeader.XUserIdRequestHeader, userId.ToString());
        }
    }
}
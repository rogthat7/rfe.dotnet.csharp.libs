These classes are based on Microsoft.AspNetCore.Diagnostics
Since they are not extendable, we had to copy them and adjust them to solve one issue with Serilog:
LogContext.PushProperty related actions are lost within an exception due to different context.
One option is to simply populate these properties again which we'll do prior to logging the exception.
Basically only ExceptionHandlerMiddleware.cs had to be extended (HandleException)
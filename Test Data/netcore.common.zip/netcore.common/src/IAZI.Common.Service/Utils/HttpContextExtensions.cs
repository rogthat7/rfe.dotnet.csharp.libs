using System;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using IAZI.Common.Core.Utils;
using Serilog.Context;
using System.Security.Claims;
using Microsoft.AspNetCore.Localization;
using IAZI.Common.Core.Models.Utils;
using IAZI.Common.Core.Interfaces.Models.Auth;
using IAZI.Common.Core.Models.Auth;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Web.Init;
using IAZI.Common.Core.Interfaces.Web.Utils;

namespace IAZI.Common.Service.Utils
{
    public static class HttpContextExtensions
    {
        #region Constants

        private static readonly string UserIdPropertyName = "UserId";

        private static readonly string UserNamePropertyName = "UserName";

        private static readonly string RequestIpPropertyName = "RequestIp";  

        public static readonly string RequestNSClientIPkey = "NS-Client-IP";

        public static readonly string RequestClientIPkey = "Req-Client-IP";

        public static readonly string RequestProxyIPKey = "X-Forwarded-For";

        internal const string ContextKeyAuthData = "Auth:AuthData";

        internal const string ContextKeyUserClaimInfo = "UserClaimInfo";

        #endregion

        public static async Task<RequestContext<IAuthBase>> GetRequestContext(this HttpContext context, ServiceOptions serviceOptions) 
        {
            return await GetRequestContext<IAuthBase>(context, serviceOptions);
        } 

        public static async Task<RequestContext<T>> GetRequestContext<T>(this HttpContext context, ServiceOptions serviceOptions) where T: class, IAuthBase
        {
            
            var requestCulture = GetRequestCulture(context);            

            var requestContext = new RequestContext<T>(
                requestCulture.UICulture,
                requestCulture.Culture,
                context.GetCultureFromRequestForDBCalls(requestCulture),
                GetAuthTokenClaimInfo(context),
                GetRequestIpAddress(context),
                await GetAuthTokenFromRequestHeader(context));

            if (requestContext.UserClaimInfo != null && (serviceOptions.Security.RequiresLegacyAppData || requestContext.UserClaimInfo.IsLegacyToken))
            {
                requestContext.SetLegacyAuthData(GetAuthTokenData<T>(context));
            }

            return requestContext;
        }  

        public static RequestCulture GetRequestCulture(this HttpContext context)
        {
            if (context != null && context.Features != null)
            {
                var requestCultureFeature = context.Features.Get<IRequestCultureFeature>();
                if (requestCultureFeature != null)
                {
                    return requestCultureFeature.RequestCulture;
                }
            }
            
            var uiCultureInfo = Thread.CurrentThread.CurrentUICulture;
            var cultureInfo = Thread.CurrentThread.CurrentCulture;

            return new RequestCulture(cultureInfo, uiCultureInfo);           
        }

        public static bool IsInternalRequest(this HttpContext context, IApplicationInfo applicationInfo)
        {            
            var requestIpAddress = GetRequestIpAddress(context);
            if (applicationInfo?.InternalIPWhitelist != null)
            {                                
                return IPAddressHelper.IPAddressIsInIPSafeList(requestIpAddress, applicationInfo?.InternalIPWhitelist);
            }

            return false;
        }

        /// <summary>
        /// Retrieves culture from context for DB calls and will even convert the culture de to de-CH 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="dontAllowTwoLetterCultures"></param>
        /// <param name="getUICulture"></param>
        /// <returns></returns>
        public static string GetCultureFromRequestForDBCalls(this HttpContext context, RequestCulture requestCulture = null, bool dontAllowTwoLetterCultures = true,
         bool getUICulture = true)
        {
            string culture = null;

            if (requestCulture == null)
            {
                requestCulture = context.GetRequestCulture();
            }
            
            if (requestCulture != null)
            {
                if (getUICulture)
                {
                   culture = requestCulture.UICulture.Name;
                }
                else
                {
                    culture = requestCulture.Culture.Name;
                }                
            }

            if (culture == null)
            {
                if (getUICulture)
                {
                   culture = Thread.CurrentThread.CurrentUICulture.Name;
                }
                else
                {
                    culture = Thread.CurrentThread.CurrentCulture.Name;
                }
            }
                        
            if (dontAllowTwoLetterCultures && !string.IsNullOrEmpty(culture) && culture.Length == 2)
            {
                culture = CultureHelper.ConvertTwoLetterCultureString(culture);
            }

            return culture;
        }
                
        public static T GetAuthTokenData<T>(this HttpContext context, bool throwExceptionIfMissing = true) where T: class, IAuthBase
        {
            var appData = context.Items[ContextKeyAuthData] as T;
            if (appData == null && throwExceptionIfMissing)
            {
                throw new IAZIHttpRequestException("Could not retrieve AppData model from HttpContext! Please check if the Controller/Action has the Authorize Attribute applied! Also check if RequiresLegacyAppData flag needs to be set to true!", true, StatusCodes.Status400BadRequest);
            }
            return appData;
        }       

        public static void SetAuthTokenData(this HttpContext context, IAuthBase authData)
        {
            context.Items[ContextKeyAuthData] = authData;
        }  

        public static UserClaimInfo GetAuthTokenClaimInfo(this HttpContext context, bool throwExceptionIfMissing = true)
        {
            var claimInfo = context.Items[ContextKeyUserClaimInfo] as UserClaimInfo;
            if (claimInfo == null && throwExceptionIfMissing)
            {
                throw new IAZIHttpRequestException("Could not retrieve ClaimInfo model from HttpContext! Please check if the Controller/Action has the Authorize Attribute applied!", true, StatusCodes.Status400BadRequest);
            }
            return claimInfo;
        } 

        public static void SetAuthTokenClaimInfo(this HttpContext context, UserClaimInfo claimInfo)
        {
            context.Items[ContextKeyUserClaimInfo] = claimInfo;
        } 
        
        public static async Task<string> GetAuthTokenFromRequestHeader(this HttpContext context, string tokenName = "access_token") 
        {
            if (string.IsNullOrEmpty(tokenName))
            {
                throw new ArgumentOutOfRangeException(nameof(tokenName));
            }

            return await context.GetTokenAsync(tokenName);
        }
        
        #region Get Client ip logic https://stackoverflow.com/questions/28664686/how-do-i-get-client-ip-address-in-asp-net-core
        
        public static IPAddress GetRequestIpAddress(this HttpContext context, bool tryClientIpHeaders = true, bool tryUseXForwardHeader = true)
        {
            string ip = null;

            if (tryClientIpHeaders)
            {                                
                ip = context.GetHeaderValueAs<string>(RequestClientIPkey);            

                if (string.IsNullOrWhiteSpace(ip))
                {
                    ip = context.GetHeaderValueAs<string>(RequestNSClientIPkey);                    
                }                
            }   

            // support new "Forwarded" header (2014) https://en.wikipedia.org/wiki/X-Forwarded-For

            // X-Forwarded-For (csv list):  Using the First entry in the list seems to work
            // for 99% of cases however it has been suggested that a better (although tedious)
            // approach might be to read each IP from right to left and use the first public IP.
            // http://stackoverflow.com/a/43554000/538763
            // also check: https://docs.microsoft.com/de-de/aspnet/core/host-and-deploy/proxy-load-balancer?view=aspnetcore-3.1
            if (tryUseXForwardHeader)
            {
                if (string.IsNullOrWhiteSpace(ip))
                {
                    ip = context.GetHeaderValueAs<string>(RequestProxyIPKey);
                    if (!string.IsNullOrWhiteSpace(ip))
                    {
                        ip = ip.SplitCsv().FirstOrDefault();
                    }  
                }                            
            }                             

            // RemoteIpAddress is always null in DNX RC1 Update1 (bug).
            if (string.IsNullOrWhiteSpace(ip) && context?.Connection?.RemoteIpAddress != null)
            {
                ip = context.Connection.RemoteIpAddress.ToString();
            }

            // _httpContextAccessor.HttpContext?.Request?.Host this is the local host.

            if (string.IsNullOrWhiteSpace(ip))
            {
                return IPAddress.None;
            }    

            // Prevent issues with loopback address
            if (ip == "::1" || ip.Contains("::ffff:127.0.0.1", StringComparison.InvariantCultureIgnoreCase))
            {
                ip = "127.0.0.1";
            } 

            if (!IPAddress.TryParse(ip, out var ipAddress))
            {
                throw new Exception($"Could not parse IPAddress '{ip}'");
            }            

            if (!ipAddress.IsIPv6LinkLocal &&
                !ipAddress.IsIPv6Multicast &&
                !ipAddress.IsIPv6SiteLocal &&
                !ipAddress.IsIPv6Teredo)            
            {
                return ipAddress.MapToIPv4();
            }
            else
            {
                return ipAddress.MapToIPv6();
            }
        }

        public static T GetHeaderValueAs<T>(this HttpContext context, string headerName)
        {
            StringValues values;

            if (context?.Request?.Headers?.TryGetValue(headerName, out values) ?? false)
            {
                string rawValues = values.ToString();   // writes out as Csv when there are multiple.

                if (!string.IsNullOrEmpty(rawValues))
                    return (T)Convert.ChangeType(values.ToString(), typeof(T));
            }
            return default(T);
        }

        public static void ApplyLogContextProperties(this HttpContext context)
        {
            if (context != null)
            {
                if (context.User != null && context.User.Identity != null)
                {
                    if (context.User.Identity.IsAuthenticated && !string.IsNullOrEmpty(context.User.Identity.Name))
                    {
                        LogContext.PushProperty(UserNamePropertyName, context.User.Identity.Name);
                    }

                    var claimsIdentity = context.User.Identity as ClaimsIdentity;
                    if (claimsIdentity != null && claimsIdentity.Claims != null && claimsIdentity.Claims.Any())
                    {
                        string userId = null;
                        var tokenSub = claimsIdentity.Claims.FirstOrDefault(c => c.Type == IAZIToken.IdentityClaimTypeSubject);
                        if (tokenSub != null)
                        {
                            userId = tokenSub.Value;
                        }
                        else
                        {
                            var legacy = claimsIdentity.Claims.FirstOrDefault(c => c.Type == IAZIToken.LegacyUserId);
                            if (legacy != null)
                            { 
                                userId = legacy.Value;
                            }
                        }
                        
                        if (!string.IsNullOrEmpty(userId))
                        {
                            LogContext.PushProperty(UserIdPropertyName, userId);                            
                        }                        
                    }
                }               
                
                LogContext.PushProperty(RequestIpPropertyName, context.GetRequestIpAddress());                
            }
           
        }       

        #endregion
    }
}
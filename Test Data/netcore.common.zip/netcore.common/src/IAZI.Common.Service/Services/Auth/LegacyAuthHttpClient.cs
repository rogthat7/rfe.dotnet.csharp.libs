using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth.Legacy;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Utils;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Services.Auth
{
    public class LegacyAuthHttpClient : HttpClientBase, ILegacyAuthHttpClient
    {
        #region Properties

        public override string ClientName
        {
            get
            {
                return base.ClientName + "_LocalApi";
            }
        }

        protected readonly IJsonFacade JsonFacade;

        protected override string ServiceInterfaceKey
        {
            get
            {
                return InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer;
            }
        }


        #endregion

        #region Constructor

        public LegacyAuthHttpClient(HttpClient httpClient, ILogger<LegacyAuthHttpClient> logger, 
            IOptions<ServiceOptions> serviceOptions, IJsonFacade jsonFacade) : base(httpClient, logger, serviceOptions)
        {
            JsonFacade = jsonFacade;
        }

        #endregion

        #region Public methods    

        /// <summary>
        /// App token retrieval via IdentityServer endpoint
        /// The endpoint is protected as in Service.Auth via portal_token bearer token, so base class features using IDSRV tokens cannot be used
        /// </summary>
        /// <param name="appTokenClientRequest"></param>
        /// <returns></returns>
        public async Task<AppTokenResponseDto> RequestAppToken(AppTokenClientRequestDto appTokenClientRequest)
        {
            if (appTokenClientRequest == null)
            {
                throw new ArgumentNullException(nameof(appTokenClientRequest));
            }

            if (string.IsNullOrEmpty(appTokenClientRequest.App))
            {
                throw new ArgumentException("App property is mandatory in AppTokenClientRequest");
            }

            if (string.IsNullOrEmpty(appTokenClientRequest.IpAddress))
            {
                throw new ArgumentException("IpAddress property is mandatory in AppTokenClientRequest");
            }

            if (string.IsNullOrEmpty(appTokenClientRequest.UserName) && string.IsNullOrEmpty(appTokenClientRequest.PortalToken))
            {
                throw new ArgumentException("Please either set PortalToken or UserName in AppTokenClientRequest");
            }

            if (!string.IsNullOrEmpty(appTokenClientRequest.UserName) && string.IsNullOrEmpty(appTokenClientRequest.Password))
            {
                throw new ArgumentException("Please either a Password when using UserName in AppTokenClientRequest");
            }

            try
            {
                // TODO: Add Polly logic to retry here as well? HttpClient will already handle this
                // TODO: Endpoint needs to be passed via configuration
                const string requestUri = "v1/apptoken";
                Logger.LogDebug($"Sending Post request to {HttpClient.BaseAddress + requestUri}");
                
                HttpClient.AddRequesterClientIpHeader(appTokenClientRequest.IpAddress);

                if (!string.IsNullOrEmpty(appTokenClientRequest.PortalToken))
                {
                    HttpClient.DefaultRequestHeaders.Remove("Authorization");
                    HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", appTokenClientRequest.PortalToken);
                }

                var request = new AppTokenRequestDto
                {
                    App = appTokenClientRequest.App,
                    Password = appTokenClientRequest.Password,
                    UserName = appTokenClientRequest.UserName
                };
                
                var response = await HttpClient.PostAsJsonAsync(requestUri, request, JsonFacade, ServiceOptions.Json).ConfigureAwait(false);
                var verifiedReponse = await response.EnsureSuccessStatusCodeWithStatusCodeException(JsonFacade, ServiceOptions.Json);
                return await (verifiedReponse.Item1).Content.ReadAsAsync<AppTokenResponseDto>(JsonFacade, ServiceOptions.Json).ConfigureAwait(false);
            }
            catch(Exception ex)
            {
                Logger.LogError($"RequestAppToken Error: {ex.GetExceptionMessage(true, true)}");
                throw;
            } 
        }  

        #endregion       
    }
}
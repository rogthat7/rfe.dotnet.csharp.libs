using System;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;

namespace IAZI.Common.Service.Services.Auth
{
    public static class LegacyAuthHttpClientServiceExtensions
    {
        public static IHttpClientBuilder RegisterLegacyAuthHttpClient(this IServiceCollection services, ServiceOptions serviceOptions)
        {
            if (serviceOptions is null)
            {
                throw new ArgumentNullException(nameof(serviceOptions));
            }

            var authInterface = serviceOptions.GetServiceInterface(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer);                        

            return services.AddHttpClient<ILegacyAuthHttpClient, LegacyAuthHttpClient>(authInterface.Name, client =>
            {
                client.BaseAddress = new Uri(authInterface.BaseUrl);
                client.DefaultRequestHeaders.Add("Accept", "application/json");                
            })
            .AddTransientHttpErrorPolicy(builder => builder.WaitAndRetryAsync(new[]
            {
                TimeSpan.FromSeconds(1),
                TimeSpan.FromSeconds(5),
                TimeSpan.FromSeconds(10)
            }));  
        }                   
    }
}
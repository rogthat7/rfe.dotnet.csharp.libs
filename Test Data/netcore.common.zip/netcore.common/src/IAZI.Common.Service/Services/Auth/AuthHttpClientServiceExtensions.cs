using System;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;

namespace IAZI.Common.Service.Services.Auth
{
    public static class AuthHttpClientServiceExtensions
    {
        public static IHttpClientBuilder RegisterAuthHttpClient(this IServiceCollection services, ServiceOptions serviceOptions)
        {            
            if (serviceOptions is null)
            {
                throw new ArgumentNullException(nameof(serviceOptions));
            }
            
            var authInterface = serviceOptions.GetServiceInterface(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer);                        

            return services.AddHttpClient<IAuthHttpClient, AuthHttpClient>(authInterface.Name, client =>
            {
                client.BaseAddress = new Uri(authInterface.BaseUrl);
                client.DefaultRequestHeaders.Add("Accept", "application/json");                
            })
            .AddTransientHttpErrorPolicy(builder => builder.WaitAndRetryAsync(new[]
            {
                TimeSpan.FromSeconds(1),
                TimeSpan.FromSeconds(5),
                TimeSpan.FromSeconds(10)
            }));  
        }                   
    }
}
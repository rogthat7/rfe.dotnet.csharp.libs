using System;
using System.Linq;
using System.Security.Claims;
using IAZI.Common.Core.Interfaces.Models.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Utils;
using IdentityModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Services.Auth
{
    public class ServiceAuthorizationValidator : IServiceAuthorizationValidator
    {
        #region Properties

        private readonly ILogger<ServiceAuthorizationValidator> _logger;

        private readonly IUserClaimInfoService _userClaimInfoService;

        private readonly ServiceOptions _serviceOptions;

        private readonly IJsonFacade _jsonFacade;

        #endregion

        #region Constructor

        public ServiceAuthorizationValidator(ILogger<ServiceAuthorizationValidator> logger,
        IUserClaimInfoService userClaimInfoService, IOptions<ServiceOptions> serviceOptions,
            IJsonFacade jsonFacade)
        {
            _logger = logger;
            _userClaimInfoService = userClaimInfoService;
            _serviceOptions = serviceOptions.Value;
            _jsonFacade = jsonFacade;            
        }

        #endregion

        #region Public methods

        #endregion

        public virtual bool ValidateRequirement(AuthorizationHandlerContext context, HttpContext httpContext, out IAuthBase authBase, out UserClaimInfo userClaimInfo)
        {
            if (context is null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            if (httpContext is null)            
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            var principal = context.User;
            
            if (principal is null)
            {
                throw new ArgumentNullException(nameof(principal));
            }

            authBase = null;
            userClaimInfo = null;

            var identity = principal.Identity;
            if (identity == null)
            {
                _logger.LogInformation("Requirement failed: Missing identity");
                return false;
            }

            if (!identity.IsAuthenticated)
            {
                _logger.LogInformation("Requirement failed: User not authenticated");
                return false;
            }

            var claimsIdentity = identity as ClaimsIdentity;
            if (claimsIdentity == null)
            {
                _logger.LogInformation("Requirement failed: Identity has to be of type ClaimsIdentity");
                return false;
            }

            if (claimsIdentity.Claims == null || !claimsIdentity.Claims.Any())
            {
                _logger.LogInformation("Requirement failed: Identity doesn't have any claims");
                return false;
            } 

            // Maybe the data has been already extracted
            userClaimInfo = httpContext.GetAuthTokenClaimInfo(false); 
            if (userClaimInfo == null)
            {
                userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(claimsIdentity.Claims, httpContext?.Request.Headers);
            }
            
            if (userClaimInfo == null)
            {
                _logger.LogInformation("Requirement failed: Could not extract claim info data from token");
                return false;
            }

            if (!userClaimInfo.IsLegacyToken)
            {
                var found = claimsIdentity.Claims.Any(c => string.Equals(c.Type, JwtClaimTypes.Scope, StringComparison.OrdinalIgnoreCase)
                            && c.Value.Equals(_serviceOptions.Security.ApiName, StringComparison.OrdinalIgnoreCase));
        
                if (!found)
                {
                    _logger.LogInformation($"Requirement failed for IDSRV token: Required Scope claim '{_serviceOptions.Security.ApiName}' is missing");
                    return false;  
                }
            }
           
            var authTokenType = _serviceOptions.Security.AuthTokenType;
            if (authTokenType != null && (userClaimInfo.IsLegacyToken || _serviceOptions.Security.RequiresLegacyAppData))
            {
                var appName = _serviceOptions.Security.AppName;
                if (string.IsNullOrEmpty(appName))
                {
                    throw new NullReferenceException($"{SecurityOptions.ConfigurationRoot}:AppName is not configured in appsettings!");
                }

                if (userClaimInfo.AppData == null || !userClaimInfo.AppData.Any())
                {
                    _logger.LogInformation($"Requirement failed: Payload is missing for appName {appName}");
                    return false;
                }

                if (authBase == null)
                {
                     // TODO: Refactoring required, contains could be errorprone
                    var permData = userClaimInfo.AppData.Where(x => x.Contains(appName, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                    if (permData != null)
                    {
                        authBase = _jsonFacade.DeserializeObject(permData, authTokenType, _serviceOptions.Json) as IAuthBase;
                    }
                }

                if (authBase == null)
                {
                    _logger.LogInformation($"Requirement failed: No permissions for API with appname {appName}, missing token information. Please ensure AuthTokenType is of type IAppData!");
                    return false;
                }
            }

            return true;
        }
    }
}
using System;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Models.Auth.Token;
using Microsoft.Extensions.Logging;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Services.Auth.Token
{
    public class LegacyAuthHttpClientTokenHandler : HttpClientTokenHandlerBase<LegacyHttpClientTokenRequestDto>
    {
        #region Properties

        private readonly ILegacyAuthHttpClient _legacyAuthHttpClient;

        #endregion

        #region Constructor

        public LegacyAuthHttpClientTokenHandler(ILegacyAuthHttpClient legacyAuthHttpClient, ILogger logger, ITokenContainer tokenContainer) : base(ClientAuthModes.LegacyAuth, logger, tokenContainer)
        {       
            _legacyAuthHttpClient = legacyAuthHttpClient;     
        }

        #endregion

        #region Protected methods

        protected override async Task<string> CreateBearerToken(HttpClientTokenCreateRequest httpClientTokenCreateRequest)
        {
            if (httpClientTokenCreateRequest is null)
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest));
            }
            
            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.ClientName))
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.ClientName));
            }

            var legacyTokenRequest = httpClientTokenCreateRequest.TokenRequest as LegacyHttpClientTokenRequestDto;
            if (legacyTokenRequest == null)
            {
                throw new ArgumentException("Type of tokenRequest must be LegacyHttpClientTokenRequest, please check the call from the HttpClient");
            }

            if (legacyTokenRequest.AppTokenClientRequest == null)
            {
                throw new ArgumentException("Please set AppTokenClientRequest in LegacyHttpClientTokenRequest");
            }
            
            var response = await _legacyAuthHttpClient.RequestAppToken(legacyTokenRequest.AppTokenClientRequest);
            
            if (response == null || string.IsNullOrEmpty(response.AppToken))
            {
                throw new Exception("Could not retrieve AppToken");
            }

            return response.AppToken;
        }

        protected override string CreateTokenKey(string clientName)
        {
            if (string.IsNullOrEmpty(clientName))
            {
                throw new ArgumentNullException(nameof(clientName));
            }

            return base.CreateTokenKey(clientName) + "-Legacy";
        }

        #endregion
    }
}
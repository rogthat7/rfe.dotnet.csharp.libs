using System;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Models.Auth.Token;
using Microsoft.Extensions.Logging;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Services.Auth.Token
{
    public class AuthHttpClientTokenHandler : HttpClientTokenHandlerBase<AuthHttpClientTokenRequestDto>
    {
        #region Properties

        private readonly IAuthHttpClient _authHttpClient;        

        #endregion

        #region Constructor

        public AuthHttpClientTokenHandler(IAuthHttpClient authHttpClient, ILogger logger, ITokenContainer tokenContainer)
         : base(ClientAuthModes.IdentityServer, logger, tokenContainer)
        {       
            _authHttpClient = authHttpClient;     
        }

        #endregion

        

        #region Protected methods

        protected override async Task<string> CreateBearerToken(HttpClientTokenCreateRequest httpClientTokenCreateRequest)
        {
            if (httpClientTokenCreateRequest is null)
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest));
            }
            
            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.ClientName))
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.ClientName));
            }
            
            var authTokenRequest = httpClientTokenCreateRequest.TokenRequest as AuthHttpClientTokenRequestDto;
            if (authTokenRequest == null)
            {
                throw new ArgumentException("Type of tokenRequest must be AuthHttpClientTokenRequestDto, please check the call from the HttpClient, maybe you switched from LegacyAuth to IdentityServer recently.");
            }            
            
            Logger.LogDebug($"CreateBearerToken: RefreshAccessToken enter -> clientName={httpClientTokenCreateRequest.ClientName}, grantType={httpClientTokenCreateRequest.ServiceInterface?.GrantType}");
            
            if (httpClientTokenCreateRequest.ServiceInterface?.GrantType == GrantTypeModes.Delegation)
            {
                return await _authHttpClient.RequestAccessTokenDelegationAsync(httpClientTokenCreateRequest);
            }
            else
            {
                return await _authHttpClient.RequestAccessTokenClientCredentialsAsync(httpClientTokenCreateRequest);
            }
        }       

        #endregion
    }
}
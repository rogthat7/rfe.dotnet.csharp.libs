using System;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth.Token;
using IAZI.Common.Core.Models.Auth.Token;
using Microsoft.Extensions.Logging;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Services.Auth.Token
{
    public abstract class HttpClientTokenHandlerBase<T> : IHttpClientTokenHandler where T: HttpClientTokenRequestDtoBase
    {
        #region Properties

        protected readonly ILogger Logger;

        protected readonly ITokenContainer TokenContainer;

        /// <summary>
        /// Access Token to access the Service this HttpClient is used for
        /// In a Docker scenario it is ok that all Service instances get their own token
        /// </summary>
        protected string Token
        {
            get; set;
        }

        protected ClientAuthModes ClientAuthMode
        {
            get; private set;
        }

        #endregion

        #region Constructor

        protected HttpClientTokenHandlerBase(ClientAuthModes clientAuthMode, ILogger logger, ITokenContainer tokenContainer)
        {     
            Logger = logger;  
            TokenContainer = tokenContainer;   
            ClientAuthMode = clientAuthMode;  
        }

        #endregion

        #region Public methods

        public virtual async Task EnsureBearerTokenIsCreated(HttpClientTokenCreateRequest httpClientTokenCreateRequest)
        {            
            if (httpClientTokenCreateRequest is null)
            {
                 throw new ArgumentNullException(nameof(httpClientTokenCreateRequest));
            }

            if (httpClientTokenCreateRequest.TokenRequest is null)
            {
                 throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.TokenRequest));
            }

            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.ClientName))
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.ClientName));
            }
                       
            var token = GetCreatedToken(httpClientTokenCreateRequest.ClientName, httpClientTokenCreateRequest.SubjectReference, httpClientTokenCreateRequest.RequesterIpAddress);
            if (token == null)
            {
                Logger.LogDebug($"ExecuteResilientHttpRequest: Bearer token not available, getting a new one");
                await RefreshBearerToken(httpClientTokenCreateRequest);                
            }                      
        }     

        public virtual async Task RefreshBearerToken(HttpClientTokenCreateRequest httpClientTokenCreateRequest)         
        {
            Logger.LogDebug("HttpClientTokenHandlerBase: RefreshBearerToken enter");
            
            Token = await CreateBearerToken(httpClientTokenCreateRequest);
            if (Token == null)
            {
                throw new Exception($"HttpClientTokenHandlerBase: could not create a token for client {httpClientTokenCreateRequest.ClientName}, , subject {httpClientTokenCreateRequest.SubjectReference}, requestIp {httpClientTokenCreateRequest.RequesterIpAddress}");
            }

            var key = CreateTokenKey(httpClientTokenCreateRequest.ClientName);    
            
             // Without subject the token container should not be used 
            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.SubjectReference))
            {                                
                Logger.LogDebug($"HttpClientTokenHandlerBase: no subject provided, don't store token with key {key}, subject {httpClientTokenCreateRequest.SubjectReference}, requestIp {httpClientTokenCreateRequest.RequesterIpAddress}");
                return;
            }
                    
            Logger.LogDebug($"HttpClientTokenHandlerBase: setting token with key {key}, subject {httpClientTokenCreateRequest.SubjectReference}, requestIp {httpClientTokenCreateRequest.RequesterIpAddress}");
            TokenContainer.SetToken(key, httpClientTokenCreateRequest.SubjectReference, httpClientTokenCreateRequest.RequesterIpAddress, Token);            
        }

        public string GetCreatedToken(string clientName, string subjectReference, IPAddress requesterIpAddress)
        {
            if (Token != null)
            {
                return Token;
            }

            // Without subject the token container should not be used so return null to recreate a token
            if (string.IsNullOrEmpty(subjectReference))
            {
                Logger.LogDebug($"GetToken: for client {clientName}, subject {subjectReference}, requesterIpAddress {requesterIpAddress}, authMode {ClientAuthMode}, token exists: {Token!=null}, subject was not provided, we need to create a new token.");    
                return null;
            }
              
            Token = TokenContainer.TryGetToken(CreateTokenKey(clientName), subjectReference, requesterIpAddress);
            Logger.LogDebug($"GetToken: for client {clientName}, subject {subjectReference}, requesterIpAddress {requesterIpAddress}, authMode {ClientAuthMode}, token exists: {Token!=null}");
            return Token;
        }
        
        #endregion

        #region Protected methods

        protected abstract Task<string> CreateBearerToken(HttpClientTokenCreateRequest httpClientTokenCreateRequest);
        
        protected virtual string CreateTokenKey(string clientName)
        {
            if (string.IsNullOrEmpty(clientName))
            {
                throw new ArgumentNullException(nameof(clientName));
            }         

            var sb = new StringBuilder();
            sb.Append(clientName);           

            return sb.ToString();
        }
        
        #endregion
    }
}
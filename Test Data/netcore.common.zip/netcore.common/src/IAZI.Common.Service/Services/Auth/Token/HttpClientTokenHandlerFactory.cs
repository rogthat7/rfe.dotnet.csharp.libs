using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth.Token;
using Microsoft.Extensions.Logging;

namespace IAZI.Common.Service.Services.Auth.Token
{
    public class HttpClientTokenHandlerFactory : IHttpClientTokenHandlerFactory
    {
        public IHttpClientTokenHandler CreateAuthHttpClientTokenHandler(IAuthHttpClient authHttpClient, ILogger logger, ITokenContainer tokenContainer)
        {
            return new AuthHttpClientTokenHandler(authHttpClient, logger, tokenContainer);
        }

        public IHttpClientTokenHandler CreateLegacyHttpClientTokenHandler(ILegacyAuthHttpClient legacyAuthHttpClient, ILogger logger, ITokenContainer tokenContainer)
        {
            return new LegacyAuthHttpClientTokenHandler(legacyAuthHttpClient, logger, tokenContainer);
        }
    }
}
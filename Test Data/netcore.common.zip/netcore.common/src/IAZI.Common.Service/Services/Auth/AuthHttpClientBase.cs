using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth.Token;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth.Token;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Utils;
using IdentityModel.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Services.Auth
{
    public abstract class AuthHttpClientBase : HttpClientBase
    {
        #region Properties

        private readonly IHttpClientTokenHandlerFactory _httpClientTokenHandlerFactory;
        
        private IHttpClientTokenHandler _httpClientTokenHandler;
        protected IHttpClientTokenHandler HttpClientTokenHandler
        {
            get
            {
                if (_httpClientTokenHandler == null)
                {
                     if (ClientAuthMode == ClientAuthModes.IdentityServer)
                     {
                         _httpClientTokenHandler = _httpClientTokenHandlerFactory.CreateAuthHttpClientTokenHandler(_authHttpClient, Logger, _tokenContainer);
                     }
                     else if (ClientAuthMode == ClientAuthModes.LegacyAuth)
                     {
                         _httpClientTokenHandler = _httpClientTokenHandlerFactory.CreateLegacyHttpClientTokenHandler(_legacyAuthHttpClient, Logger, _tokenContainer);
                     }
                     else
                     {
                         throw new NotSupportedException($"Unsupported authMode for HttpClientTokenHandler creation: {ClientAuthMode}");
                     }                     
                }
                return _httpClientTokenHandler;
            }
        }

        /// <summary>
        /// The client auth mode defines with which kind of bearer token the client should be used to access any service
        /// </summary>
        /// <value></value>
        public virtual ClientAuthModes ClientAuthMode
        {
            get
            {
                return ServiceInterface.AuthMode;
            }         
        }              

        private readonly IAuthHttpClient _authHttpClient;

        private readonly ILegacyAuthHttpClient _legacyAuthHttpClient;

        private readonly ITokenContainer _tokenContainer;

        protected readonly IJsonFacade JsonFacade;

        protected readonly IHttpContextAccessor HttpContextAccessor;

        #endregion

        #region Constructor

        protected AuthHttpClientBase(HttpClient httpClient, ILogger logger, IHttpClientTokenHandlerFactory httpClientTokenHandlerFactory, 
        IAuthHttpClient authHttpClient, ILegacyAuthHttpClient legacyAuthHttpClient, ITokenContainer tokenContainer,
        IOptions<ServiceOptions> serviceOptions, IJsonFacade jsonFacade, IHttpContextAccessor httpContextAccessor) : base(httpClient, logger, serviceOptions)
        {
            _httpClientTokenHandlerFactory = httpClientTokenHandlerFactory;    
            _legacyAuthHttpClient = legacyAuthHttpClient;
            _authHttpClient = authHttpClient;     
            _tokenContainer = tokenContainer;   
            JsonFacade = jsonFacade; 
            HttpContextAccessor = httpContextAccessor;                             
        }

        #endregion

        #region Protected Methods

        protected virtual async Task<HttpClientTokenResponseDto<TU>> ExecuteResilientHttpPostRequest<T, TU>(string requestUri, T data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where T : class where TU : class
        {
            var response = await ExecuteResilientHttpRequest<T>(HttpMethod.Post, requestUri, data, httpClientTokenRequest);
            return await HandleHttpResponse<TU>(response, HttpMethod.Post);            
        }

        protected virtual async Task<HttpClientTokenResponseDto<TU>> ExecuteResilientHttpGetRequest<TU>(string requestUri, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            var response = await ExecuteResilientHttpRequest<string>(HttpMethod.Get, requestUri, null, httpClientTokenRequest);                        
            return await HandleHttpResponse<TU>(response, HttpMethod.Get);            
        }

        protected virtual async Task<HttpClientTokenResponseDto<TU>> ExecuteResilientHttpDeleteRequest<TU>(string requestUri, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            var response = await ExecuteResilientHttpRequest<string>(HttpMethod.Delete, requestUri, null, httpClientTokenRequest);
            return await HandleHttpResponse<TU>(response, HttpMethod.Delete);            
        }

        protected virtual async Task<HttpClientTokenResponseDto<TU>> ExecuteResilientHttpPutRequest<T, TU>(string requestUri, T data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            var response = await ExecuteResilientHttpRequest<T>(HttpMethod.Put, requestUri, data, httpClientTokenRequest);
            return await HandleHttpResponse<TU>(response, HttpMethod.Put);            
        }

        protected virtual async Task<HttpClientTokenResponseDto<TU>> ExecuteResilientHttpPatchRequest<TU>(string requestUri, HttpContent data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            var response = await ExecuteResilientHttpRequest<HttpContent>(HttpMethod.Patch, requestUri, data, httpClientTokenRequest);
            return await HandleHttpResponse<TU>(response, HttpMethod.Patch);            
        }

        protected virtual async Task<HttpClientTokenResponseDto<TU>> HandleHttpResponse<TU>((HttpResponseMessage responseMessage, ProblemDetailsDto problemDetails) response, HttpMethod requestHttpMethod) where TU : class
        {
            var finalResponse = new HttpClientTokenResponseDto<TU>
            {
                ProblemDetailsResult = response.problemDetails,
                RequestHttpMethod = requestHttpMethod
            };          
            
            if (response.responseMessage != null)
            {
                 var content = await response.responseMessage.Content.ReadAsAsync<TU>(JsonFacade, ServiceOptions.Json).ConfigureAwait(false);            
                 finalResponse.Response = content;
            }
                                        
            return finalResponse;
        }        

        protected virtual async Task<(HttpResponseMessage responseMessage, ProblemDetailsDto problemDetails)> ExecuteResilientHttpRequest<T>(HttpMethod httpMethod, string requestUri, T data, HttpClientTokenRequestDtoBase httpClientTokenRequest)
        {            
            if (string.IsNullOrEmpty(requestUri))
            {
                throw new ArgumentNullException(nameof(requestUri));
            }
            
            // Create new request
            var tokenCreateRequest = new HttpClientTokenCreateRequest(ServiceInterface, httpClientTokenRequest);
            tokenCreateRequest.ClientName = ClientName;
            string subjectReference = null;
            if (httpClientTokenRequest.SubjectReference != null)
            {
                subjectReference = httpClientTokenRequest.SubjectReference.ToString();
            }
            else
            {
                var userClaimInfo = HttpContextAccessor.HttpContext.GetAuthTokenClaimInfo(false);
                subjectReference = userClaimInfo != null ? userClaimInfo.UserId.ToString() : string.Empty;
            }
            tokenCreateRequest.SubjectReference = subjectReference;

            var requesterIpAddress = HttpContextAccessor.HttpContext.GetRequestIpAddress();            
            tokenCreateRequest.RequesterIpAddress = requesterIpAddress;

            var requesterUICulture = HttpContextAccessor.HttpContext.GetRequestCulture().UICulture;
            var requesterCulture = HttpContextAccessor.HttpContext.GetRequestCulture().Culture;
            tokenCreateRequest.RequesterCulture = CultureHelper.CreateCultureString(requesterUICulture, requesterCulture, true);            
            
            Logger.LogInformation($"ExecuteResilientHttpRequest enter: httpMethod={httpMethod}, client={ClientName}, requesterIp={requesterIpAddress}, subject={subjectReference}, requestUri={requestUri}");                                  
            
            await HttpClientTokenHandler.EnsureBearerTokenIsCreated(tokenCreateRequest);
                       
            Polly.Retry.AsyncRetryPolicy<HttpResponseMessage> authorisationEnsuringPolicy = Policy
                    .HandleResult<HttpResponseMessage>(r => r.StatusCode == HttpStatusCode.Unauthorized || r.StatusCode == HttpStatusCode.Forbidden)
                    .RetryAsync(
                    retryCount: 2,
                    onRetryAsync: (e, i) => HttpClientTokenHandler.RefreshBearerToken(tokenCreateRequest)
                );
                        
            var response = await authorisationEnsuringPolicy.ExecuteAsync(async () =>
            {
                var token = HttpClientTokenHandler.GetCreatedToken(ClientName, tokenCreateRequest.SubjectReference, tokenCreateRequest.RequesterIpAddress);
                if (token != null)
                {
                    this.HttpClient.SetBearerToken(token);
                }  

                AddAdditionalRequestHeaders(tokenCreateRequest);                
                
                if (httpMethod == HttpMethod.Post)
                {
                    Logger.LogDebug($"Sending Post request to {HttpClient.BaseAddress + requestUri}");
                    return await HttpClient.PostAsJsonAsync<T>(requestUri, data, JsonFacade, ServiceOptions.Json).ConfigureAwait(false);
                }
                else if (httpMethod == HttpMethod.Put)
                {
                    Logger.LogDebug($"Sending Put request to {HttpClient.BaseAddress + requestUri}");
                    return await HttpClient.PutAsJsonAsync<T>(requestUri, data, JsonFacade, ServiceOptions.Json).ConfigureAwait(false);
                }
                else if (httpMethod == HttpMethod.Delete)
                {
                    Logger.LogDebug($"Sending Delete request to {HttpClient.BaseAddress + requestUri}");
                    return await HttpClient.DeleteAsync(requestUri).ConfigureAwait(false);
                }
                else if (httpMethod == HttpMethod.Patch)
                {
                    Logger.LogDebug($"Sending Patch request to {HttpClient.BaseAddress + requestUri}");
                    return await HttpClient.PatchAsync(requestUri, data as HttpContent).ConfigureAwait(false);                    
                }
                else
                {
                    Logger.LogDebug($"Sending Get request to {HttpClient.BaseAddress + requestUri}");
                    return await HttpClient.GetAsync(requestUri).ConfigureAwait(false);
                }
            });
            
            return await response.EnsureSuccessStatusCodeWithStatusCodeException(JsonFacade, ServiceOptions.Json);
        }

        protected virtual void AddAdditionalRequestHeaders(HttpClientTokenCreateRequest tokenCreateRequest)
        {
            if (tokenCreateRequest is null)
            {
                throw new ArgumentNullException(nameof(tokenCreateRequest));
            }

            // Set Requester IP
            if (tokenCreateRequest.RequesterIpAddress != null)              
            {                    
                this.HttpClient.AddRequesterClientIpHeader(tokenCreateRequest.RequesterIpAddress);
            }

            // Set Requester Culture
            if (!String.IsNullOrEmpty(tokenCreateRequest.RequesterCulture))
            {
                this.HttpClient.AddRequesterCultureHeader(tokenCreateRequest.RequesterCulture);
            }
        }

        protected virtual IActionResult CreateResponse<TU>(HttpClientTokenResponseDto<TU> response)  where TU: class                                                                                                         
        {
            var finalResponse = HandleProblemDetailsResponse<TU>(response);
            if (finalResponse != null)
            {
                return finalResponse;
            }

            return HandleHttpClientTokenResponse<TU>(response);
        } 

        protected virtual IActionResult HandleProblemDetailsResponse<TU>(HttpClientTokenResponseDto<TU> response) where TU: class 
        {
            if (response.ProblemDetailsResult != null)
            {
                Logger.LogError("External HttpClientTokenRequest Problem: "+response.ProblemDetailsResult);
                
                return new ObjectResult(response.ProblemDetailsResult)
                {
                    StatusCode = response.ProblemDetailsResult.Status
                };                 
            }

            return null;
        }

        protected virtual IActionResult HandleHttpClientTokenResponse<TU>(HttpClientTokenResponseDto<TU> response) where TU: class 
        {
            var statusCode = StatusCodes.Status200OK;
            if (response.RequestHttpMethod == HttpMethod.Post)
            {
                statusCode = StatusCodes.Status201Created;
            }
            else if (response.RequestHttpMethod == HttpMethod.Delete
                    || response.RequestHttpMethod == HttpMethod.Put
                    || response.RequestHttpMethod == HttpMethod.Patch)
            {
                statusCode = StatusCodes.Status204NoContent;
            }
                                   
            if (response == null)
            {
                return new StatusCodeResult(statusCode);
            }
            return new ObjectResult(response.Response)
                    {     
                        StatusCode = statusCode           
                    };             
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Models.Auth;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Service.Services.Auth
{
    public class UserClaimInfoService : IUserClaimInfoService
    {
        #region Public methods

        public UserClaimInfo ExtractUserClaimInfo(IEnumerable<Claim> claims, IHeaderDictionary requestHeaders)
        {
            if (claims == null)
            {
                throw new ArgumentNullException("claims");
            }

            var userClaimInfo = new UserClaimInfo();
            var isLegacyToken = claims.Any(d => d.Type != null && d.Type == (IAZIToken.LegacyUserId));

            if (isLegacyToken)
            {
                var permList = claims.Where(c => c.Type == IAZIToken.LegacyAppData);
                if (permList != null && permList.Count<Claim>() > 0)
                {
                    userClaimInfo.AppData = (from p in permList select p.Value).ToList();
                }

                if (claims.Any(c => c.Type == (IAZIToken.LegacyUserId)))
                {
                    userClaimInfo.UserId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyUserId)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == (IAZIToken.LegacyEmailAddress)))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.LegacyEmailAddress)).Value;
                }
                else if (claims.Any(c => c.Type == (IAZIToken.LegacyEmail)))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.LegacyEmail)).Value;
                }
                else if (claims.Any(c => c.Type.ToLower().Contains(IAZIToken.LegacyEmailAddress)))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.ToLower().Contains(IAZIToken.LegacyEmailAddress)).Value;
                }

                if (claims.Any(c => c.Type == (IAZIToken.LegacyCustomerName)))
                {
                    userClaimInfo.CustomerName = claims.First(c => c.Type.Contains(IAZIToken.LegacyCustomerName)).Value;
                }

                if (claims.Any(c => c.Type == (IAZIToken.LegacyCustomerId)))
                {
                    userClaimInfo.CustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyCustomerId)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == IAZIToken.LegacyBankId))
                {
                    userClaimInfo.BankId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyBankId)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == IAZIToken.LegacyAppFamily))
                {
                    userClaimInfo.AppFamily = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyAppFamily)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == IAZIToken.LegacyLoginId))
                {
                    userClaimInfo.LoginId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyLoginId)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == IAZIToken.LegacyAppName))
                {
                    userClaimInfo.AppName = Convert.ToString(claims.First(c => c.Type.Contains(IAZIToken.LegacyAppName)).Value, CultureInfo.InvariantCulture);
                }

                if (claims.Any(c => c.Type == IAZIToken.LegacyDeviceId))
                {
                    userClaimInfo.DeviceId = Convert.ToString(claims.First(c => c.Type.Contains(IAZIToken.LegacyDeviceId)).Value, CultureInfo.InvariantCulture);
                }
                
                if (claims.Any(c => c.Type == IAZIToken.LegacyAppCustomerId))
                {
                    userClaimInfo.AppCustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.LegacyAppCustomerId)).Value, CultureInfo.InvariantCulture);
                }

                //Groups
                var groupList = claims.Where(c => c.Type == IAZIToken.LegacyGroups);
                if (groupList != null && groupList.Any())
                {
                    userClaimInfo.Groups = (from p in groupList select p.Value).Distinct();
                }

                userClaimInfo.IsLegacyToken = true;
            }
            else
            {
                // AppData permissions
                IEnumerable<Claim> permList = null;
                if (claims.Any(c => c.Type == (IAZIToken.IdentityClaimTypeAppData)))
                {
                    permList = claims.Where(c => c.Type == IAZIToken.IdentityClaimTypeAppData);
                }
                else if (claims.Any(c => c.Type == (IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeAppData)))
                {
                    permList = claims.Where(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeAppData);
                }
                else if (claims.Any(c => c.Type == (IAZIToken.ObsoleteAppData)))
                {
                    permList = claims.Where(c => c.Type == IAZIToken.ObsoleteAppData);
                }
                else if (claims.Any(c => c.Type == (IAZIToken.ClientPrefix + IAZIToken.ObsoleteAppData)))
                {
                    permList = claims.Where(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.ObsoleteAppData);
                }

                if (permList != null && permList.Count<Claim>() > 0)
                {
                    userClaimInfo.AppData = from p in permList select p.Value;
                }

                // Subject (UserId)
                if (claims.Any(c => c.Type == (IAZIToken.IdentityClaimTypeSubject)))
                {
                    userClaimInfo.UserId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypeSubject)).Value, CultureInfo.InvariantCulture);
                }

                // Username
                if (claims.Any(c => c.Type == IAZIToken.IdentityClaimTypePreferredUserName))
                {
                    userClaimInfo.UserName = claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypePreferredUserName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypePreferredUserName))
                {
                    userClaimInfo.UserName = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypePreferredUserName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ObsoleteUserName))
                {
                    userClaimInfo.UserName = claims.First(c => c.Type.Contains(IAZIToken.ObsoleteUserName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.ObsoleteUserName))
                {
                    userClaimInfo.UserName = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.ObsoleteUserName)).Value;
                }

                // Email
                if (claims.Any(c => c.Type == IAZIToken.IdentityClaimTypeEmail))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypeEmail)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeEmail))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeEmail)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ObsoleteEmail))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.ObsoleteEmail)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.ObsoleteEmail))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.ObsoleteEmail)).Value;
                }

                // Customer name
                if (claims.Any(c => c.Type == IAZIToken.IdentityClaimTypeCustomerName))
                {
                    userClaimInfo.CustomerName = claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypeCustomerName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeCustomerName))
                {
                    userClaimInfo.CustomerName = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeCustomerName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ObsoleteCustomerName))
                {
                    userClaimInfo.CustomerName = claims.First(c => c.Type.Contains(IAZIToken.ObsoleteCustomerName)).Value;
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.ObsoleteCustomerName))
                {
                    userClaimInfo.CustomerName = claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.ObsoleteCustomerName)).Value;
                }

                // Customer id
                if (claims.Any(c => c.Type == IAZIToken.IdentityClaimTypeCustomerId))
                {
                    userClaimInfo.CustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypeCustomerId)).Value, CultureInfo.InvariantCulture);
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeCustomerId))
                {
                    userClaimInfo.CustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.IdentityClaimTypeCustomerId)).Value, CultureInfo.InvariantCulture);
                }
                else if (claims.Any(c => c.Type == IAZIToken.ObsoleteCustomerId))
                {
                    userClaimInfo.CustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.ObsoleteCustomerId)).Value, CultureInfo.InvariantCulture);
                }
                else if (claims.Any(c => c.Type == IAZIToken.ClientPrefix + IAZIToken.ObsoleteCustomerId))
                {
                    userClaimInfo.CustomerId = Convert.ToInt32(claims.First(c => c.Type.Contains(IAZIToken.ClientPrefix + IAZIToken.ObsoleteCustomerId)).Value, CultureInfo.InvariantCulture);
                }

                // ClientId has no prefix in client_credentials flow
                if (claims.Any(c => c.Type == IAZIToken.IdentityClaimTypeClientId))
                {
                    userClaimInfo.ClientId = claims.First(c => c.Type.Contains(IAZIToken.IdentityClaimTypeClientId)).Value;
                }

                //Groups
                var groupList = claims.Where(c => c.Type == IAZIToken.IdentityRoleClaimType);
                if (groupList != null && groupList.Any())
                {
                    userClaimInfo.Groups = (from p in groupList select p.Value).Distinct();
                }

                userClaimInfo.IsLegacyToken = false;
            }

            if (userClaimInfo.UserEmail == null)
            {
                if (claims.Any(c => c.Type == ClaimTypes.Email))
                {
                    userClaimInfo.UserEmail = claims.First(c => c.Type.Contains(ClaimTypes.Email)).Value;
                }
            }

            // Audience (scope) has no prefix in client_credentials flow
            if (claims.Any(c => c.Type == IAZIToken.Scope))
            {
                userClaimInfo.Scope = claims.First(c => c.Type.Contains(IAZIToken.Scope)).Value;
            }

            if (requestHeaders != null)
            {
                var customerIdOverwriteHeader = requestHeaders[IAZIHeader.XCustomerIdRequestHeader];
                if (!string.IsNullOrEmpty(customerIdOverwriteHeader))
                {
                    userClaimInfo.CustomerIdOverwrite = Convert.ToInt32(customerIdOverwriteHeader);
                }

                var applicationExternalId = requestHeaders[IAZIHeader.XApplicationRequestHeader];
                if (!string.IsNullOrEmpty(applicationExternalId))
                {
                    userClaimInfo.ApplicationExternalId = applicationExternalId;
                }
            }

            return userClaimInfo;
        }

        #endregion
    }
}

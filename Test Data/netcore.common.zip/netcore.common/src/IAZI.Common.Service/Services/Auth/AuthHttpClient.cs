using System;
using System.Net.Http;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth.Token;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Utils;
using IdentityModel.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Services.Auth
{
    /// <summary>
    /// Client to request a new token from IDSRV for server to server communication
    /// </summary>
    public class AuthHttpClient : HttpClientBase, IAuthHttpClient
    {        
        #region Constants

        private const string IdentityServerLocalApiScope = "IdentityServerApi";

      
        #endregion
        
        #region Properties        

        protected override string ServiceInterfaceKey
        {
            get
            {
                return InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer;
            }
        }

        private DiscoveryDocumentResponse _disco = null;

        private readonly IJsonFacade _jsonFacade;

        private readonly IHttpContextAccessor _httpContextAccessor;
        
        #endregion

        #region Constructor

        public AuthHttpClient(HttpClient httpClient, ILogger<AuthHttpClient> logger, 
            IOptions<ServiceOptions> serviceOptions, IJsonFacade jsonFacade, IHttpContextAccessor httpContextAccessor
            ) : base(httpClient, logger, serviceOptions)
        {
            _jsonFacade = jsonFacade;  
            _httpContextAccessor = httpContextAccessor;           
        }

        #endregion

        #region Pubic Methods

        /// <summary>
        /// RequestTokenAsync
        /// </summary>
        /// <returns></returns>
        public async Task<string> RequestAccessTokenDelegationAsync(HttpClientTokenCreateRequest httpClientTokenCreateRequest)
        {
            if (httpClientTokenCreateRequest is null)
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest));
            }

            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.ClientName))
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.ClientName));
            }
            
            var disco = await GetDisco();

            var accessToken = await _httpContextAccessor.HttpContext.GetAuthTokenFromRequestHeader();
            
            HttpClient.AddRequesterClientIpHeader(httpClientTokenCreateRequest.RequesterIpAddress);
            
            var response = await HttpClient.RequestTokenAsync(new TokenRequest
            {
                Address = disco.TokenEndpoint,
                GrantType = "delegation",

                ClientId = ServiceOptions.Security.ApiName,
                ClientSecret = ServiceOptions.Security.ApiSecret,

                Parameters =
                {
                    { "scope", httpClientTokenCreateRequest.ClientName },
                    { "token", accessToken }
                }
            });

            return response.AccessToken;
        }

        public async Task<string> RequestAccessTokenClientCredentialsAsync(HttpClientTokenCreateRequest httpClientTokenCreateRequest)
        {
            if (httpClientTokenCreateRequest is null)
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest));
            }

            if (string.IsNullOrEmpty(httpClientTokenCreateRequest.ClientName))
            {
                throw new ArgumentNullException(nameof(httpClientTokenCreateRequest.ClientName));
            }

            if (string.IsNullOrEmpty(ServiceOptions.Security.ApiName))
            {
                throw new ArgumentNullException(nameof(ServiceOptions.Security.ApiName));
            }

            if (string.IsNullOrEmpty(ServiceOptions.Security.ApiSecret))
            {
                throw new ArgumentNullException(nameof(ServiceOptions.Security.ApiSecret));
            }
            
            // TODO: Optimize this to avoid calling disco endpoint for each access token creation (same in RequestAccessTokenDelegationAsync)
            var disco = await GetDisco();

            HttpClient.AddRequesterClientIpHeader(httpClientTokenCreateRequest.RequesterIpAddress);

            var response = await HttpClient.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
            {
                Address = disco.TokenEndpoint,
                GrantType = "client_credentials",

                ClientId = ServiceOptions.Security.ApiName,
                ClientSecret = ServiceOptions.Security.ApiSecret,
                Scope = httpClientTokenCreateRequest.ClientName
            });

            if (response.IsError)
            {
                throw new IAZIHttpRequestException($"AuthHttpClient error: {response.HttpResponse.ReasonPhrase}", true, (int)response.HttpResponse.StatusCode);
            }

            return response.AccessToken;
        }                                    

        #endregion          

        #region Private methods
       
        private async Task<DiscoveryDocumentResponse> GetDisco()
        {
            if (_disco != null)
            {
                return _disco;
            }

            _disco = await HttpClient.GetDiscoveryDocumentAsync(new DiscoveryDocumentRequest
            {
                Address = HttpClient.BaseAddress.ToString(),
                Policy = new DiscoveryPolicy
                {
                    RequireHttps = false
                }
            });

            if (_disco.IsError)
            {
                throw new Exception(_disco.Error);
            }

            return _disco;
        }       

        #endregion

    }
}
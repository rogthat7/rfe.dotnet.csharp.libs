﻿using System;
using System.Collections.Generic;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Options;

namespace IAZI.Common.Service.Services.Auth
{
    public class AppDataPermissionService : IAppDataPermissionService
    {
        #region Properties

        private readonly IJsonFacade _jsonFacade;

        private readonly ServiceOptions _serviceOptions;

        #endregion

        #region Constructor

        public AppDataPermissionService(IJsonFacade jsonFacade, IOptions<ServiceOptions> serviceOptions)
        {
            _jsonFacade = jsonFacade;
            _serviceOptions = serviceOptions.Value;
        }
        
        #endregion        
        
        #region Public methods

        public bool ValidateAppDataPermissions<T>(IEnumerable<string> appData, List<string> permiCheckList, out T auth) where T : class
        {
            foreach (var l2 in appData)
            {                
                // Verify first if there's a section e.g. address in the permission list
                var authData = _jsonFacade.DeserializeObject<T>(l2, _serviceOptions.Json);
                if (authData != null)
                {
                    foreach (string per in permiCheckList)
                    {
                        // Verify second if there's a token e.g. address.modbase with value True
                        var result = _jsonFacade.SelectTokenValue(l2, per, false, _serviceOptions.Json);
                        
                        if (string.IsNullOrEmpty(result) || !Convert.ToBoolean(result))
                        {
                            auth = authData;
                            return false;
                        }
                    }
                    auth = authData;
                    return true;
                }
            }
            auth = null;
            return false;
        }

        #endregion
    }

}

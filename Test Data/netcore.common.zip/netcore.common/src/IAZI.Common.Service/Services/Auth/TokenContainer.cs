using System;
using System.Net;
using System.Text;
using IAZI.Common.Core.Infrastructure.Interfaces.Data.Concurrency;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Infrastructure.Data.Concurrency;

namespace IAZI.Common.Service.Services.Auth
{
    /// <summary>
    /// Token Container to collect Access Tokens for re-use
    /// Should be used as Singleton only
    /// </summary>
    public class TokenContainer : ITokenContainer
    {
        #region Properties

        private readonly IFastConcurrentDictionary<string, string> _tokenDictionary;

        private static readonly ITokenContainer _instance = new TokenContainer(new FastConcurrentDictionary<string, string>());
 
        public static ITokenContainer GetInstance() => _instance;
 
        #endregion

        #region Constructor

        private TokenContainer(IFastConcurrentDictionary<string, string> tokenDictionary)
        {
            _tokenDictionary = tokenDictionary;
        }
      
        #endregion

        #region Public methods

        public void SetToken(string authClientName, string subject, IPAddress requesterIpAddress, string token)
        {
            if (string.IsNullOrEmpty(authClientName))
            {
                throw new ArgumentNullException(nameof(authClientName));
            }

            if (string.IsNullOrEmpty(subject))
            {
                throw new ArgumentNullException(nameof(subject));
            }

            if (string.IsNullOrEmpty(token))
            {
                throw new ArgumentNullException(nameof(token));
            }
            
            _tokenDictionary.AddOrUpdate(CreateTokenContainerKey(authClientName, subject, requesterIpAddress), token);
        }

        public string TryGetToken(string authClientName, string subject, IPAddress requesterIpAddress)
        {
            if (string.IsNullOrEmpty(authClientName))
            {
                throw new ArgumentNullException(nameof(authClientName));
            }

            if (string.IsNullOrEmpty(subject))
            {
                throw new ArgumentNullException(nameof(subject));
            }

            if (_tokenDictionary.TryGetValue(CreateTokenContainerKey(authClientName, subject, requesterIpAddress), out string token))
            {
                return token;
            }

            return null;
        }

        #endregion

        #region Private methods

        private string CreateTokenContainerKey(string authClientName, string subject, IPAddress requesterIpAddress)
        {
            if (string.IsNullOrEmpty(authClientName))
            {
                throw new ArgumentNullException(nameof(authClientName));
            }

            if (string.IsNullOrEmpty(subject))
            {
                throw new ArgumentNullException(nameof(subject));
            }

            if (requesterIpAddress == null)
            {
                requesterIpAddress = IPAddress.None;
            }

            var sb = new StringBuilder();
            sb.Append(authClientName);
            sb.Append("|");
            sb.Append(subject);
            sb.Append("|");
            sb.Append(requesterIpAddress);
            
            return sb.ToString();
        }

        #endregion
    }
}
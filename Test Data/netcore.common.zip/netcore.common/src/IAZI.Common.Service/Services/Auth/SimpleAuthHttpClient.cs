using System.Net.Http;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth.Token;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Auth.Token;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using static IAZI.Common.Core.Models.Auth.AuthConfig;

namespace IAZI.Common.Service.Services.Auth
{
    public class SimpleAuthHttpClient : AuthHttpClientBase
    {
        #region Properties

        private readonly string _clientName;
        
        public override string ClientName
        {
            get
            {
                return _clientName;
            }
        }  

        private readonly ClientAuthModes _clientAuthMode;

        public override ClientAuthModes ClientAuthMode
        {
            get
            {
                return _clientAuthMode;
            }         
        }

        protected override string ServiceInterfaceKey
        {
            get
            {
                return InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer;
            }
        }

        #endregion

        #region Constructor

        public SimpleAuthHttpClient(string clientName, ClientAuthModes clientAuthMode, HttpClient httpClient, ILogger<SimpleAuthHttpClient> logger, 
            IHttpClientTokenHandlerFactory httpClientTokenHandlerFactory,
            IAuthHttpClient authHttpClient, ILegacyAuthHttpClient legacyAuthHttpClient, ITokenContainer tokenContainer,
            IOptions<ServiceOptions> ServiceOptions, IJsonFacade jsonFacade, IHttpContextAccessor httpContextAccessor) : base(httpClient, logger, httpClientTokenHandlerFactory, authHttpClient, legacyAuthHttpClient, tokenContainer, ServiceOptions, jsonFacade, httpContextAccessor)
        {         
            _clientName = clientName;   
            _clientAuthMode = clientAuthMode;
        }

        #endregion

        #region Public methods  

        public virtual async Task<HttpClientTokenResponseDto<TU>> HttpPostRequest<T, TU>(string requestUri, T data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where T : class where TU : class
        {
            return await ExecuteResilientHttpPostRequest<T, TU>(requestUri, data, httpClientTokenRequest);                     
        }

        public virtual async Task<HttpClientTokenResponseDto<TU>> HttpGetRequest<TU>(string requestUri, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            return await ExecuteResilientHttpGetRequest<TU>(requestUri, httpClientTokenRequest);                                        
        }

        public virtual async Task<HttpClientTokenResponseDto<TU>> HttpDeleteRequest<TU>(string requestUri, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            return await ExecuteResilientHttpDeleteRequest<TU>(requestUri, httpClientTokenRequest);                       
        }

        public virtual async Task<HttpClientTokenResponseDto<TU>> HttpPutRequest<T, TU>(string requestUri, T data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            return await ExecuteResilientHttpPutRequest<T, TU>(requestUri, data, httpClientTokenRequest);                     
        }

        public virtual async Task<HttpClientTokenResponseDto<TU>> HttpPatchRequest<TU>(string requestUri, HttpContent data, HttpClientTokenRequestDtoBase httpClientTokenRequest) where TU : class
        {
            return await ExecuteResilientHttpPatchRequest<TU>(requestUri, data, httpClientTokenRequest);            
        }                   

        #endregion
    }
}
using System;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Services
{
    public abstract class HttpClientBase : IDisposable
    {
        #region Properties
       
        protected ServiceInterface ServiceInterface
        {
            get;
        }   

        public virtual string ClientName
        {
            get
            {
                return ServiceInterface.Name;
            }
        }  

        protected abstract string ServiceInterfaceKey
        {
            get;
        }

        protected readonly HttpClient HttpClient;

        protected readonly ILogger Logger;

        protected readonly ServiceOptions ServiceOptions;
        

        #endregion
        
        #region Constructor

        protected HttpClientBase(HttpClient httpClient, ILogger logger, IOptions<ServiceOptions> serviceOptions)
        {
            HttpClient = httpClient;
            
            // Prevent a .Net core bug with BaseUrl / RequestUrl merging
            if (httpClient.BaseAddress != null && !httpClient.BaseAddress.ToString().EndsWith('/'))
            {
                httpClient.BaseAddress = new Uri(httpClient.BaseAddress.ToString()+"/");
            }

            Logger = logger;
            ServiceOptions = serviceOptions.Value;

            ServiceInterface = ServiceOptions.GetServiceInterface(ServiceInterfaceKey);
            
            if (ServiceInterface == null)
            {
                throw new Exception($"Could not find ServiceInterface for key {ServiceInterfaceKey}");
            }

            if (string.IsNullOrEmpty(ServiceInterface.Name))
            {
                throw new Exception($"The Name for ServiceInterface with key {ServiceInterfaceKey} needs to be provided in the appsettings");
            }

            if (string.IsNullOrEmpty(ServiceInterface.BaseUrl))
            {
                throw new Exception($"The BaseUrl for ServiceInterface with key {ServiceInterfaceKey} needs to be provided in the appsettings");
            }
        }       

        #endregion

        #region Public methods

        public virtual void Dispose()
        {
            if (HttpClient != null)
            {
                HttpClient.Dispose();
            }
        }
            
        #endregion

        #region Protected Methods

        #endregion

        #region Private methods



        #endregion
    }
}
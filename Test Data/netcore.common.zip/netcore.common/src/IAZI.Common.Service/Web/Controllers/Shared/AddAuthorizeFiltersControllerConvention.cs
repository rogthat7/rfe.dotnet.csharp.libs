using IAZI.Common.Service.Web.Init;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Authorization;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    public class AddAuthorizeFiltersControllerConvention : IControllerModelConvention
    {
        public void Apply(ControllerModel controller)
        {
            controller.Filters.Add(new AuthorizeFilter(ServiceStartup.DefaultPolicy));
        }
    }
}
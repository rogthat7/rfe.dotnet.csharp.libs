using Microsoft.AspNetCore.Authorization;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    public class ServiceAuthorizationRequirement : IAuthorizationRequirement
    {
        // Settings for service
    }
}
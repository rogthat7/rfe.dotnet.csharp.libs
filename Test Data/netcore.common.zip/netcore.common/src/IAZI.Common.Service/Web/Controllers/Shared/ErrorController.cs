using System;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Service.Web.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    [ApiController]
    [AllowAnonymous]
    public class ErrorController : ControllerBase
    {
        #region Constructor

         public ErrorController()
        {            
        }
            
        #endregion
        
        [Route("error")]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ApiVersionNeutral]
        [HttpGet]
        [HttpPost]
        [ProducesCustom("application/json", "application/problem+json")]               
        public IActionResult Error()
        {
            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            if (context != null)
            {
                if (context.Error is IAZIHttpRequestException exception)
                {                                    
                    if (exception.ExposeMessageToConsumer)
                    {
                        return Problem(detail: context.Error.Message, statusCode: exception.StatusCode);
                    }

                    return Problem(statusCode: exception.StatusCode);
                } 
                else
                {                                        
                    return Problem();
                }                
            }
            else
            {
                return Problem();
            }  
        }

        [Route("errorlocal")]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ApiVersionNeutral]
        [HttpGet]
        [HttpPost]
        [ProducesCustom("application/json", "application/problem+json")]        
        public IActionResult ErrorLocalDevelopment([FromServices] IWebHostEnvironment webHostEnvironment)
        {
            if (webHostEnvironment.EnvironmentName != "Development")
            {
                throw new InvalidOperationException(
                    "This shouldn't be invoked in non-development environments.");
            }

            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            if (context != null)
            {               
                // We could also add the stack trace but we will log it only in this service and won't send it back to the consumer
                if (context.Error is IAZIHttpRequestException exception)
                {                                                        
                    // On DEV we always show error message here
                    return Problem(detail: context.Error.Message, statusCode: exception.StatusCode);
                }                 

                return Problem(detail: context.Error.Message);
            }
            else
            {
                return Problem();
            }           
        }
    }
}
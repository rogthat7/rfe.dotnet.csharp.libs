using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using IAZI.Common.Core.Utils;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Service.Utils;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    public class ServiceAuthorizationRequirementHandler : AuthorizationHandler<ServiceAuthorizationRequirement>
    {
        private readonly ILogger<ServiceAuthorizationRequirementHandler> _logger;
        private readonly IServiceAuthorizationValidator _serviceAuthorizationValidator;  
        private IHttpContextAccessor _httpContextAccessor;

        public ServiceAuthorizationRequirementHandler(ILogger<ServiceAuthorizationRequirementHandler> logger,          
            IServiceAuthorizationValidator serviceAuthorizationValidator, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _serviceAuthorizationValidator = serviceAuthorizationValidator;
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context,
            ServiceAuthorizationRequirement requirement)
        {
            try
            {                
                var validationResult = _serviceAuthorizationValidator.ValidateRequirement(context, _httpContextAccessor.HttpContext, out var authBase, out var userClaimInfo);
                if (!validationResult)
                {
                    context.Fail();
                }
                else
                {
                    // Set it in HttpContext.Items which is available in the scope of the Request
                    if (_httpContextAccessor?.HttpContext != null)
                    {
                        if (authBase != null) 
                        {
                            _httpContextAccessor.HttpContext.SetAuthTokenData(authBase);
                        }
                        
                        if (userClaimInfo != null)
                        {
                            _httpContextAccessor.HttpContext.SetAuthTokenClaimInfo(userClaimInfo);
                        }                        
                    }                    
                    
                    context.Succeed(requirement);
                }

                return Task.CompletedTask;
            }
            catch(Exception ex)
            {
                context.Fail();
                _logger.LogWarning($"Requirement check failed with an exception: {ex.GetExceptionMessage(true, true)}");
                return Task.CompletedTask;
            }
        }
    }
}
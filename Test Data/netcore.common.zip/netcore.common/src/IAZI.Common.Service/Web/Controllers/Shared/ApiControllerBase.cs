using IdentityModel.AspNetCore.OAuth2Introspection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Web.Controllers.Shared
{

    [ApiController]
    [Route("v{ver:apiVersion}/[controller]")]       
    public abstract class ApiControllerBase : ControllerBase
    {        
        #region Properties 

        protected readonly ILogger Logger;
        
        protected readonly ServiceOptions ServiceOptions;
      
        protected readonly IStringLocalizer Localizer;                          

        #endregion 

        #region Constructor 
        
        protected ApiControllerBase(IOptions<ServiceOptions> serviceOptions, ILogger logger, 
            IStringLocalizer localizer)
        {
            ServiceOptions = serviceOptions.Value;
            Logger = logger;           
            Localizer = localizer;
        }

        #endregion

        #region Protected methods           

        protected string GetCurrentAccessToken()
        {
            return TokenRetrieval.FromAuthorizationHeader().Invoke(Request);
        }

        #endregion

        #region Private methods

        #endregion     
    }
}
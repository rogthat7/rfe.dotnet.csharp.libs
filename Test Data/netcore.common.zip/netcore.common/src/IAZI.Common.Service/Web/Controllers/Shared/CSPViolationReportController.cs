using IAZI.Common.Core.Models.Web.Security;
using IAZI.Common.Service.Web.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    [AllowAnonymous]
    [ApiController]
    public class CSPViolationReportController  : ControllerBase
    {
        #region Properties

        private readonly ILogger<CSPViolationReportController> _logger;

        #endregion

        #region Constructor

        public CSPViolationReportController(ILogger<CSPViolationReportController> logger)
        {
            _logger = logger;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Handles the consent screen postback
        /// </summary>
        [HttpPost]
        [ApiVersionNeutral]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ProducesCustom("application/json", "application/problem+json")] 
        [Route("cspviolationreport")]
        public IActionResult CspReport([FromBody] CspReportRequest request)
        {
            _logger.LogWarning($"CSP Violation detected: {request.CspReport.DocumentUri}, {request.CspReport.BlockedUri}");

            return Ok();
        }


        #endregion
    }
}
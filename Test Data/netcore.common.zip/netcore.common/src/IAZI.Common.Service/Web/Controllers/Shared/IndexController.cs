using Microsoft.AspNetCore.Mvc;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.Extensions.Options;
using IAZI.Common.Core.Interfaces.Web.Utils;
using IAZI.Common.Service.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using IAZI.Common.Service.Web.Attributes;
using IAZI.Common.Service.Utils;

namespace IAZI.Common.Service.Web.Controllers.Shared
{
    [Route("/")]
    [ApiVersionNeutral] 
    [ApiController]
    [AllowAnonymous]
    public class IndexController : ControllerBase
    {        
        #region Properties                

        private readonly ServiceOptions _serviceOptions;

        private readonly IApplicationInfo _applicationInfo;

        #endregion 

        #region Constructor 
        
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        public IndexController(IOptions<ServiceOptions> serviceOptions, IApplicationInfo applicationInfo)
        {
            _serviceOptions = serviceOptions.Value;
            _applicationInfo = applicationInfo;
        }
        
        #endregion

        #region Public methods 

        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ProducesCustom("application/json", "application/problem+json")]   
        [ProducesResponseType(typeof(IndexResponseDto), StatusCodes.Status200OK)]
        public virtual IActionResult Get()
        {
            // check if base url is set
            if (!string.IsNullOrEmpty(_serviceOptions.BasePath))
            {
                if (Request.Path.Value.Equals("/"))
                {
                    Response.Redirect(_serviceOptions.BasePath);
                }
            }        
                            
            var response = new IndexResponseDto();
            response.Init(_applicationInfo, _serviceOptions);
            
            var isInternalRequest = HttpContext.IsInternalRequest(_applicationInfo);
            
            response.IsInternalRequest(isInternalRequest);
            
            return Ok(response);
        }
       
        #endregion     

        #region Protected methods


        #endregion
    }
}
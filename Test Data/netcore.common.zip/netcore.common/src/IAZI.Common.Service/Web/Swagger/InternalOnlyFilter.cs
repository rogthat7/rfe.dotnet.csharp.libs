using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using IAZI.Common.Core.Models.Web.Utils;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Utils;
using IAZI.Common.Service.Web.Attributes;
using Microsoft.AspNetCore.Http;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace IAZI.Common.Service.Web.Swagger
{
    public class InternalOnlyFilter : IDocumentFilter
    {        
       private readonly IEnumerable<ComplexIPAddress> _hideInternalEndpointIpWhitelist;

       private readonly IHttpContextAccessor _httpContextAccessor;

       public InternalOnlyFilter(IEnumerable<ComplexIPAddress> hideInternalEndpointIpWhitelist, IHttpContextAccessor httpContextAccessor)
       {
           _hideInternalEndpointIpWhitelist = hideInternalEndpointIpWhitelist;
           _httpContextAccessor = httpContextAccessor;
       } 

        public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {                        
            if (_hideInternalEndpointIpWhitelist == null || !_hideInternalEndpointIpWhitelist.Any())
            {
                return;
            }

            var requestIpAddress = _httpContextAccessor.HttpContext.GetRequestIpAddress();

            var isWhiteListedRequester = IPAddressHelper.IPAddressIsInIPSafeList(requestIpAddress, _hideInternalEndpointIpWhitelist);

            // Allow to see all Actions if current requester is on Whitelist
            if (isWhiteListedRequester)
            {
                return;
            }

            var schemaDependencies = CreateSchemaReferenceCollection(swaggerDoc);

            var removedPaths = new List<string>();
            var schemasToRemove = new List<string>();

            foreach (var apiDescription in context.ApiDescriptions)
            {                
                if (apiDescription.TryGetMethodInfo(out MethodInfo method))
                {
                    if (method.ReflectedType.CustomAttributes.Any(t => t.AttributeType == typeof(HideFromSwaggerAttribute))
                    || method.CustomAttributes.Any(t => t.AttributeType == typeof(HideFromSwaggerAttribute)))
                    {
                        string key = "/" + apiDescription.RelativePath;
                        if (key.Contains("?"))
                        {
                            var idx = key.IndexOf("?", System.StringComparison.Ordinal);
                            key = key.Substring(0, idx);
                        }
                        swaggerDoc.Paths.Remove(key);
                        removedPaths.Add(key);                        
                    }
                }
            }

            if (!removedPaths.Any() || !schemaDependencies.Any())                        
            {
                return;
            }

            foreach(var removedPath in removedPaths)
            {
                schemaDependencies.TryGetValue(removedPath, out List<string> listRef);
                if (listRef == null)
                {
                    continue;
                }

                // Check if the reference of the removed path exists in another path that was not removed
                var schemaDependenciesWithoutRemovedPaths = schemaDependencies.Where(s => !removedPaths.Contains(s.Key)).Select(k => k.Value);
                foreach(var schemaRef in listRef)
                {
                    if (schemasToRemove.Contains(schemaRef))
                    {
                        continue;                        
                    }

                    if (!schemaDependenciesWithoutRemovedPaths.Any(v => v.Contains(schemaRef)))
                    {
                        schemasToRemove.Add(schemaRef);
                    }
                }
            }

            if (!schemasToRemove.Any())
            {
                return;
            }

            foreach(var schema in schemasToRemove)
            {
                swaggerDoc.Components.Schemas.Remove(schema);
            }             
        }

        /// <summary>
        /// Creates a collection with schema references
        /// Key = Path Ids, values = list with schemas that are used in the path
        /// </summary>
        /// <param name="swaggerDoc"></param>
        /// <returns></returns>
        private Dictionary<string, List<string>> CreateSchemaReferenceCollection(OpenApiDocument swaggerDoc)
        {
            var dic = new Dictionary<string, List<string>>();

            // Nothing that could be removed, simply return
            if (swaggerDoc.Components?.Schemas == null)
            {
                return dic;
            }

            // Collect all Operations that have a reference to this schema (could be in request or response)
            foreach(var path in swaggerDoc.Paths)
            {
                 //path.Key
                var listSchemaRef = new List<string>();                

                foreach(var operation in path.Value.Operations.Values)
                {
                    // Check Request                       
                    var contentDic = operation.RequestBody?.Content;
                    if (contentDic != null)
                    {
                        foreach(var mediaType in contentDic.Values)
                        {
                            if (mediaType.Schema?.Reference != null)
                            {
                                var pathSchemaKey = mediaType.Schema?.Reference.Id;
                                if (pathSchemaKey != null && !listSchemaRef.Contains(pathSchemaKey))
                                {
                                    listSchemaRef.Add(pathSchemaKey);
                                }
                            }
                        }
                    }

                    // Check Response
                    if (operation.Responses != null)
                    {
                        foreach(var response in operation.Responses.Values)
                        {
                            if (response.Content != null)
                            {
                                foreach(var mediaType in response.Content.Values)
                                {
                                    // direct reference
                                    if (mediaType.Schema?.Reference != null)
                                    {
                                        CreateNestedSchemaReferenceCollection(swaggerDoc.Components.Schemas, mediaType.Schema.Reference?.Id, listSchemaRef);
                                    }                                                                   

                                    // collection type
                                    if (mediaType.Schema?.Items?.Reference != null)
                                    {
                                       CreateNestedSchemaReferenceCollection(swaggerDoc.Components.Schemas, mediaType.Schema.Items.Reference?.Id, listSchemaRef);
                                    } 
                                }
                            }
                        }
                    }                        
                }

                if (listSchemaRef.Any() && !dic.ContainsKey(path.Key))
                {
                    dic.Add(path.Key, listSchemaRef);
                }                
            }

            return dic;
        }   

        private void CreateNestedSchemaReferenceCollection(IDictionary<string, OpenApiSchema> swaggerDocSchemas, string pathSchemaKey, List<string> listSchemaRef)
        {
            if (listSchemaRef is null)
            {
                throw new ArgumentNullException(nameof(listSchemaRef));
            }

            if (swaggerDocSchemas is null)
            {
                throw new ArgumentNullException(nameof(swaggerDocSchemas));
            }
            
            if (string.IsNullOrEmpty(pathSchemaKey))
            {
                return;
            }
                                          
            if (listSchemaRef.Contains(pathSchemaKey))
            {
                return;
            }
            
            listSchemaRef.Add(pathSchemaKey);
            
            // Get full schema info from SwaggerDocs

            swaggerDocSchemas.TryGetValue(pathSchemaKey, out OpenApiSchema swaggerDocSchema);
            if (swaggerDocSchema != null)
            {
                // Go through each property and check for other complex types
                if (swaggerDocSchema.Properties != null)
                {
                    foreach(var property in swaggerDocSchema.Properties.Values)
                    {
                        if (property.Reference != null)
                        {
                            CreateNestedSchemaReferenceCollection(swaggerDocSchemas, property.Reference.Id, listSchemaRef);                            
                        }

                        if (property.Items?.Reference != null)
                        {
                            CreateNestedSchemaReferenceCollection(swaggerDocSchemas, property.Items.Reference.Id, listSchemaRef);                            
                        }                        
                    }
                }

                // This will detect schemas used in collections
                if (swaggerDocSchema.Items?.Reference != null)
                {
                    CreateNestedSchemaReferenceCollection(swaggerDocSchemas, swaggerDocSchema.Items.Reference.Id, listSchemaRef);
                }
            }

        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Web.Attributes;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace IAZI.Common.Service.Web.Swagger
{
    public class CustomHeaderOperationFilter : IOperationFilter
    {
        #region Properties
            
        private readonly ServiceOptions _serviceOptions;
        
        #endregion

        #region Constructor

        public CustomHeaderOperationFilter(IOptions<ServiceOptions> serviceOptions)
        {
            _serviceOptions = serviceOptions.Value;
        }
            
        #endregion
        
        #region Public methods

        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
            {
                operation.Parameters = new List<OpenApiParameter>();
            }            
                
            // XCultureRequestHeader
            if (!operation.Parameters.Any(p => p.Name.Equals(IAZIHeader.XCultureRequestHeader, StringComparison.InvariantCultureIgnoreCase))
                &&
                   (_serviceOptions.Swagger.ApplyXCultureHeader 
                    || 
                    context.MethodInfo.ReflectedType.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerCultureHeaderAttribute))
                    || 
                    context.MethodInfo.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerCultureHeaderAttribute))
                    )
                )
            {
                operation.Parameters.Add(new OpenApiParameter
                {
                    Name = IAZIHeader.XCultureRequestHeader,
                    In = ParameterLocation.Header,
                    Description = "Culture to be used in service",
                    Schema = new OpenApiSchema
                    {
                        Type = "String",
                        Default = new OpenApiString(CultureOptions.DefaultGermanCulture)
                    },
                    Required = false 
                });
            }

 
            // XCustomerIdRequestHeader
            if (!operation.Parameters.Any(p => p.Name.Equals(IAZIHeader.XCustomerIdRequestHeader, StringComparison.InvariantCultureIgnoreCase))
                &&
                   (_serviceOptions.Swagger.ApplyXCustomerIdHeader 
                    || 
                    context.MethodInfo.ReflectedType.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerCustomerHeaderAttribute))
                    || 
                    context.MethodInfo.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerCustomerHeaderAttribute))
                    )
                )
            {
                operation.Parameters.Add(new OpenApiParameter
                {
                    Name = IAZIHeader.XCustomerIdRequestHeader,
                    In = ParameterLocation.Header,
                    Description = "Customer Id",
                    Schema = new OpenApiSchema
                    {
                        Type = "Int"                        
                    },
                    Required = false 
                });
            }

            // XApplicationRequestHeader
            if (!operation.Parameters.Any(p => p.Name.Equals(IAZIHeader.XApplicationRequestHeader, StringComparison.InvariantCultureIgnoreCase))
                &&
                   (_serviceOptions.Swagger.ApplyXApplicationHeader 
                    || 
                    context.MethodInfo.ReflectedType.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerApplicationHeaderAttribute))
                    || 
                    context.MethodInfo.CustomAttributes.Any(t => t.AttributeType == typeof(SwaggerApplicationHeaderAttribute))
                    )
                )
            {
                operation.Parameters.Add(new OpenApiParameter
                {
                    Name = IAZIHeader.XApplicationRequestHeader,
                    In = ParameterLocation.Header,
                    Description = "Application",
                    Schema = new OpenApiSchema
                    {
                        Type = "String"                        
                    },
                    Required = false 
                });
            }
        }
            
        #endregion
    }
}
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Session;

namespace IAZI.Common.Service.Web.Providers
{
    public class NullDataProtectionProvider : IDataProtectionProvider
    {
        private readonly IDataProtectionProvider innerDataProtectionProvider;

        public NullDataProtectionProvider(IDataProtectionProvider innerDataProtectionProvider)
        {
            this.innerDataProtectionProvider = innerDataProtectionProvider;
        }

        public IDataProtector CreateProtector(string purpose)
        {
            if (purpose == nameof(SessionMiddleware))
            {
                return new NullDataProtector(this);
            }

            return innerDataProtectionProvider.CreateProtector(purpose);
        }
    }
}
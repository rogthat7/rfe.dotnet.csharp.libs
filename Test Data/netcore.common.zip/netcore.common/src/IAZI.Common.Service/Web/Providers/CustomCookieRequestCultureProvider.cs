using System;
using System.Threading.Tasks;
using IAZI.Common.Core.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;

namespace IAZI.Common.Service.Web.Providers
{
    /// <summary>
    /// Determines the culture information for a request via the value of a cookie.
    /// 
    /// Based on existing CookieRequestCultureProvider but being able to parse simple culture strings as well
    /// https://github.com/aspnet/Localization/blob/master/src/Microsoft.AspNetCore.Localization/CookieRequestCultureProvider.cs
    /// </summary>
    public class CustomCookieRequestCultureProvider : RequestCultureProvider
    {
        /// <summary>
        /// Represent the default cookie name used to track the user's preferred culture information, which is ".AspNetCore.Culture".
        /// </summary>
        public static readonly string DefaultCookieName = "identity.culture"; // ".AspNetCore.Culture";

        /// <summary>
        /// The name of the cookie that contains the user's preferred culture information.
        /// Defaults to <see cref="DefaultCookieName"/>.
        /// </summary>
        public string CookieName { get; set; } = DefaultCookieName;

        /// <inheritdoc />
        public override Task<ProviderCultureResult> DetermineProviderCultureResult(HttpContext httpContext)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            var cookie = httpContext.Request.Cookies[CookieName];

            if (string.IsNullOrEmpty(cookie))
            {
                return NullProviderCultureResult;
            }

            var providerResultCulture = ParseCookieValue(cookie);

            return Task.FromResult(providerResultCulture);
        }

        /// <summary>
        /// Creates a string representation of a <see cref="RequestCulture"/> for placement in a cookie.
        /// </summary>
        /// <param name="requestCulture">The <see cref="RequestCulture"/>.</param>
        /// <returns>The cookie value.</returns>
        public static string MakeCookieValue(RequestCulture requestCulture, bool simpleFormat = true)
        {
            if (requestCulture == null)
            {
                throw new ArgumentNullException(nameof(requestCulture));
            }

            if (simpleFormat)
            {
                return requestCulture.UICulture.TwoLetterISOLanguageName;
            }
            else
            {
                return CookieRequestCultureProvider.MakeCookieValue(requestCulture);                               
            }            
        }

        /// <summary>
        /// Parses a <see cref="RequestCulture"/> from the specified cookie value.
        /// Returns <c>null</c> if parsing fails.
        /// </summary>
        /// <param name="value">The cookie value to parse.</param>
        /// <returns>The <see cref="RequestCulture"/> or <c>null</c> if parsing fails.</returns>
        public static ProviderCultureResult ParseCookieValue(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }
          
            if (!CultureHelper.IsSimpleCultureCookieFormat(value))
            {
                var result = CookieRequestCultureProvider.ParseCookieValue(value);
                if (result != null)
                {
                    // Ensure to convert ALWAYS en to en-US also in complex cookie value format
                    var uiCulture = result.UICultures?.ToString();
                    var culture = result.Cultures?.ToString();
                    var newCultures = false;

                    if (string.IsNullOrWhiteSpace(uiCulture) && uiCulture.Length == 2)
                    {
                        newCultures = true;
                        uiCulture = CultureHelper.ConvertTwoLetterCultureString(uiCulture);
                    }
                    
                    if (string.IsNullOrWhiteSpace(culture) && culture.Length == 2)
                    {                        
                        newCultures = true;
                        culture = CultureHelper.ConvertTwoLetterCultureString(culture);
                    }

                    if (newCultures)
                    {
                        return new ProviderCultureResult(culture, uiCulture);  
                    }                                    
                }

                return result;
            }
            else 
            {
                // Always convert e.g. en to en-US
                var newValue = CultureHelper.ConvertTwoLetterCultureString(value);
                
                return new ProviderCultureResult(newValue, newValue);
            }
        }       
    }
}
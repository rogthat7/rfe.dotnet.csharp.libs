using System;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;

namespace IAZI.Common.Service.Web.Providers
{
    /// <summary>
    /// Custom culture provider to set the thread culture based on a request header "X-Culture"
    /// </summary>
    public class XCultureHeaderRequestCultureProvider : RequestCultureProvider
    {

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public XCultureHeaderRequestCultureProvider()
        {
        }
       
        #endregion

        #region Public methods

        /// <summary>
        /// DetermineProviderCultureResult
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public override Task<ProviderCultureResult> DetermineProviderCultureResult(HttpContext httpContext)
        {
            if (httpContext is null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            httpContext.Request?.Headers.TryGetValue(IAZIHeader.XCultureRequestHeader, out var cultureRequestHeader);

            if (cultureRequestHeader.Count > 0)
            {
                return Task.FromResult(new ProviderCultureResult(cultureRequestHeader.ToString()));
            }

            return NullProviderCultureResult;
        }


        #endregion

    }
}
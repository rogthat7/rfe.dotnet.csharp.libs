using Microsoft.AspNetCore.DataProtection;

namespace IAZI.Common.Service.Web.Providers
{  
    public class NullDataProtector : IDataProtector
    {
        private readonly IDataProtectionProvider dataProtectionProvider;

        public NullDataProtector(IDataProtectionProvider dataProtectionProvider)
        {
            this.dataProtectionProvider = dataProtectionProvider;
        }

        public IDataProtector CreateProtector(string purpose)
        {
            return this.dataProtectionProvider.CreateProtector(purpose);
        }

        public byte[] Protect(byte[] plaintext) => plaintext;

        public byte[] Unprotect(byte[] protectedData) => protectedData;
    }
}
using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Core.Formatter.Json
{
    /// <summary>
    /// Implementation for a facade logic of a Json library
    /// </summary>
    public class JsonSystemTextFacade : IJsonFacade
    {
        #region Public methods

        public string Serialize<TValue>(TValue value, JsonOptions jsonOptions)
        {
            return JsonSerializer.Serialize<TValue>(value, GetDefaultJsonSerializerOptions(jsonOptions));       
        }

        public async Task<string> SerializeAsync<TValue>(TValue value, JsonOptions jsonOptions)
        {
            await using var stream = new MemoryStream();                        
            await JsonSerializer.SerializeAsync<TValue>(stream, value, GetDefaultJsonSerializerOptions(jsonOptions));                         
            stream.Position = 0; 
            using var reader = new StreamReader(stream);
            return await reader.ReadToEndAsync();             
        }

        public async Task<T> DeserializeObjectAsync<T>(string json, JsonOptions jsonOptions)
        {
            if (string.IsNullOrEmpty(json))
            {
                throw new ArgumentNullException(nameof(json));
            }

            byte[] data = Encoding.UTF8.GetBytes(json);            
            await using var stream = new MemoryStream(data);
            return await DeserializeStreamAsync<T>(stream, jsonOptions);            
        }

        public async Task<T> DeserializeStreamAsync<T>(Stream stream, JsonOptions jsonOptions)
        {
            if (stream is null)
            {
                throw new ArgumentNullException(nameof(stream));
            }
            
            return await JsonSerializer.DeserializeAsync<T>(stream, GetDefaultJsonSerializerOptions(jsonOptions));            
        }

        public T DeserializeObject<T>(string json, JsonOptions jsonOptions)
        {
            if (string.IsNullOrEmpty(json))
            {
                throw new ArgumentNullException(nameof(json));
            }            

            return JsonSerializer.Deserialize<T>(json, GetDefaultJsonSerializerOptions(jsonOptions));
        }

        public object DeserializeObject(string json, Type type, JsonOptions jsonOptions)
        {
            if (string.IsNullOrEmpty(json))
            {
                throw new ArgumentNullException(nameof(json));
            }

            if (type == null)
            {
                throw new ArgumentNullException(nameof(type));
            }

            return JsonSerializer.Deserialize(json, type, GetDefaultJsonSerializerOptions(jsonOptions));
        }

        public string ParseAndGetValue(string json, string propertyName, bool throwException, JsonOptions jsonOptions)
        {
            if (string.IsNullOrEmpty(json))
            {
                throw new ArgumentNullException(nameof(json));
            }

            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentNullException(nameof(propertyName));
            }
            
            var jsonSerializerOptions = GetDefaultJsonSerializerOptions(jsonOptions);

            using var doc = JsonDocument.Parse(json, 
                new JsonDocumentOptions
                {
                    AllowTrailingCommas = jsonSerializerOptions.AllowTrailingCommas,
                    MaxDepth = jsonSerializerOptions.MaxDepth,
                    CommentHandling = jsonSerializerOptions.ReadCommentHandling
                });
            
            if (!doc.RootElement.TryGetProperty(propertyName, out JsonElement property))            
            {
                if (throwException)
                {
                    throw new Exception($"Invalid property {propertyName}");
                }
                else
                {
                    return null;
                }
            }

            return property.ToString();            
        }

        public string SelectTokenValue(string json, string searchToken, bool throwException, JsonOptions jsonOptions)
        {
            if (string.IsNullOrEmpty(json))
            {
                throw new ArgumentNullException(nameof(json));
            }

            if (string.IsNullOrEmpty(searchToken))
            {
                throw new ArgumentNullException(nameof(searchToken));
            }

            // Split by . selector to be able to search by the properties one by one
            var tokenParts = searchToken.Split('.', StringSplitOptions.RemoveEmptyEntries);
            
            var jsonSerializerOptions = GetDefaultJsonSerializerOptions(jsonOptions);

            using var doc = JsonDocument.Parse(json, 
                new JsonDocumentOptions
                {
                    AllowTrailingCommas = jsonSerializerOptions.AllowTrailingCommas,
                    MaxDepth = jsonSerializerOptions.MaxDepth,
                    CommentHandling = jsonSerializerOptions.ReadCommentHandling
                });

            // start with root element
            JsonElement currentJsonElement = doc.RootElement;
            
            for(var i=0;i<tokenParts.Length;i++)
            {
                if (!currentJsonElement.TryGetProperty(tokenParts[i], out JsonElement property))            
                {
                    if (throwException)
                    {
                        throw new Exception($"Invalid property {tokenParts[i]}");
                    }
                    else
                    {
                        return null;
                    }
                }

                currentJsonElement = property;
            }
                        
            return currentJsonElement.ToString();
        }
       
        #endregion

        #region Private methods

        private JsonSerializerOptions GetDefaultJsonSerializerOptions(JsonOptions jsonOptions, bool forceRefresh = false)
        {
            return jsonOptions.CreateJsonSerializerOptions(forceRefresh);
        }

        #endregion
    }
}
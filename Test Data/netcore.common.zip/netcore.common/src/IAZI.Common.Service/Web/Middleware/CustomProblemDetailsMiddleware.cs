using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Web.Exceptions;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;

namespace IAZI.Common.Service.Web.Middleware
{
    public class CustomProblemDetailsMiddleware
    {
        #region Properties

        private readonly HashSet<string> allowedHeaderNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            HeaderNames.AccessControlAllowCredentials,
            HeaderNames.AccessControlAllowHeaders,
            HeaderNames.AccessControlAllowMethods,
            HeaderNames.AccessControlAllowOrigin,
            HeaderNames.AccessControlExposeHeaders,
            HeaderNames.AccessControlMaxAge,

            HeaderNames.StrictTransportSecurity,

            HeaderNames.WWWAuthenticate,
        };

        public static readonly MediaTypeCollection ProblemDetailsContentTypes = new MediaTypeCollection
        {
            "application/problem+json",
            "application/problem+xml"
        };

        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        private readonly ServiceOptions _serviceOptions; 
        private readonly CustomProblemDetailsFactory _problemDetailsFactory;     

        private readonly IActionResultExecutor<ObjectResult> _executor;


        private static readonly ActionDescriptor EmptyActionDescriptor = new ActionDescriptor();

        private static readonly RouteData EmptyRouteData = new RouteData();
            
        #endregion   

        #region Constructor

        public CustomProblemDetailsMiddleware(RequestDelegate next, ILoggerFactory loggerFactory, 
            IOptions<ServiceOptions> serviceOptions, ProblemDetailsFactory problemDetailsFactory,
            IActionResultExecutor<ObjectResult> executor)
        {
            _next = next;
            _serviceOptions = serviceOptions.Value;
            _logger = loggerFactory.CreateLogger<CustomProblemDetailsMiddleware>();    
            _problemDetailsFactory = problemDetailsFactory as CustomProblemDetailsFactory; 
            _executor = executor;     
        }
            
        #endregion     

        #region Methods

        public async Task Invoke(HttpContext context)
        {           
            try
            {
                await _next(context);

                if (context.Response.HasStarted || !IsCustomProblem(context))
                {
                    return; 
                }

                ClearResponse(context, context.Response.StatusCode);

                await WriteProblemDetails(context);            
            }
            catch(Exception ex)
            { 
                _logger.LogError($"Error in CustomProblemDetailsMiddleware: {ex.GetExceptionMessage(true)}");               
            } 
        }    

        private static bool IsCustomProblem(HttpContext context)
        {
            // We might have different middleware for Status Codes > 400 && < 500 but if so we'll never land here when it's already handled
            
            if (context.Response.StatusCode < 400)
            {
                return false;
            }

            if (context.Response.StatusCode > 500)
            {
                return false;
            }

            if (context.Response.ContentLength.HasValue)
            {
                return false;
            }

            if (string.IsNullOrEmpty(context.Response.ContentType))
            {
                return true;
            }

            return false;
        }  

        private async Task WriteProblemDetails(HttpContext context)
        {
            var details = _problemDetailsFactory.CreateProblemDetails(context, context.Response.StatusCode) as ProblemDetailsDto;
            
            if (string.IsNullOrEmpty(details.Type))
            {
                details.Type = $"https://httpstatuses.com/{context.Response.StatusCode}";
            }

            if (string.IsNullOrEmpty(details.Title))
            {
                details.Title = ReasonPhrases.GetReasonPhrase(context.Response.StatusCode);
            }

            AddTraceIdIfMissing(context, details);

            var routeData = context.GetRouteData() ?? EmptyRouteData;

            var actionContext = new ActionContext(context, routeData, EmptyActionDescriptor);

            var result = new ObjectResult(details)
            {
                StatusCode = details.Status ?? context.Response.StatusCode,
                ContentTypes = ProblemDetailsContentTypes,
                DeclaredType = details.GetType(),
            };

            result.ContentTypes = ProblemDetailsContentTypes;

            await _executor.ExecuteAsync(actionContext, result);

            await context.Response.CompleteAsync();
        }

        private void ClearResponse(HttpContext context, int statusCode)
        {
            var headers = new HeaderDictionary();

            // Make sure problem responses are never cached.
            headers.Append(HeaderNames.CacheControl, "no-cache, no-store, must-revalidate");
            headers.Append(HeaderNames.Pragma, "no-cache");
            headers.Append(HeaderNames.Expires, "0");

            foreach (var header in context.Response.Headers)
            {
                // Because the CORS middleware adds all the headers early in the pipeline,
                // we want to copy over the existing Access-Control-* headers after resetting the response.
                if (allowedHeaderNames.Contains(header.Key))
                {
                    headers.Add(header);
                }
            }

            context.Response.Clear();
            context.Response.StatusCode = statusCode;

            foreach (var header in headers)
            {
                context.Response.Headers.Add(header);
            }
        }  

        internal void AddTraceIdIfMissing(HttpContext context, ProblemDetailsDto details)
        {
            const string key = "traceId";

            if (details.Extensions.ContainsKey(key))
            {
                return;
            }

            var traceId = Activity.Current?.Id ?? context.TraceIdentifier;

            if (!string.IsNullOrEmpty(traceId))
            {
                details.Extensions[key] = traceId;
            }
        }
            
        #endregion            
    }
}
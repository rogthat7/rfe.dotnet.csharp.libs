using System;
using System.Threading.Tasks;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Piwik.Tracker;

namespace IAZI.Common.Service.Web.Middleware
{
    public class AnalyticsMiddleware
    {
        #region Properties

        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        private readonly ServiceOptions _serviceOptions;      
            
        #endregion   

        #region Constructor

        public AnalyticsMiddleware(RequestDelegate next, ILoggerFactory loggerFactory, IOptions<ServiceOptions> serviceOptions)
        {
            _next = next;
            _serviceOptions = serviceOptions.Value;
            _logger = loggerFactory.CreateLogger<AnalyticsMiddleware>();          
        }
            
        #endregion     

        #region Methods

        public async Task Invoke(HttpContext context)
        {           
            // Background thread for request work
            var task = Task.Run<PiwikTracker>(() => 
            {                               
                var entry = new PiwikTracker(_serviceOptions.Analytics.SiteId, _serviceOptions.Analytics.AnalyticsBaseUrl, context);
                entry.SetTokenAuth(_serviceOptions.Analytics.Token);   
                entry.SetUrl(context.Request.GetDisplayUrl());
                entry.DisableCookieSupport();
                entry.SetIp(context.GetRequestIpAddress()?.ToString());
                return entry;                                        
            });
           
            await _next.Invoke(context); // call next middleware  

            try
            {                 
                 var trackingResponse = await task.ContinueWith<TrackingResponse>((t) => {                
                    // Handle request data
                    // analyticsEntry = CreateAnalyticsEntryWithRequestData(context, analyticsEntry);     
                    // Handle response 
                    if (t.IsCompletedSuccessfully)
                    {
                        return HandleAnalyticsEntryWithResponse(context, t.Result);
                    }
                    return null;
                }, TaskContinuationOptions.RunContinuationsAsynchronously); 

                _logger.LogDebug($"Response from Analytics: {trackingResponse?.RequestedUrl}, {trackingResponse?.HttpStatusCode}"); 
            }
            catch(Exception ex)
            { 
                _logger.LogError($"Error in Analyticsmiddleware: {ex.GetExceptionMessage(true)}");               
            } 
        }

        private PiwikTracker CreateAnalyticsEntryWithRequestData(HttpContext context, PiwikTracker analyticsEntry)
        {                            
            // TODO: Body request is not yet passed to Piwik
            /*  if (context.Request.Body != null && context.Request.ContentLength > 0)
            {
                // TODO: size of body
                context.Request.EnableBuffering();
                context.Request.Body.Position = 0;
                using (var stream = new StreamReader(context.Request.Body))
                {
                    var task = stream
                        .ReadToEndAsync()
                        .ContinueWith(t => {                                                                
                            analyticsEntry.RequestContentBody = t.Result;
                        });
                    task.Wait();
                }                   
            }     */            
            
            return analyticsEntry;            
        }

        private TrackingResponse HandleAnalyticsEntryWithResponse(HttpContext context, PiwikTracker entry)        
        {
            if (entry == null)
            {
                return null;
            }
            
            var claimInfo = context.GetAuthTokenClaimInfo(false);

            // Update the API log entry with response info
            entry.SetUserId(claimInfo?.UserName ?? claimInfo?.UserEmail ?? string.Empty);   
              
            // TODO: Body response is not yet passed to Piwik
            /* if (context.Response.Body != null && context.Response.ContentLength > 0)
            {
                // TODO: size of body
                context.Response.Body.Position = 0;
                using (var stream = new StreamReader(context.Response.Body))
                {
                    var task = stream
                        .ReadToEndAsync()
                        .ContinueWith(t => {                                                                
                            entry.ResponseContentBody = t.Result;                     
                            entry.ResponseContentType = context.Response.ContentType;
                            entry.ResponseHeaders = _jsonFacade.Serialize<object>(context.Response.Headers, _serviceOptions.Json);
                        });
                    task.Wait();
                }                   
            }  */          

            return entry.DoTrackEvent(_serviceOptions.Security.ApiName, "VISIT", "STATUS", context.Response.StatusCode.ToString());                   
        }
            
        #endregion            
    }
}
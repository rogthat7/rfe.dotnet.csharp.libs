using System;
using Microsoft.AspNetCore.Builder;

namespace IAZI.Common.Service.Web.Middleware
{
    public static class AnalyticsMiddlewareExtensions
    {
        /// <summary>
        /// Adds a middleware to the pipeline that will track analytics data
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseAnalytics(this IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            return app.UseMiddleware<AnalyticsMiddleware>();
        }
    }
}
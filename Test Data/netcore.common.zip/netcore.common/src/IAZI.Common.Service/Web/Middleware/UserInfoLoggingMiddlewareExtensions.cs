using Microsoft.AspNetCore.Builder;

namespace IAZI.Common.Service.Web.Middleware
{
    public static class UserInfoLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseUserInfoLogging(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<UserInfoLoggingMiddleware>();
        }
    }
}
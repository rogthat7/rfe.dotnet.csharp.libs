using System;
using Microsoft.AspNetCore.Builder;

namespace IAZI.Common.Service.Web.Middleware
{
    public static class CustomProblemDetailsMiddlewareExtensions
    {
        /// <summary>
        /// Adds a middleware to the pipeline that will handle additional topics in the context of ProblemDetails
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseCustomProblemDetailsMiddleware(this IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            return app.UseMiddleware<CustomProblemDetailsMiddleware>();
        }
    }
}
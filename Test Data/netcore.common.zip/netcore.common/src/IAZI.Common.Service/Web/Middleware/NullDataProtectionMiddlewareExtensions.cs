using System;
using System.Linq;
using IAZI.Common.Service.Web.Providers;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace IAZI.Common.Service.Web.Middleware
{
    public static class NullDataProtectionMiddlewareExtensions
    {
        internal static IServiceCollection AddNullDataProtectionProvider(this IServiceCollection services)
        {
            var dataProtectionProviderDescriptor = services.FirstOrDefault(s => s.ServiceType == typeof(IDataProtectionProvider));
            
            if (dataProtectionProviderDescriptor == null)
            {
                // in order to set the null DataProtectionProvider there has to be the default provider
                services.AddDataProtection();
                dataProtectionProviderDescriptor = services.FirstOrDefault(s => s.ServiceType == typeof(IDataProtectionProvider));                

                if (dataProtectionProviderDescriptor == null)
                {
                    throw new Exception("The IDataProtectionProvider could not be found in the IServiceCollection");
                }
            }
            
            services.Replace(
                ServiceDescriptor.Describe(
                    dataProtectionProviderDescriptor.ServiceType,
                    sp =>
                    {
                        var innerDataProtectionProvider = (IDataProtectionProvider)dataProtectionProviderDescriptor.ImplementationFactory(sp);

                        return new NullDataProtectionProvider(innerDataProtectionProvider);
                    },
                    dataProtectionProviderDescriptor.Lifetime));

            return services;
        }
    }
}
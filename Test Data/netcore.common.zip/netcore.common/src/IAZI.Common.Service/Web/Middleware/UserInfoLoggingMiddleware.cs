using System.Threading.Tasks;
using IAZI.Common.Service.Utils;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Service.Web.Middleware
{
    public class UserInfoLoggingMiddleware
    {
        #region Properties
        
        private readonly RequestDelegate _next;              

        #endregion

        #region Constructor

        public UserInfoLoggingMiddleware(RequestDelegate next)
        {
            _next = next;         
        }

        #endregion
        
        #region Public methods

        public async Task InvokeAsync(HttpContext context)
        {                        
            context.ApplyLogContextProperties();

            // Call the next delegate/middleware in the pipeline
            await _next(context);
        }
        
        
        #endregion                
    }
}
using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace IAZI.Common.Service.Web.Attributes
{
   
    /// <summary>
    /// Problem with wrong content-type with ProblemDetails
    /// see https://github.com/dotnet/aspnetcore/issues/19510
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class ProducesCustomAttribute : Microsoft.AspNetCore.Mvc.ProducesAttribute
    {
        public ProducesCustomAttribute(Type type) : base(type)
        {
        }

        public ProducesCustomAttribute(string contentType, params string[] additionalContentTypes) : base(contentType, additionalContentTypes)
        {
        }

        public override void OnResultExecuting(ResultExecutingContext context)
        {
            if (context.Result is ObjectResult result && result.Value is ProblemDetails) return;
            base.OnResultExecuting(context);
        }
    }
}
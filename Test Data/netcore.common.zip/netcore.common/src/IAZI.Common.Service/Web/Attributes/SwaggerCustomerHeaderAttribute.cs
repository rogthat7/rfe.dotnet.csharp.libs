using System;

namespace IAZI.Common.Service.Web.Attributes
{
    /// <summary>
    /// Simple marker attribute to add the custom Customer header to Swagger, 
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class SwaggerCustomerHeaderAttribute : Attribute
    {        
    }
}
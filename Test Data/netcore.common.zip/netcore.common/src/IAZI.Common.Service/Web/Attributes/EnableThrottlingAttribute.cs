﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using IAZI.Common.Core.Models.Infrastructure.RateLimiting.Legacy;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Infrastructure.RateLimiting.Legacy.Helper;
using IAZI.Common.Service.Utils;
using System.Security.Claims;
using IAZI.Common.Core.Interfaces.Services.Auth;

namespace IAZI.Common.Service.Web.Attributes
{
    /// <summary>
    /// Enables legacy throttling when applied
    /// </summary>
    public class EnableThrottlingAttribute : ActionFilterAttribute
    {
        #region variables
        private static readonly object ProcessLocker = new object();
        private string _ThrottlePolicyKey { get; set; }
        RequestIdentity requestIdentity;

        private IMemoryCache _memoryCache; 

        private RateLimitingOptions _options;   

        private IUserClaimInfoService _userClaimInfoService;    

        #endregion

        public EnableThrottlingAttribute()
        { 
        }

        public EnableThrottlingAttribute(string ThrottlePolicyKey)
        {
            _ThrottlePolicyKey = ThrottlePolicyKey;         
        }

        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            if (_memoryCache == null)
            {
                _memoryCache = actionContext.HttpContext.RequestServices.GetService<IMemoryCache>();
            }  

            if (_options == null)
            {
                _options = actionContext.HttpContext.RequestServices.GetService<IOptions<RateLimitingOptions>>().Value;
            } 

            if (_userClaimInfoService == null)
            {
                _userClaimInfoService = actionContext.HttpContext.RequestServices.GetService<IUserClaimInfoService>();
            }        

            string endPointName = UriHelper.GetDisplayUrl(actionContext.HttpContext.Request);
            
            #region //STEP 1: Get user details like email, IP address, customerid, etc. & fill dictionary
            requestIdentity = GetIdentity(actionContext);

            Dictionary<string, string> dictIdentity = new Dictionary<string, string>();
            dictIdentity.Add(KeyType.customerId.ToString(), requestIdentity.CustomerName);
            dictIdentity.Add(KeyType.email.ToString(), requestIdentity.EmailId);
            dictIdentity.Add(KeyType.ip.ToString(), requestIdentity.IpAddress);
            dictIdentity.Add(KeyType.mobileAppLoginId.ToString(), requestIdentity.MobileAppLoginId);
            #endregion

           var throttleData = _options.LegacyThrottling;

            if (throttleData == null)
            {
                return;
            }

            if (throttleData.whiteListClients != null)
            {
                //STEP 3: Filtered whiteList users, throttling not applied to these users.
                if (throttleData.whiteListClients.Contains(requestIdentity.EmailId)
                    || throttleData.whiteListClients.Contains(requestIdentity.CustomerId)
                    || throttleData.whiteListClients.Contains(requestIdentity.IpAddress)
                    || throttleData.whiteListClients.Contains(requestIdentity.MobileAppLoginId))
                    return;
            }

            if (throttleData.clientRateLimiting != null)
            {
                 //Step 4: Apply policy -> unique -> method name + identity key like emil, ip etc.
                var clientRateLimiting = throttleData.clientRateLimiting.Where(p => p.key == _ThrottlePolicyKey).First();
                ApplyAndCheckPolicy(actionContext, clientRateLimiting.policy, dictIdentity[clientRateLimiting.keyType.ToString()] + endPointName);

                Trace.TraceInformation("******************Identity=>" + clientRateLimiting.keyType.ToString() + " => " + dictIdentity[clientRateLimiting.keyType.ToString()] + "/Method Call=>" + endPointName);
            }
        }

        #region private methods

        /// <summary>
        /// To apply policy, check limit + restrict user.
        /// </summary>
        /// <param name="actionContext">Request context</param>
        /// <param name="policyList">List of throttle policies</param>
        /// <param name="IdentityKey">Key like emailId, IP address etc.</param>
        private void ApplyAndCheckPolicy(ActionExecutingContext actionContext, List<ThrottlePolicy> policyList, string IdentityKey)
        {
            foreach (ThrottlePolicy item in policyList)
            {
                var key = ThrottlingHelper.ComputeCounterKey(IdentityKey, item);
                var allowExecute = false;
                item.PeriodTimespan = ThrottlingHelper.ConvertToTimeSpan(item.Period);

                var throttleCounter = new ThrottleCounter()
                {
                    Timestamp = DateTime.UtcNow,
                    TotalRequests = 1
                };

                lock (ProcessLocker)
                {
                    if (_memoryCache.TryGetValue<ThrottleCounter>(key, out var entry))
                    {
                        // entry has not expired
                        if (entry.Timestamp + item.PeriodTimespan >= DateTime.UtcNow)
                        {
                            // increment request count
                            var totalRequests = entry.TotalRequests + 1;

                            // deep copy
                            throttleCounter = new ThrottleCounter
                            {
                                Timestamp = entry.Timestamp,
                                TotalRequests = totalRequests
                            };
                        }
                    }                    

                    _memoryCache.Set<ThrottleCounter>(key, throttleCounter, new MemoryCacheEntryOptions
                    {
                        SlidingExpiration = item.PeriodTimespan,
                        Priority = CacheItemPriority.Low
                    });
                    
                    if (throttleCounter.TotalRequests > item.Limit)
                    {
                        allowExecute = false;
                    }                        
                    else
                    {
                        allowExecute = true;
                    }
                        

                    if (!allowExecute)
                    {
                        actionContext.Result = new ContentResult
                        {
                            Content = string.Format("API calls quota exceeded! maximum admitted {0} per {1}.", item.Limit, item.Period),
                            StatusCode = (int)HttpStatusCode.TooManyRequests,
                            ContentType = "application/json"
                        };

                        actionContext.HttpContext.Response.Headers.Add("Retry-After", RetryAfterFrom(throttleCounter.Timestamp, item));
                        Trace.TraceError(string.Format(Environment.NewLine + "Request {0} from IpAddress:{1} EmailId:{2} has been throttled (blocked), quota {3}/{4} exceeded by {5}"
                                                , UriHelper.GetDisplayUrl(actionContext.HttpContext.Request)
                                                , requestIdentity.IpAddress
                                                , requestIdentity.EmailId
                                                , item.Limit
                                                , item.Period
                                                , throttleCounter.TotalRequests));
                    }
                }
            }

        }

        /// <summary>
        /// Get requested user details
        /// </summary>
        /// <param name="actionContext">Request context</param>
        /// <returns></returns>
        private RequestIdentity GetIdentity(ActionExecutingContext actionContext)
        {
            var userClaimInfo = actionContext.HttpContext.GetAuthTokenClaimInfo(false);
            if (userClaimInfo == null)
            {
                var principal = actionContext.HttpContext.User as ClaimsPrincipal;
                userClaimInfo = _userClaimInfoService.ExtractUserClaimInfo(principal.Claims, actionContext.HttpContext.Request.Headers);
                actionContext.HttpContext.SetAuthTokenClaimInfo(userClaimInfo);
            }
                        
            return new RequestIdentity()
            {
                CustomerId = userClaimInfo == null ? string.Empty : userClaimInfo.CustomerId.ToString(),
                EmailId = userClaimInfo == null ? string.Empty : userClaimInfo.UserEmail,
                IpAddress = actionContext.HttpContext.GetRequestIpAddress().ToString(),
                CustomerName = userClaimInfo == null ? string.Empty : userClaimInfo.CustomerName,
                MobileAppLoginId = userClaimInfo == null ? string.Empty : userClaimInfo.LoginId.ToString(),
            };
        }

        /// <summary>
        /// To get next request retry time(in seconds)
        /// </summary>
        /// <param name="timestamp">Last request timestamp.</param>
        /// <param name="rule">ThrottlePolicy</param>
        /// <returns></returns>
        private string RetryAfterFrom(DateTime timestamp, ThrottlePolicy rule)
        {
            var secondsPast = Convert.ToInt32((DateTime.UtcNow - timestamp).TotalSeconds);
            var retryAfter = Convert.ToInt32(rule.PeriodTimespan.TotalSeconds);
            retryAfter = retryAfter > 1 ? retryAfter - secondsPast : 1;
            return retryAfter.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        #endregion
    }
}

using System;

namespace IAZI.Common.Service.Web.Attributes
{
    /// <summary>
    /// Simple marker attribute to hide the action from Swagger, 
    /// please set ServiceInternalIpWhitelist to allow certain users to see the actions
    /// and UseHideInternalEndpoints = true
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class HideFromSwaggerAttribute : Attribute
    {        
    }
}
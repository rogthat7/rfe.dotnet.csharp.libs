using IAZI.Common.Core.Models.Web.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace IAZI.Common.Service.Web.Filters
{
    public class HttpRequestExceptionFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context) { }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception is IAZIHttpRequestException exception)
            {                
                var value = $"{exception.Message}";

                context.Result = new ObjectResult(value)
                {
                    StatusCode = exception.StatusCode,
                };
                context.ExceptionHandled = true;
            }
        }
    }
}
using System.ComponentModel.DataAnnotations;
using IAZI.Common.Core.Models.Auth;
using Microsoft.AspNetCore.Mvc;

namespace IAZI.Common.Service.Web.Models
{    
    /// <summary>
    /// Dto class to be able to do validation on the header field (you need [FromQuery] and not [FromHeader]!!) in controller action    
    /// Please note that the header value is also stored in UserClaimInfo where it should be used
    /// but there won't be any input validation
    /// </summary>
    public class ApplicationHeaderRequestDto
    {
        #region Properties

        /// <summary>
        /// ApplicationExternalId
        /// </summary>
        /// <value></value>
        [Required]        
        [FromHeader(Name = IAZIHeader.XApplicationRequestHeader)]
        public string ApplicationExternalId { get; set; }

        #endregion
    }
}
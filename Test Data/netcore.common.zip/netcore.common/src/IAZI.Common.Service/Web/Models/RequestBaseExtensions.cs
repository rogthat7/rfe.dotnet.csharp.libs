using System;
using IAZI.Common.Core.Models.Shared;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Utils;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Service.Web.Models
{
    public static class RequestBaseExtensions
    {
        #region Public methods

        public static T CreateSystemRequest<T>(this T instance, HttpContext httpContext) where T: RequestBase
        {
            if (instance == default(T))
            {
                instance = Activator.CreateInstance<T>();
            }
             
            instance.RequestCustomerId = DefaultValues.DefaultRequestSystemCustomerId;    
            instance.RequestUserId = DefaultValues.DefaultRequestSystemUserId;    
            instance.Culture = httpContext != null ? httpContext.GetCultureFromRequestForDBCalls() : CultureOptions.DefaultGermanCulture;

            return instance;
        }
        
        #endregion      
    }
}
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.AspNetCore.Mvc;

namespace IAZI.Common.Service.Web.Models
{    
    /// <summary>
    /// Dto class to be able to do validation on the header field (you need [FromQuery] and not [FromHeader]!!) in controller action
    /// Please note that the header value is also stored in HttpContext where it should be used
    /// but there won't be any input validation
    /// </summary>
    public class CultureHeaderRequestDto
    {
        #region Properties

        [Required]
        [MaxLength(5)]
        [DefaultValue(CultureOptions.DefaultGermanCulture)]
        [FromHeader(Name = IAZIHeader.XCultureRequestHeader)]
        public string Culture { get; set; } = CultureOptions.DefaultGermanCulture;

        #endregion
    }
}
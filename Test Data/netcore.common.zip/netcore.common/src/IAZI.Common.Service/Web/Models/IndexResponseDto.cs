using System;
using IAZI.Common.Core.Interfaces.Web.Utils;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Core.Models.Web.Options;

namespace IAZI.Common.Service.Web.Models
{
    public class IndexResponseDto
    {
        #region Properties

        public string ApiName { get; set; }

        public string Environment { get; set; } 

        public string Addresses { get; set; } 

        public string HostingEnvironment { get; set; }    
        
        public string BasePath { get; set; }
        
        public string HostName { get; set; }
                
        public string Version { get; set; }
        
        public string VersionDate { get; set; }
        
        public string SharedLibraryVersion { get; set; }
        
        public string SharedLibraryVersionDate { get; set; }
        
        public string TCBuildNumber { get; set; }

        public string GitHash { get; set; }

        public string DockerImageTag { get; set; }

        public string RequestCulture { get; set; } 
      
        public string RequestCultureUI { get; set; }

        public string Cultures { get; set; }

        public string ContentRootPath { get; set; }

        public string WebRootPath { get; set; }

        public string ServerAuthMode { get; set; }

        public string Database { get; set; } 

        private bool _isInternalRequest;
            
        #endregion
        
        #region Public methods

        public void IsInternalRequest(bool isInternalRequest)
        {
            _isInternalRequest = isInternalRequest;

            if (!_isInternalRequest)
            {
                TCBuildNumber = string.Empty;
                GitHash = string.Empty;
                Database = string.Empty;
                DockerImageTag = string.Empty;
                ServerAuthMode = string.Empty;
                ContentRootPath = string.Empty;
                WebRootPath = string.Empty;
                HostingEnvironment = string.Empty;
                Addresses = null;
                HostName = string.Empty;
            }
        }

        public void Init(IApplicationInfo applicationInfo, ServiceOptions options)
        {
            if (applicationInfo is null)
            {
                throw new ArgumentNullException(nameof(applicationInfo));
            }

            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            ApiName = options.Security.ApiName;
            Environment = options.Environment.ToString();
            Addresses = applicationInfo.ServerAddressList;
            HostingEnvironment = applicationInfo.HostingEnvironment;
            BasePath = options.BasePath;
            HostName = applicationInfo.HostName;
            Version = applicationInfo.Version;
            VersionDate = applicationInfo.VersionDate;
            SharedLibraryVersion = applicationInfo.SharedLibraryVersion;
            SharedLibraryVersionDate = applicationInfo.SharedLibraryVersionDate;
            TCBuildNumber = applicationInfo.TCBuildNumber;
            GitHash = applicationInfo.GitHash;
            DockerImageTag = applicationInfo.DockerImageTag;
            RequestCulture = options.Culture.Default;
            RequestCultureUI = options.Culture.DefaultUI;
            Cultures = string.Join(',', options.Culture.Supported);
            ContentRootPath = applicationInfo.ContentRootPath;
            WebRootPath = applicationInfo.WebRootPath;
            ServerAuthMode = options.Security.ServerAuthMode.ToString();  
            Database = applicationInfo.Database;
        }
            
        #endregion

        #region Public Methods

        // TODO: https://stackoverflow.com/questions/59507818/shouldserialize-method-is-not-triggered-in-net-core-3
        public bool ShouldSerializeDatabase()
        {
            return _isInternalRequest;
        }
            
        #endregion
    }
}
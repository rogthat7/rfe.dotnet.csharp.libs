using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace IAZI.Common.Service.Web.Init
{
    /// <summary>
    /// Lean Service startup for e.g. an API Gateway
    /// </summary>
    public class LeanServiceStartup : ServiceStartup
    {
        #region Properties

        #endregion

        #region Constructor

        public LeanServiceStartup(IConfiguration configuration,
            IWebHostEnvironment env) : base(configuration, env)
        {            
        }

        #endregion

        #region Protected methods - ConfigureServices

        protected override void InitLocalization(IServiceCollection services)
        {
        }

        protected override void InitConfiguration(IServiceCollection services)
        {            
        }
        
        /// <summary>
        /// No MVC required
        /// </summary>
        /// <param name="services"></param>
        protected override IMvcBuilder InitMVC(IServiceCollection services)
        {
            return null;                      
        }

        protected override void InitApiVersioning(IServiceCollection services)
        {           
        }

        protected override void InitCustomServices(IServiceCollection services)
        {            
        }

        protected override void InitIoC(IServiceCollection services)
        {
        }

        protected override void InitOptions(IServiceCollection services)
        {
        }

        protected override void InitDataProtection(IServiceCollection services)
        {
        }

        protected override void InitDbAndCaching(IServiceCollection services)
        {
        }

        protected override void InitAuthentication(IServiceCollection services)
        {
        }

        protected override void InitHttpClients(IServiceCollection services)
        {
        }

        #endregion

        #region Protected methods - Configure       

        protected override void UseLocalization(IApplicationBuilder app)
        {            
        }
        
        protected override void UseSwagger(IApplicationBuilder app)
        {           
        } 

        protected override void UseMVC(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            UseMVCAuthentication(app);
        }

        #endregion
    }
}
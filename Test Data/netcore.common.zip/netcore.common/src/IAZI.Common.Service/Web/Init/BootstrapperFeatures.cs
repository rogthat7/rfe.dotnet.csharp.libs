using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using IAZI.Common.Core.Models.Utils;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Models.Web.Options;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;

namespace IAZI.Common.Service.Web.Init
{
    public class BootstrapperFeatures : IDisposable
    {
        #region Properties
        
        private ILogger<BootstrapperFeatures> _logger;

        private IHost _host;

        private bool _init;   

        /// <summary>
        /// Application Info details coming from environment
        /// </summary>
        /// <returns></returns>
        public ApplicationInfo ApplicationInfo { get; set; } = new ApplicationInfo();
   
        /// <summary>
        /// Action to handle custom json config files
        /// </summary>
        public Action<IConfigurationBuilder> AdditionalJsonConfigFileAction;

        /// <summary>
        /// Action to inject additional webhostbuilder logic
        /// </summary>
        public Action<IWebHostBuilder> AdditionalWebHostBuilderAction;

        public bool ShutDownAfterFiveSecondsForTesting { get; set; }       

        private System.Timers.Timer _timer; 

        #endregion

        #region Constructor

        public BootstrapperFeatures()
        {            
        }
            
        #endregion
        
        
      
        #region Public methods

        public virtual IHost Init<T>(string[] args = null) where T: RootStartupBase
        {
            if (_init)
            {
                throw new InvalidOperationException("StartupFeature Init has already been executed!");
            }
           
            _init = true;            
            return CreateHostBuilder<T>(args).Build();            
        }

        public virtual int Run<T>(string[] args = null) where T: RootStartupBase
        {
             if (_host == null)
             {
                 _host = Init<T>(args);
             }

             _logger = _host.Services.GetRequiredService<ILogger<BootstrapperFeatures>>(); 

            try
            {
                if (ShutDownAfterFiveSecondsForTesting)
                {
                     _timer = new System.Timers.Timer(5000);

                    // Hook up the Elapsed event for the timer.
                    _timer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                    _timer.Enabled = true;                    
                }
                
                _host.Run();                
                return 0;
            }
            catch (Exception ex)
            {
                if (_logger != null)
                {
                    _logger.LogCritical(ex, "Host terminated unexpectedly");
                }
                
                if (_host != null)
                {
                    _host.Dispose();
                }
                return 1;
            }             
        }

        public virtual IHostBuilder CreateHostBuilder<T>(string[] args) where T: RootStartupBase
        {
            return Host.CreateDefaultBuilder(args)                            
                .ConfigureAppConfiguration((context, config) =>
                {
                    var env = context.HostingEnvironment;
                    
                    if (env.IsProduction())
                    {
                        HandleJsonConfigurationsForRancher(config);
                    }   

                    if (AdditionalJsonConfigFileAction != null)
                    {
                        AdditionalJsonConfigFileAction(config);
                    }
                })                                           
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<T>();
                    
                    webBuilder.UseKestrel(o => 
                    {
                      o.AddServerHeader = false;                        
                      HandleKestrelServerOptions(args, o);
                    });              
                        
                    // disable the status messages     
                    webBuilder.SuppressStatusMessages(true); 
                    webBuilder.CaptureStartupErrors(false);

                    if (AdditionalWebHostBuilderAction != null)
                    {
                        AdditionalWebHostBuilderAction(webBuilder);
                    }
                })                             
                .UseSerilog((context, config) =>
                {                                            
                    config.ReadFrom.Configuration(context.Configuration);                            
                });  
        }

        public virtual void ShutDown()
        {
            try
            {
                _logger?.LogInformation("Shutting down .Net Core environment");                
            }
            catch (Exception ex)
            {
                _logger?.LogCritical(ex, "Error while shutting down");                    
            } 
            finally
            {
                if (_host != null)
                {
                    _host.Dispose();
                }
            }
        }  

        public async Task ManualShutdown(CancellationToken cancellationToken = default)
        {
            if (_host != null)
            {
                await _host.StopAsync(cancellationToken);
            }
        }                                 

        protected virtual void HandleJsonConfigurationsForRancher(IConfigurationBuilder config, bool reloadOnChange = true)              
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            // Paths & Files are configured like this in Rancher for ALL environments
            // The file names could also be passed via configuration but at this time
            // the configuration is not yet available in .NET Core
            const string rancherConfigFile = "/config/appsettings.Rancher.ConfigMaps.json";
            const string rancherSecretFile = "/secret/appsettings.Rancher.Secrets.json";
            if (File.Exists(rancherConfigFile))
            {
                config.AddJsonFile(rancherConfigFile, optional: true, reloadOnChange: reloadOnChange);
            }
            if (File.Exists(rancherSecretFile))
            {
                config.AddJsonFile(rancherSecretFile, optional: true, reloadOnChange: reloadOnChange);
            }
        }

        protected virtual void HandleKestrelServerOptions(string[] args, KestrelServerOptions options)
        {           
            var serviceOptions = options.ApplicationServices.GetService<IOptions<ServiceOptions>>();

            if (ApplicationInfo.ServerCertificate != null 
            && serviceOptions.Value.Security.Certificate.UsedCertMode != SecurityCertificateOptions.CertMode.None
            && serviceOptions.Value.Security.Certificate.UseServerCertificateForSecuredKestrel)
            {
                // Get https port
                int port = 443; 
                var newPort = this.ApplicationInfo.GetHttpsPort();
                if (newPort != 0)
                {
                    port = newPort;
                }
                
                options.Listen(IPAddress.Any, port, listenOptions => 
                {
                    listenOptions.UseHttps(ApplicationInfo.ServerCertificate);
                });                  

                _logger.LogInformation($"Successfully initialized internal HTTPS endpoint with given certificate on port {port}");
            }                                        
        }

        public void Dispose()
        {
            if (_host != null)
            {
                _host.Dispose();
            }                      
        }

        // Specify what you want to happen when the Elapsed event is  
        // raised. 
        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            _timer.Enabled = false;
            ManualShutdown().Wait();
        }

        #endregion
    }
}
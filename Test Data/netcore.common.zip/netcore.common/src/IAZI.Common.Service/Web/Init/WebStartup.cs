using System;
using System.IO;
using System.Linq;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Core.Models.Web.Utils;
using IAZI.Common.Service.Utils;
using IAZI.Common.Service.Utils.Exceptions;
using IAZI.Common.Service.Web.Controllers.Shared;
using IAZI.Common.Service.Web.Middleware;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using NWebsec.AspNetCore.Mvc.Csp;

namespace IAZI.Common.Service.Web.Init
{
    public class WebStartup : StartupBase
    {
        #region Properties  

        protected WebApplicationOptions WebApplicationOptions
        {
            get; set;
        }    

        #endregion

        #region Constructor

        public WebStartup(IConfiguration configuration, IWebHostEnvironment env)
            : base(configuration, env)
        {
        }

        #endregion

        #region Protected methods - ConfigureServices

        protected override void InitOptions(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitOptions(services);

            services.AddOptions<WebApplicationOptions>().Bind(Configuration.GetSection(WebApplicationOptions.ConfigurationRoot))
             .PostConfigure(config => {
                // this code will be called with each DI flow
                PostConfigureWebApplicationOptions(config);
            })
            .ValidateDataAnnotations()
            .Validate(WebApplicationOptions.ValidateSettings, "WebApplicationOptions validation failed");     

            // Create Service Configuration based on passed Options
            var sp = services.BuildServiceProvider();                        
            WebApplicationOptions = sp.GetRequiredService<IOptions<WebApplicationOptions>>().Value;                                                    

            // Set the Cookie Policy Options
            InitCookiePolicy(services);
        }

        protected virtual void InitCookiePolicy(IServiceCollection services)
        {
            CookiePolicyOptions cookiePolicyOptions = null;
            if (ServiceOptions.Environment.Equals(DeployEnvironment.LOCAL))
            {
                var httpsPort = this.Bootstrapper.Features.ApplicationInfo.GetHttpsPort();
                // We are running HTTP in localhost
                if (httpsPort == 0)
                {
                    cookiePolicyOptions = new CookiePolicyOptions
                    {
                        //CheckConsentNeeded = context => true,
                        MinimumSameSitePolicy = SameSiteMode.Lax,
                        Secure = CookieSecurePolicy.SameAsRequest
                    };
                }               
            }

            if (cookiePolicyOptions == null)
            {
                cookiePolicyOptions = new CookiePolicyOptions
                {
                    CheckConsentNeeded = context => true,
                    MinimumSameSitePolicy = SameSiteMode.None,
                    Secure = CookieSecurePolicy.SameAsRequest
                };
            }

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = cookiePolicyOptions.CheckConsentNeeded;
                options.MinimumSameSitePolicy = cookiePolicyOptions.MinimumSameSitePolicy;
                options.Secure = cookiePolicyOptions.Secure;
            });                                      
        }

        protected virtual void PostConfigureWebApplicationOptions(WebApplicationOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected override void InitCORS(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitCORS(services);           
        }    

        protected override void InitMiscSecurity(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitMiscSecurity(services);

            services.AddAntiforgery(options =>
            {
                // This cookie is for AntiForgery ONLY you
                // This cookie CANNOT be used by any JS library for XSRF support
                //options.CookieName = "XSRF-TOKEN"; 

                // The name of the Request Header that the AntiForgery Service should
                // expect to find the AntiForgery Request Token
                // options.HeaderName = "X-XSRF-TOKEN";
                options.SuppressXFrameOptionsHeader = true;
                options.Cookie.HttpOnly = WebHostEnvironment.IsProduction();
                options.Cookie.SecurePolicy = !WebHostEnvironment.IsProduction() ?
                   Microsoft.AspNetCore.Http.CookieSecurePolicy.SameAsRequest : Microsoft.AspNetCore.Http.CookieSecurePolicy.Always;
            });
        }
      
        protected override IMvcBuilder InitMVC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            /* services.AddControllersWithViews();
            services.AddRazorPages(); same as services.AddMvc() */
            services.AddRouting(o =>
            {
                o.LowercaseUrls = true;
            });

            IMvcBuilder mvcBuilder = null;

            if (WebApplicationOptions.UseControllerViews)
            {
                mvcBuilder = services.AddControllersWithViews(o => InitMVCFilters(o))
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization(opt =>
                {
                    var resourceType = ServiceOptions.Culture.ResourceType;  
                    opt.DataAnnotationLocalizerProvider = (type, factory) =>
                            factory.Create(resourceType);
                })
                .AddJsonOptions(opt =>
                {
                    InitJsonOptions(opt);
                })                
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
                
                var part = mvcBuilder.PartManager.ApplicationParts.Where(p => p.Name == "IAZI.Common.Service").FirstOrDefault();
                mvcBuilder.PartManager.ApplicationParts.Remove(part);
                mvcBuilder.PartManager.ApplicationParts.Add(new TypesPart(typeof(CSPViolationReportController)));
            }

            if (WebApplicationOptions.UseRazorPages)
            {                
                mvcBuilder = services.AddRazorPages(options =>
                {
                })
                .AddMvcOptions(options =>
                {
                    InitRazorPagesMvcOptions(options);
                })
                .AddRazorPagesOptions(options => InitRazorPageOptions(options))
                .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
                .AddDataAnnotationsLocalization(opt =>
                {
                    var resourceType = ServiceOptions.Culture.ResourceType;
                    opt.DataAnnotationLocalizerProvider = (type, factory) =>
                            factory.Create(resourceType);
                })
                .AddJsonOptions(opt =>
                {
                    InitJsonOptions(opt);
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
               
                var part = mvcBuilder.PartManager.ApplicationParts.Where(p => p.Name == "IAZI.Common.Service").FirstOrDefault();
                mvcBuilder.PartManager.ApplicationParts.Remove(part);                        
                mvcBuilder.PartManager.ApplicationParts.Add(new TypesPart(typeof(CSPViolationReportController)));
            }

            if (WebApplicationOptions.EnableAuthorization)            
            {
                services.AddAuthorization(o =>
                {
                    InitDefaultAuthPolicy(o);
                });
            }

            return mvcBuilder;
        }     

        protected virtual void InitDefaultAuthPolicy(AuthorizationOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (ServiceOptions.Security.CreateAuthorizationDefaultPolicy)
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()                
                .RequireServiceAuthorization()
                .Build();
            }  
        }
        
        protected virtual void InitRazorPagesMvcOptions(MvcOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            // In case of issues with routing (e.g. for security of Areas, please set to false)
            options.EnableEndpointRouting = true;
        }

        protected virtual void InitRazorPageOptions(RazorPagesOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }
        }

        protected virtual void InitMVCFilters(MvcOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            // Register both CSP and CSP Report only

            if (IsNonProdHostingEnvironment)
            {
                options.Filters.Add(typeof(CspReportOnlyAttribute));
                options.Filters.Add(new CspDefaultSrcReportOnlyAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspScriptSrcReportOnlyAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspStyleSrcReportOnlyAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspConnectSrcReportOnlyAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspObjectSrcReportOnlyAttribute
                {
                    None = true
                });

                options.Filters.Add(new CspReportUriAttribute
                {
                    ReportUris = ServiceOptions.BasePath + SecurityOptions.CSPViolationReportUrl
                });

                // Add support for csp-report content
                options.InputFormatters.Where(item => item.GetType() == typeof(SystemTextJsonInputFormatter))
                 .Cast<SystemTextJsonInputFormatter>().Single().SupportedMediaTypes.Add("application/csp-report");
            }
            else
            {
                options.Filters.Add(typeof(CspAttribute));
                options.Filters.Add(new CspDefaultSrcAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspScriptSrcAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspStyleSrcAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspConnectSrcAttribute
                {
                    Self = true
                });
                options.Filters.Add(new CspObjectSrcAttribute
                {
                    None = true
                });
            }
        }
                
        protected override void InitIoC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitIoC(services);
        }        

        #endregion

        #region Protected methods - Configure

        protected override void AddSecurityHeaders(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            base.AddSecurityHeaders(app);

            app.Use(async (context, next) =>
            {
                if (context.Response.Headers["Permissions-Policy"].Count == 0)
                {                    
                    context.Response.Headers.Add("Permissions-Policy", "geolocation=(), midi=(), sync-xhr=(), microphone=(), camera=(), magnetometer=(), gyroscope=(), payment=(), fullscreen=(*)");
                }
                await next();
            });
        }

        protected override void AddProblemDetailsMiddleware(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            } 

            if (ServiceOptions.EnableCustomProblemDetailsMiddleware)
            {
                app.UseWhen(IsNonUIRequest, app =>
                    app.UseCustomProblemDetailsMiddleware()
                );            
            }            
        }

        protected override void UseExceptionHandler(IApplicationBuilder app, Microsoft.Extensions.Logging.ILogger logger)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            // Special error handling for UI requests
            app.UseWhen(IsUIRequest, app =>
            { 
                if (WebHostEnvironment.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                    app.UseDatabaseErrorPage();
                }
                else
                {
                    if (WebApplicationOptions != null && WebApplicationOptions.ErrorPage != null)
                    {
                        WebApplicationOptions.ErrorPage = ServiceOptions.BasePath + WebApplicationOptions.ErrorPage;
                        UseExceptionHandlerForUIRequests(app);                        
                    }                    
                }

                if (WebApplicationOptions != null && WebApplicationOptions.StatusCodePage != null)
                {
                    app.UseStatusCodePagesWithReExecute(ServiceOptions.BasePath + WebApplicationOptions.StatusCodePage, "?code={0}");
                }
            });

            app.UseWhen(IsNonUIRequest, app =>
            {
                if (WebHostEnvironment.IsDevelopment())
                {
                    app.UseExceptionHandler(ServiceOptions.BasePath+"/errorlocal");
                }
                else
                {
                    app.UseExceptionHandler(ServiceOptions.BasePath+"/error");
                }
            });  
        }

        protected virtual void UseExceptionHandlerForUIRequests(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            app.UseCustomExceptionHandler<ExceptionHandlerMiddleware>(WebApplicationOptions.ErrorPage);
        }

        protected virtual bool IsUIRequest(HttpContext httpContext)
        {
            var requestPath = httpContext.Request.Path;
            return requestPath == (ServiceOptions.BasePath ?? "/") || requestPath.StartsWithSegments(ServiceOptions.BasePath + "/ui", StringComparison.OrdinalIgnoreCase)
            || (ServiceOptions.Swagger.UseSwaggerUI && requestPath.StartsWithSegments(ServiceOptions.BasePath + "/swagger", StringComparison.OrdinalIgnoreCase));
            ;
        }

        protected virtual bool IsNonUIRequest(HttpContext httpContext)
        {
            return !IsUIRequest(httpContext);
        } 

        protected override void UseMVC(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }           

            app.UseStaticFiles();

            if (WebApplicationOptions != null && WebApplicationOptions.EnableCookiePolicy)
            {
                app.UseCookiePolicy();
            }

            base.UseMVC(app);
        }

        protected override void UseMVCEndpoints(IEndpointRouteBuilder endpoints)
        {
            if (endpoints == null)
            {
                throw new ArgumentNullException(nameof(endpoints));
            }

            // endpoints.MapControllers();
            // endpoints.MapHealthChecks("/health");
            // endpoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

            endpoints.MapDefaultControllerRoute();

            if (WebApplicationOptions == null || (WebApplicationOptions != null && WebApplicationOptions.UseRazorPages))
            {
                endpoints.MapRazorPages();
            }
        }

       
        protected override void UseSettings(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            base.UseSettings(app);
        }

        #endregion

        #region Protected methods 

        protected virtual void ServeFromDirectory(IApplicationBuilder app, string path)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(
                    Path.Combine(WebHostEnvironment.ContentRootPath, path)
                ),
                // UseBasePath has been already applied, it is not required here any longer
                RequestPath = "/" + path
            });
        }

        protected override void UseSwagger(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (WebApplicationOptions.UseSwagger)
            {
                base.UseSwagger(app);
            }
        }        
      
        protected override void UseCors(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (WebHostEnvironment.IsDevelopment())
            {
                app.UseCors();
            }
            else
            {
                app.UseCors("service");
            }
        }

        
        #endregion
    }
}
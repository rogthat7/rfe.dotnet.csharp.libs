using IAZI.Common.Service.Web.Controllers.Shared;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Routing;
using static IAZI.Common.Core.Models.Auth.AuthConfig;
using IAZI.Common.Core.Models.Auth;
using IAZI.Common.Service.Utils.Exceptions;
using IAZI.Common.Service.Utils;

namespace IAZI.Common.Service.Web.Init
{
    public class ServiceStartup : StartupBase
    {
        #region Properties

        public readonly static string DefaultPolicy = "auth";

        #endregion

        #region Constructor

        public ServiceStartup(IConfiguration configuration, IWebHostEnvironment env)
            : base(configuration, env)
        {
        }

        #endregion

        #region Protected methods - ConfigureServices       

        protected override IMvcBuilder InitMVC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }
         
            services.AddRouting(o =>
            {
                o.LowercaseUrls = true;
            });

            var mvcBuilder = services.AddControllers(o =>
            {
                InitDefaultControllerFilter(o);
                var jsonOutputFormatter = o.OutputFormatters.OfType<SystemTextJsonOutputFormatter>().FirstOrDefault();

                if (jsonOutputFormatter != null)
                {
                    // remove text/json as it isn't the approved media type
                    // for working with JSON at API level
                    if (jsonOutputFormatter.SupportedMediaTypes.Contains("text/json"))
                    {
                        jsonOutputFormatter.SupportedMediaTypes.Remove("text/json");
                    }
                }
            })
            .AddDataAnnotationsLocalization(opt =>
            {
                var resourceType = ServiceOptions.Culture.ResourceType ;
                opt.DataAnnotationLocalizerProvider = (type, factory) =>
                        factory.Create(resourceType);
            })
            .AddJsonOptions(opt =>
            {
                InitJsonOptions(opt);
            })
            .AddApplicationPart(typeof(IndexController).Assembly)
            .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            
            services.AddCors();

            if (ServiceOptions.Security.ServerAuthMode != ServerAuthModes.None)            
            {
                services.AddAuthorization(o =>
                {
                    InitDefaultAuthPolicy(o);
                });
            }

            return mvcBuilder;                   
        }

        protected override void InitIoC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitIoC(services);            
        }

        protected virtual void InitDefaultControllerFilter(MvcOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }                      
        }

        protected virtual void InitDefaultAuthPolicy(AuthorizationOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (ServiceOptions.Security.ServerAuthMode != ServerAuthModes.None)
            {
                if (ServiceOptions.Security.CreateAuthorizationDefaultPolicy)
                {
                    options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .RequireServiceAuthorization()
                    .Build();
                }                
            }
        }

        protected override void InitAuthentication(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            base.InitAuthentication(services);

            if (ServiceOptions.Security.ServerAuthMode == ServerAuthModes.LegacyAuth)
            {
                services.AddAuthentication(x =>
                {
                    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(x =>
                {                    
                    x.TokenValidationParameters = ServiceOptions.Security.CreateLegacyTokenValidationParameters();
                });
            }
            else if (ServiceOptions.Security.ServerAuthMode == ServerAuthModes.IdentityServer)
            {
                services.AddAuthentication(IdentityServerAuthenticationDefaults.AuthenticationScheme)
                .AddIdentityServerAuthentication(options =>
                {
                    options.Authority = ServiceOptions.Security.Authority;
                    options.RequireHttpsMetadata = ServiceOptions.Security.RequireHttpsMetadata;
                    options.ApiName = ServiceOptions.Security.ApiName;
                    options.ApiSecret = ServiceOptions.Security.ApiSecret;
                    options.SupportedTokens = SupportedTokens.Both;
                    options.NameClaimType = IAZIToken.IdentityNameClaimType;
                    options.RoleClaimType = IAZIToken.IdentityRoleClaimType;
                    options.EnableCaching = ServiceOptions.Security.EnableAccessTokenCaching;
                    options.CacheDuration = ServiceOptions.Security.AccessTokenCacheDuration;
                    options.CacheKeyPrefix = ServiceOptions.Security.AccessTokenCacheKeyPrefix;                    
                });
            }
            else if (ServiceOptions.Security.ServerAuthMode == ServerAuthModes.Both)
            {
                services.AddAuthentication(IdentityServerAuthenticationDefaults.AuthenticationScheme)
                    .AddIdentityServerAuthentication(IdentityServerAuthenticationDefaults.AuthenticationScheme,
                        jwtOptions =>
                        {
                            jwtOptions.TokenValidationParameters = ServiceOptions.Security.CreateLegacyTokenValidationParameters();
                        },
                        referenceOptions =>
                        {
                            referenceOptions.Authority = ServiceOptions.Security.Authority;
                            referenceOptions.ClientId = ServiceOptions.Security.ApiName;
                            referenceOptions.ClientSecret = ServiceOptions.Security.ApiSecret;  
                            referenceOptions.NameClaimType = IAZIToken.IdentityNameClaimType;
                            referenceOptions.RoleClaimType = IAZIToken.IdentityRoleClaimType;   
                            referenceOptions.EnableCaching = ServiceOptions.Security.EnableAccessTokenCaching;
                            referenceOptions.CacheDuration = ServiceOptions.Security.AccessTokenCacheDuration;
                            referenceOptions.CacheKeyPrefix = ServiceOptions.Security.AccessTokenCacheKeyPrefix;                          
                        });
            }
        }       

        #endregion

        #region Protected methods - Configure

        protected override void UseExceptionHandler(IApplicationBuilder app, Microsoft.Extensions.Logging.ILogger logger)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

             if (WebHostEnvironment.IsDevelopment())
            {
                app.UseCustomExceptionHandler<ExceptionHandlerMiddleware>(ServiceOptions.BasePath+"/errorlocal");
            }
            else
            {
                app.UseCustomExceptionHandler<ExceptionHandlerMiddleware>(ServiceOptions.BasePath+"/error");
            }                  
        }

        protected override void UseCors(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (WebHostEnvironment.IsDevelopment())
            {
                app.UseCors();
            }
            else
            {
                app.UseCors("service");
            }
        }

        protected override void UseMVCEndpoints(IEndpointRouteBuilder endpoints)
        {
            if (endpoints == null)
            {
                throw new ArgumentNullException(nameof(endpoints));
            }
           
            // endpoints.MapControllers();
            endpoints.MapControllerRoute("default", "v{ver:apiVersion}/{controller=Index}/{action=Get}/{id?}");
        }

        #endregion       

    }
}
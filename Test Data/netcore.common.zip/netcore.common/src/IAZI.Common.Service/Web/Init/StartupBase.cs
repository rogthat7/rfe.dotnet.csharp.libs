using IAZI.Common.Service.Services.Auth;
using IAZI.Common.Service.Utils;
using IAZI.Common.Service.Web.Controllers.Shared;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Logging;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore.Hosting;
using System.Globalization;
using Microsoft.Extensions.Hosting;
using IAZI.Common.Core.Formatter.Json;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Routing;
using Serilog;
using IAZI.Common.Service.Services.Auth.Token;
using Microsoft.AspNetCore.DataProtection;
using static IAZI.Common.Core.Models.Auth.AuthConfig;
using IAZI.Common.Core.Interfaces.Services.Utils.Logging;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Core.Interfaces.Services.Auth.Token;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Models.Web.Options;
using IAZI.Common.Service.Web.Middleware;
using IAZI.Common.Infrastructure.Logging;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Versioning.Conventions;
using Swashbuckle.AspNetCore.SwaggerGen;
using Swashbuckle.AspNetCore.Filters;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerUI;
using IAZI.Common.Core.Models.Web.Exceptions;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using IAZI.Common.Core.Interfaces.Web.Utils;
using JsonOptions = IAZI.Common.Core.Models.Web.Options.JsonOptions;
using IAZI.Common.Core.Infrastructure.Interfaces.Data.Repositories.Dapper;
using IAZI.Common.Infrastructure.Data.Repositories.Dapper;
using IAZI.Common.Service.Web.Providers;
using IAZI.Common.Core.Utils;
using AspNetCoreRateLimit;
using IAZI.Common.Service.Web.Models;
using IAZI.Common.Service.Web.Swagger;
using Microsoft.AspNetCore.Http;
using IAZI.Common.Core.Interfaces.Infrastructure.Cache.Redis;
using IAZI.Common.Infrastructure.Cache.Redis;
using StackExchange.Redis.Extensions.Core.Configuration;
using StackExchange.Redis.Extensions.System.Text.Json;
using StackExchange.Redis.Extensions.Core;
using System.Net;
using StackExchange.Redis.Extensions.Protobuf;
using StackExchange.Redis;
using StackExchange.Redis.Extensions.Core.Abstractions;
using Microsoft.AspNetCore.HttpOverrides;

namespace IAZI.Common.Service.Web.Init
{
    public abstract class StartupBase : RootStartupBase 
    {        
        #region Properties
        
        protected virtual bool IsWebApplication
        {
            get
            {
                var thisType = this.GetType();
                var webStartupType = typeof(WebStartup);
                return thisType == webStartupType || thisType.IsSubclassOf(webStartupType);
            }
        }
        
        protected readonly IConfiguration Configuration;        
    
        protected virtual bool IsNonProdHostingEnvironment
        {
            get
            {
                return WebHostEnvironment.IsDevelopment();
            }
        }     
       
        protected IWebHostEnvironment WebHostEnvironment;

        protected virtual Bootstrapper Bootstrapper
        {
            get
            {
                // Since .NET Core 3 it is not possible to inject services into Startup classes
                return Bootstrapper.GetInstance();
            }
        }

        protected ServiceOptions ServiceOptions
        {
            get; set;
        }

        // Please be aware the logger is accessible only in Configure method
        protected ILogger<StartupBase> Logger;

        protected IHttpContextAccessor HttpContextAccessor;

        private const string DefaultAssemblyNamesPrefix = "IAZI";
        protected virtual string AssemblyNamesPrefix
        {
            get
            {
                return DefaultAssemblyNamesPrefix;
            }
        }

        protected virtual IEnumerable<Assembly> ProjectAssemblies
        {
            get
            {
                return AppDomain.CurrentDomain.GetAssemblies().Where(m => m.GetName().Name.StartsWith(AssemblyNamesPrefix, true, CultureInfo.InvariantCulture));
            }
        }

        private bool _xCultureHeaderRequestCultureProviderEnabled;

        private bool _memoryCacheEnabled;       
      
        #endregion

        #region Constructor

        public StartupBase(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;
            WebHostEnvironment = env;                            
        }

        #endregion


        #region Public methods

        // This method gets called by the runtime. Use this method to add services to the container.
        public virtual void ConfigureServices(IServiceCollection services)
        {                                 
            #region Common init

            Init(services);
            
            #endregion

            #region Options

            InitOptions(services);

            #endregion

            #region Configuration Checker

            InitConfiguration(services);
            
            #endregion

            #region Localization configuration

            InitLocalization(services);
            
            #endregion
            
            #region CORS

            InitCORS(services);

            #endregion   

            #region Certificate 
            
            // Certificate was already provided via Startup Feature
            if (ServiceOptions != null && ServiceOptions.Security.Certificate.UsedCertMode != SecurityCertificateOptions.CertMode.None
            && Bootstrapper.Features.ApplicationInfo.ServerCertificate == null)            
            {                                                        
                Bootstrapper.Features.ApplicationInfo.ServerCertificate = InitCertificate();
            }
            
            #endregion                      

            #region DB and Caching
            
            InitDbAndCaching(services);
           
            #endregion

            #region Data Protection

            InitDataProtection(services);
                
            #endregion

            #region MiscSecurity

            InitMiscSecurity(services);

            #endregion

            #region ASP.NET Core Identity

            InitAspNetCoreIdentity(services);
                                    
            #endregion

            #region Authentication settings

            InitAuthentication(services);
                        
            #endregion

            #region MVC

            InitMVC(services);            
            InitApiVersioning(services);
            InitAutoMapper(services);       
            InitForwardHeaders(services);

            #endregion            
            
            #region IoC

            InitIoC(services);

            #endregion

            #region IoC

            InitStartupFilters(services);

            #endregion                       

            #region HttpClients

            InitHttpClients(services);

            #endregion   

            #region Swagger

            InitSwagger(services);

            #endregion
            
            #region Custom code

            InitCustomServices(services);

            #endregion                 
        }        

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public virtual void Configure(IApplicationBuilder app, IHostApplicationLifetime applicationLifetime)
        {            
            Logger = app.ApplicationServices.GetRequiredService<ILogger<StartupBase>>();
            HttpContextAccessor = app.ApplicationServices.GetRequiredService<IHttpContextAccessor>();
         
            var jsonFacade = app.ApplicationServices.GetRequiredService<IJsonFacade>();

            // Because the ServiceOptions doesn't have the server addresses from above because they were not
            // yet available, let's set them here as well for the startup logging            
            
            if (Bootstrapper != null)
            {               
                Bootstrapper.Features.ApplicationInfo.ServerAddresses = GetServerAddresses(app);
                Bootstrapper.Features.ApplicationInfo.ContentRootPath = WebHostEnvironment.ContentRootPath;                
                Bootstrapper.Features.ApplicationInfo.WebRootPath = WebHostEnvironment.WebRootPath;
                Bootstrapper.Features.ApplicationInfo.InitApplicationInfo(ServiceOptions, Assembly.GetEntryAssembly());
                
                applicationLifetime.ApplicationStopping.Register(Bootstrapper.Features.ShutDown);
            }   

            if (ServiceOptions != null)
            {
                var info = new IndexResponseDto();
                if (ServiceOptions != null)
                {
                    info.Init(Bootstrapper.Features.ApplicationInfo, ServiceOptions);
                    Logger.LogInformation($"Starting .Net Core web host: {jsonFacade.Serialize<IndexResponseDto>(info, ServiceOptions.Json)}");
                }                
                else 
                {
                    Logger.LogInformation("Starting .Net Core web host, no service options are available");
                }
            }

            if (_memoryCacheEnabled)
            {
                Logger.LogWarning("Memory Caching is enabled for this instance. Please note this can lead to issues when scaling by using multiple instances");
            }

            if (ServiceOptions.Data.EnableRedisCache)       
            {
                Logger.LogInformation("Redis Caching has been enabled.");
            }            

            #region Custom Middleware beginning of pipeline

            ExecutePreConfigurationActions(app);

            #endregion

            #region Problem Details

            AddProblemDetailsMiddleware(app);
            
            #endregion           

            #region Security Headers

            AddSecurityHeaders(app); 

            #endregion

            #region Exception Handler

            UseExceptionHandler(app, Logger);

            #endregion           

            #region Localization
            
            UseLocalization(app);

            #endregion  

            #region Forward Headers

            UseForwardHeaders(app);
            
            #endregion     

            #region Settings

            UseSettings(app);

            #endregion
            
            #region Swagger

            UseSwagger(app);

            #endregion
            
            #region Cors

            UseCors(app);

            #endregion

            #region Analytics

            UseAnalytics(app);

            #endregion

            #region MVC

            UseMVC(app);

            #endregion           

            #region Other stuff

            ExecutePostConfigurationActions(app);

            #endregion

            Logger.LogInformation("Configure exit");           
        }        

        #endregion

        #region Protected methods - ConfigureServices

        protected virtual void Init(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }            
        }

        protected virtual void InitOptions(IServiceCollection services)
        {               
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }           

            //Create Configuration options
            var optionsBuilder = services.AddOptions<ServiceOptions>().Bind(Configuration.GetSection(ServiceOptions.ConfigurationRoot))
            .PostConfigure(config => {
                // this code will be called with each DI flow
                PostConfigureServiceOptions(config);
            });            
            ValidateOptions(optionsBuilder);
            
             // Create Service Configuration based on passed Options
            var sp = services.BuildServiceProvider();                        
            ServiceOptions = sp.GetRequiredService<IOptions<ServiceOptions>>().Value; 

            // We need to define also the child options individually again so we are able also to request them individually 
            services.AddOptions<SecurityOptions>().Bind(Configuration.GetSection(SecurityOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureSecurityOptions(config, ServiceOptions);                
            }).ValidateDataAnnotations().Validate(SecurityOptions.ValidateSettings, "SecurityOptions validation failed");

            services.AddOptions<SecurityCertificateOptions>().Bind(Configuration.GetSection(SecurityCertificateOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureSecurityCertificateOptions(config, ServiceOptions);                
            }).ValidateDataAnnotations().Validate(SecurityCertificateOptions.ValidateSettings, "SecurityCertificateOptions validation failed");

            services.AddOptions<CultureOptions>().Bind(Configuration.GetSection(CultureOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureCultureOptions(config);                
            }).ValidateDataAnnotations().Validate(CultureOptions.ValidateSettings, "CultureOptions validation failed");

            services.AddOptions<LoggingOptions>().Bind(Configuration.GetSection(LoggingOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureLoggingOptions(config);                
            }).ValidateDataAnnotations().Validate(LoggingOptions.ValidateSettings, "LoggingOptions validation failed");

             services.AddOptions<JsonOptions>().Bind(Configuration.GetSection(JsonOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureJsonOptions(config);                
            }).ValidateDataAnnotations().Validate(JsonOptions.ValidateSettings, "JsonOptions validation failed");

            services.AddOptions<SwaggerOptions>().Bind(Configuration.GetSection(SwaggerOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureSwaggerOptions(config);                
            }).ValidateDataAnnotations().Validate(SwaggerOptions.ValidateSettings, "SwaggerOptions validation failed");
          
             services.AddOptions<DataOptions>().Bind(Configuration.GetSection(DataOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureDataOptions(config);                
            }).ValidateDataAnnotations().Validate(DataOptions.ValidateSettings, "DataOptions validation failed");

             services.AddOptions<RedisOptions>().Bind(Configuration.GetSection(RedisOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureRedisOptions(config, ServiceOptions.Security);                
            }).ValidateDataAnnotations().Validate(RedisOptions.ValidateSettings, "RedisOptions validation failed");

            services.AddOptions<AnalyticsOptions>().Bind(Configuration.GetSection(AnalyticsOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureAnalyticsOptions(config);                
            }).ValidateDataAnnotations().Validate(AnalyticsOptions.ValidateSettings, "AnalyticsOptions validation failed");

            services.AddOptions<RateLimitingOptions>().Bind(Configuration.GetSection(RateLimitingOptions.ConfigurationRoot))
            .PostConfigure(config => {                
                PostConfigureRateLimitingOptions(config);                
            }).ValidateDataAnnotations().Validate(RateLimitingOptions.ValidateSettings, "RateLimitingOptions validation failed");

            if (ServiceOptions.RateLimiting.Enable)
            {
                services.AddOptions<IpRateLimitOptions>().Bind(Configuration.GetSection(RateLimitingOptions.ConfigurationIpRateLimiting));
                services.AddOptions<IpRateLimitPolicies>().Bind(Configuration.GetSection(RateLimitingOptions.ConfigurationIpRateLimitPolicies));
                services.AddOptions<ClientRateLimitOptions>().Bind(Configuration.GetSection(RateLimitingOptions.ConfigurationClientRateLimiting));
                services.AddOptions<ClientRateLimitPolicies>().Bind(Configuration.GetSection(RateLimitingOptions.ConfigurationClientRateLimitPolicies));
            }
        } 

        protected virtual OptionsBuilder<T> ValidateOptions<T>(OptionsBuilder<T> optionsBuilder) where T: ServiceOptions
        {
            return optionsBuilder.ValidateDataAnnotations()
            .Validate(ServiceOptions.ValidateSettings, "ServiceOptions validation failed")
            .Validate(config => { return SecurityOptions.ValidateSettings(config.Security); }, "SecurityOptions validation failed")
            .Validate(config => { return SecurityCertificateOptions.ValidateSettings(config.Security.Certificate); }, "SecurityCertificateOptions validation failed")
            .Validate(config => { return CultureOptions.ValidateSettings(config.Culture); }, "CultureOptions validation failed")
            .Validate(config => { return LoggingOptions.ValidateSettings(config.Logging); }, "LoggingOptions validation failed")
            .Validate(config => { return JsonOptions.ValidateSettings(config.Json); }, "JsonOptions validation failed")
            .Validate(config => { return SwaggerOptions.ValidateSettings(config.Swagger); }, "SwaggerOptions validation failed")
            .Validate(config => { return DataOptions.ValidateSettings(config.Data); }, "DataOptions validation failed")
            .Validate(config => { return RedisOptions.ValidateSettings(config.Data.Redis); }, "RedisOptions validation failed")
            .Validate(config => { return InterfaceOptions.ValidateSettings(config.Interfaces, config.Security.ServerAuthMode, config.Swagger.UseSwaggerUIAuth); }, "InterfaceOptions validation failed")
            .Validate(config => { return AnalyticsOptions.ValidateSettings(config.Analytics); }, "AnalyticsOptions validation failed")
            .Validate(config => { return RateLimitingOptions.ValidateSettings(config.RateLimiting); }, "RateLimitingOptions validation failed");
        }

        protected virtual void InitCustomOptions<T>(IServiceCollection services, Func<T, bool> validationFunction, Action<IServiceCollection, T> postConfigureOptions, Action<IServiceCollection, CustomServiceOptions<T>> postfullConfigureOptions, string configSectionName = null) where T: CustomOptions
        {
            if (configSectionName is null)
            {
                configSectionName = CustomOptions.ConfigurationRoot;
            }
            
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (validationFunction is null)
            {
                throw new ArgumentNullException(nameof(validationFunction));
            }

            if (postConfigureOptions is null)
            {
                throw new ArgumentNullException(nameof(postConfigureOptions));
            }

            // Setup global custom service configuration that contains the existing ServiceConfiguration incl. the custom ServiceConfiguration
            services.AddSingleton<IOptions<ServiceOptions>, OptionsManager<CustomServiceOptions<T>>>();
            
            var optionBuilder = new OptionsBuilder<CustomServiceOptions<T>>(services, Options.DefaultName).Bind(Configuration.GetSection(ServiceOptions.ConfigurationRoot))
            .PostConfigure(config => {
                // this code will be called with each DI flow
                PostConfigureServiceOptions(config);
                postfullConfigureOptions(services, config);
            }).ValidateDataAnnotations();
            ValidateOptions(optionBuilder).Validate(config => { return validationFunction(config.Custom); }, "CustomOptions validation failed");            

            // Setup individual CustomConfigurationOptions
            services.AddOptions<T>().Bind(Configuration.GetSection(configSectionName))
            .PostConfigure(config => {
                // this code will be called with each DI flow    
                postConfigureOptions(services, config);            
            }).ValidateDataAnnotations().Validate(validationFunction, "CustomOptions validation failed");
        } 
      
        protected virtual void PostConfigureServiceOptions(ServiceOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }        
            
            PostConfigureInterfaceOptions(config.Interfaces);
            PostConfigureSecurityOptions(config.Security, config);     
            PostConfigureSecurityCertificateOptions(config.Security.Certificate, config);
            PostConfigureCultureOptions(config.Culture);  
            PostConfigureLoggingOptions(config.Logging);  
            PostConfigureJsonOptions(config.Json);  
            PostConfigureSwaggerOptions(config.Swagger);  
            PostConfigureDataOptions(config.Data);
            PostConfigureRedisOptions(config.Data.Redis, config.Security);
            PostConfigureAnalyticsOptions(config.Analytics);
            PostConfigureRateLimitingOptions(config.RateLimiting);
        }

        protected virtual void PostConfigureSecurityOptions(SecurityOptions config, ServiceOptions serviceOptions)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            if (serviceOptions is null)
            {
                throw new ArgumentNullException(nameof(serviceOptions));
            }

            if (config.ServerAuthMode == ServerAuthModes.IdentityServer || config.ServerAuthMode == ServerAuthModes.Both)
            {
                config.Authority = serviceOptions.GetServiceInterface(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer).BaseUrl;                
            }
            config.RequireHttpsMetadata = !WebHostEnvironment.IsDevelopment() && serviceOptions.Environment != DeployEnvironment.LOCAL && serviceOptions.Environment != DeployEnvironment.DEV;                                    


            if (config.ServiceInternalIPWhitelist == null || !config.ServiceInternalIPWhitelist.Any())
            {
                config.ServiceInternalIPWhitelist = new List<string>
                {
                    // TODO: Constants
                    "127.0.0.1", "192.168.0.0/16"
                };            
            }
        }

        protected virtual void PostConfigureSecurityCertificateOptions(SecurityCertificateOptions config, ServiceOptions serviceOptions)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
            
            var flag = EnvironmentExtensions.SwitchToCertModeNoneIfConfigInvalid;
            if (flag != null)
            {
                config.SwitchToCertModeNoneIfConfigInvalid = flag.Value;
            }            
        }

        protected virtual void PostConfigureCultureOptions(CultureOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            if (config.Supported == null || !config.Supported.Any())
            {
                config.Supported = new List<string> 
                {
                    CultureOptions.DefaultEnglishCulture,
                    CultureOptions.DefaultGermanCulture,
                    CultureOptions.DefaultFrenchCulture,
                    CultureOptions.DefaultItalianCulture
                };
            }
        }

        protected virtual void PostConfigureLoggingOptions(LoggingOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected virtual void PostConfigureJsonOptions(JsonOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected virtual void PostConfigureSwaggerOptions(SwaggerOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected virtual void PostConfigureDataOptions(DataOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            var flag = EnvironmentExtensions.EnableRedisCache;
            if (flag != null)
            {
                config.EnableRedisCache = flag.Value;
            }  
        }

        protected virtual void PostConfigureRedisOptions(RedisOptions config, SecurityOptions securityOptions)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            if (securityOptions is null)
            {
                throw new ArgumentNullException(nameof(securityOptions));
            }

            if (!string.IsNullOrEmpty(config.Config.KeyPrefix))
            {
                return;
            }

            config.Config.KeyPrefix = config.GetRedisPrefixKey(securityOptions.ApiName);
        }

        protected virtual void PostConfigureAnalyticsOptions(AnalyticsOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected virtual void PostConfigureRateLimitingOptions(RateLimitingOptions config)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }
        }

        protected virtual void PostConfigureInterfaceOptions(Dictionary<string, ServiceInterface> interfaces)
        {
            if (interfaces is null)
            {
                throw new ArgumentNullException(nameof(interfaces));
            }
        }   

        protected virtual void InitConfiguration(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 
        }

        protected virtual void InitLocalization(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 

            services.AddLocalization(options => 
            {
                // options.ResourcesPath = "Resources";                                    
            });

            services.Configure<RequestLocalizationOptions>(options =>
            {
                
                var supportedCultures = ServiceOptions.Culture.SupportedCultures;              
                options.DefaultRequestCulture = new RequestCulture(ServiceOptions.Culture.DefaultRequestCulture,
                                                                   ServiceOptions.Culture.DefaultRequestUICulture);                
                options.SupportedCultures = supportedCultures;
                options.SupportedUICultures = supportedCultures;                   

                InitLocalizationRequestCultureProviders(options);      

                _xCultureHeaderRequestCultureProviderEnabled = options.RequestCultureProviders != null &&
                                                                options.RequestCultureProviders.OfType<XCultureHeaderRequestCultureProvider>().Any();
            });
        }

        protected virtual void InitLocalizationRequestCultureProviders(RequestLocalizationOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            // You can change which providers are configured to determine the culture for requests, or even add a custom
            // provider with your own logic. The providers will be asked in order to provide a culture for each request,
            // and the first to provide a non-null result that is in the configured supported cultures list will be used.
            // By default, the following built-in providers are configured:
            // - QueryStringRequestCultureProvider, sets culture via "culture" and "ui-culture" query string values, useful for testing
            // - CookieRequestCultureProvider, sets culture via "ASPNET_CULTURE" cookie
            // - AcceptLanguageHeaderRequestCultureProvider, sets culture via the "Accept-Language" request header
            
            if (ServiceOptions.Culture.ProviderMode == CultureProviderModes.Empty)
            {
                options.RequestCultureProviders.Clear();
            }
            else
            {
                // Remove standard cookie provider from Microsoft                                
                var queryStringProvider = options.RequestCultureProviders.OfType<QueryStringRequestCultureProvider>().First();
                var acceptLanguageHeaderProvider = options.RequestCultureProviders.OfType<AcceptLanguageHeaderRequestCultureProvider>().First();
                
                options.RequestCultureProviders = new List<IRequestCultureProvider>
                {
                    queryStringProvider,
                    new XCultureHeaderRequestCultureProvider()
                };
                
                if (ServiceOptions.Culture.ProviderMode == CultureProviderModes.AppService)
                {
                    var customCookieProviderDefault = new CustomCookieRequestCultureProvider();
                    customCookieProviderDefault.CookieName = CustomCookieRequestCultureProvider.DefaultCookieName;

                    // TODO: Remove legacy provider once the old culture cookie has been removed
                    var customCookieProviderLegacy = new CustomCookieRequestCultureProvider();
                    customCookieProviderLegacy.CookieName = CultureHelper.legacyCookieName;
                    
                    options.RequestCultureProviders.Add(customCookieProviderDefault);
                    options.RequestCultureProviders.Add(customCookieProviderLegacy);
                    options.RequestCultureProviders.Add(acceptLanguageHeaderProvider);
                }
            }
        }
        
        protected virtual void InitCORS(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 

            services.AddCors(options =>
            {
                options.AddDefaultPolicy(policy =>
                {
                    policy.WithOrigins("*")
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });                  
                
                var origins = ServiceOptions.Security.CorsOrigins;
                if (string.IsNullOrEmpty(origins))
                {
                    options.AddPolicy("service", policy =>
                    {
                        policy.WithOrigins("*")
                            .AllowAnyHeader()
                            .WithMethods("GET","POST","PUT","DELETE","OPTIONS");                            
                    });
                }
                else
                {
                    var originsArr = origins.Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(o => o.Trim());

                    options.AddPolicy("service", policy =>
                    {
                        policy.WithOrigins(originsArr.ToArray())
                            .AllowAnyHeader()
                            .WithMethods("GET","POST","PUT","DELETE","OPTIONS")
                            .AllowCredentials();
                    });
                }                
            });    
        }   

        protected virtual X509Certificate2 InitCertificate()
        {
            X509Certificate2 cert = null;  
            if (ServiceOptions.Security.Certificate.UsedCertMode == SecurityCertificateOptions.CertMode.PEM)
            {
                var pathCrt = ServiceOptions.Security.Certificate.PathCrt;
                var pathKey = ServiceOptions.Security.Certificate.PathKey;
                        
                if (!String.IsNullOrEmpty(pathCrt) && !String.IsNullOrEmpty(pathKey) && File.Exists(pathCrt) && File.Exists(pathKey))
                {                    
                    cert = CertificateHelper.LoadCertificateFromFiles(pathCrt, pathKey);            
                }                 
            }
            else if (ServiceOptions.Security.Certificate.UsedCertMode == SecurityCertificateOptions.CertMode.PFX)
            {
                var pathPfx = ServiceOptions.Security.Certificate.PathCrt;
                var pfxSecret = ServiceOptions.Security.Certificate.PathKey;

                if (!String.IsNullOrEmpty(pathPfx) && !String.IsNullOrEmpty(pfxSecret) && File.Exists(pathPfx))
                {                    
                    cert = new X509Certificate2(pathPfx, pfxSecret);            
                } 
            }
            else if (ServiceOptions.Security.Certificate.UsedCertMode == SecurityCertificateOptions.CertMode.Store)
            {
                var thumbprint = ServiceOptions.Security.Certificate.StoreCertThumbprint;
                var location = ServiceOptions.Security.Certificate.StoreCertLocation;

                if (!String.IsNullOrEmpty(thumbprint))
                {                    
                    cert = CertificateHelper.LookUpCertificateInCertStore(thumbprint, location);            
                } 
            }

            return cert;
        }                    

        protected virtual void InitDbAndCaching(IServiceCollection services)
        {     
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }     

            if (ServiceOptions.RateLimiting.EnableLegacy || ServiceOptions.RateLimiting.Enable) 
            {
                // TODO: This needs to be replaced by Redis                
                services.AddMemoryCache();                 
                _memoryCacheEnabled = true;         
            }     

            if (ServiceOptions.Data.EnableRedisCache)       
            {
                // We can set statically SystemTextJsonSerializer as Serializer because the IoC method
                // will ovderride this again depending on the Redis Serializer configuration
                services.AddStackExchangeRedisExtensions<SystemTextJsonSerializer>(ServiceOptions.Data.Redis.Config);
            }
        }

        protected virtual void InitDataProtection(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }  

            // To understand this, check https://codeopinion.com/asp-net-core-data-protection/  
            // and https://docs.microsoft.com/en-us/aspnet/core/security/data-protection/configuration/overview?view=aspnetcore-3.1  
            if (ServiceOptions.Security.InitDataProtection)
            {
                var keyLifeTime = ServiceOptions.Security.DataProtectionKeyLifeTimeInDays;
                
                if (ServiceOptions.Data.EnableRedisCache && ServiceOptions.Security.UseDataProtectionRedisStore)
                {
                    var redisKeyPrefix = ServiceOptions.Data.Redis.GetRedisPrefixKey(ServiceOptions.Security.ApiName);
                    var key = new RedisKey($"{redisKeyPrefix}DataProtection-Keys");
                    var sp = services.BuildServiceProvider();
                    var redisCacheConnectionPoolManager = sp.GetService<IRedisCacheConnectionPoolManager>();
                    
                    if (Bootstrapper.Features.ApplicationInfo.ServerCertificate != null
                    && Bootstrapper.Features.ApplicationInfo.ServerCertificate.HasPrivateKey)
                    {
                        services
                                .AddDataProtection()
                                .SetDefaultKeyLifetime(TimeSpan.FromDays(keyLifeTime))
                                .PersistKeysToStackExchangeRedis(redisCacheConnectionPoolManager.GetConnection(), key)
                                .ProtectKeysWithCertificate(Bootstrapper.Features.ApplicationInfo.ServerCertificate);                                   
                    } 
                    else
                    {
                        services
                                .AddDataProtection()
                                .SetDefaultKeyLifetime(TimeSpan.FromDays(keyLifeTime))
                                .PersistKeysToStackExchangeRedis(redisCacheConnectionPoolManager.GetConnection(), key);
                    }   
                }
                else
                {
                    var diDataProtection = ServiceOptions.Security.DataProtectionFolder != null ? new DirectoryInfo(ServiceOptions.Security.DataProtectionFolder) : null;                
                
                    if (diDataProtection != null && !diDataProtection.Exists)
                    {
                        diDataProtection = new DirectoryInfo(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
                    }
                    // Unfortunately builder pattern doesn't work and will lead to issues when in use
                    
                    if (Bootstrapper.Features.ApplicationInfo.ServerCertificate != null
                        && Bootstrapper.Features.ApplicationInfo.ServerCertificate.HasPrivateKey)
                    {
                        services
                                .AddDataProtection()
                                .SetDefaultKeyLifetime(TimeSpan.FromDays(keyLifeTime))
                                .PersistKeysToFileSystem(diDataProtection) 
                                .ProtectKeysWithCertificate(Bootstrapper.Features.ApplicationInfo.ServerCertificate);                                   
                    } 
                    else
                    {
                        services
                                .AddDataProtection()
                                .SetDefaultKeyLifetime(TimeSpan.FromDays(keyLifeTime))
                                .PersistKeysToFileSystem(diDataProtection); 
                    }   
                }                                            

                if (ServiceOptions.Security.UseNullDataProtectionProvider)
                {
                    services.AddNullDataProtectionProvider();
                }
            } 
        }

        protected virtual void InitMiscSecurity(IServiceCollection services)
        {        
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }  
        }

        protected virtual void InitAspNetCoreIdentity(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 
        }

        protected abstract IMvcBuilder InitMVC(IServiceCollection services);

        protected virtual void InitApiVersioning(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
            
            services.AddApiVersioning(o =>
            {
                // reporting api versions will return the headers "api-supported-versions" and "api-deprecated-versions"
                o.AssumeDefaultVersionWhenUnspecified = true;                
                o.ReportApiVersions = true;
                o.Conventions.Add(new VersionByNamespaceConvention());                
            });

            services.AddVersionedApiExplorer(
                options =>
                {
                    // add the versioned api explorer, which also adds IApiVersionDescriptionProvider service
                    // note: the specified format code will format the version as "'v'major[.minor][-status]"
                    options.GroupNameFormat = "'v'VVV";

                    // note: this option is only necessary when versioning by url segment. the SubstitutionFormat
                    // can also be used to control the format of the API version in route templates
                    options.SubstituteApiVersionInUrl = true;
                });
        }
        
        protected virtual void InitAutoMapper(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (ServiceOptions == null || !ServiceOptions.UseAutomapper)
            {
                return;
            }

            services.AddAutoMapper(ProjectAssemblies);  
        }

        protected virtual void InitForwardHeaders(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (ServiceOptions == null || !ServiceOptions.UseForwardHeaders)
            {
                return;
            }

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });
        }

        protected virtual void InitJsonOptions(Microsoft.AspNetCore.Mvc.JsonOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            ServiceOptions.Json.ApplyJsonSettings(options.JsonSerializerOptions);            
        }

        protected virtual void InitIoC(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }  
                       
            services.AddSingleton<Bootstrapper>((s) => Bootstrapper);
            services.AddSingleton<IApplicationInfo>((s) => Bootstrapper.Features.ApplicationInfo);
                       
            services.AddScoped<IUserClaimInfoService, UserClaimInfoService>();  
            // Since Requirement handlers have access to HttpContext, we need to add this earlier
            services.AddHttpContextAccessor();
            services.AddScoped<IAuthorizationHandler, ServiceAuthorizationRequirementHandler>();  
            services.AddScoped<IServiceAuthorizationValidator, ServiceAuthorizationValidator>();
            services.AddSingleton<IJsonFacade, JsonSystemTextFacade>();             
            services.AddSingleton<IEnvironmentLoggingEnricher, EnvironmentLoggingEnricher>();                                     

            services.AddScoped<IStringLocalizer>((s) =>
            {                
                var factory = s.GetService<IStringLocalizerFactory>();                
                var type = ServiceOptions.Culture.ResourceType;
                var assemblyName = new AssemblyName(type.GetTypeInfo().Assembly.FullName);
                return factory.Create(type);
            }); 
            
            services.AddSingleton<ITokenContainer>((s) => {
                return TokenContainer.GetInstance();
            });
            
            services.AddSingleton<IHttpClientTokenHandlerFactory, HttpClientTokenHandlerFactory>();             
            services.AddTransient<ProblemDetailsFactory, CustomProblemDetailsFactory>();

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider =>
            {
                var connectionString = ServiceOptions.Data.GetDbConnectionString();
                return new UnitOfWork(connectionString);
            });   

            services.AddScoped<InternalOnlyFilter>(); 

            if (ServiceOptions.RateLimiting.Enable)
            {
                // inject counter and rules stores
                services.AddSingleton<IIpPolicyStore, MemoryCacheIpPolicyStore>();
                services.AddSingleton<IRateLimitCounterStore, MemoryCacheRateLimitCounterStore>();

                // inject counter and rules stores
                services.AddSingleton<IClientPolicyStore, MemoryCacheClientPolicyStore>();
                services.AddSingleton<IRateLimitCounterStore, MemoryCacheRateLimitCounterStore>();

                // configuration (resolvers, counter key builders)
                services.AddSingleton<IRateLimitConfiguration, RateLimitConfiguration>();            
            }

            if (ServiceOptions.Data.EnableRedisCache)       
            {
                if (ServiceOptions.Data.Redis.Serializer == RedisOptions.SerializerType.GzipJson)
                {
                    services.AddSingleton<ISerializer, GzipJsonSerializer>();
                }
                else if (ServiceOptions.Data.Redis.Serializer == RedisOptions.SerializerType.ProtoBuf)
                {
                    services.AddSingleton<ISerializer, ProtobufSerializer>();
                }
                else
                {
                    // TODO: Could be our serializer based on JsonSystemTextFacade
                    services.AddSingleton<ISerializer, SystemTextJsonSerializer>();
                }
                
                services.AddSingleton<ICacheFacade, CacheFacade>();                
                services.AddSingleton<RedisConfiguration>((s) => {
                    var config = s.GetService<IOptions<RedisOptions>>();                
                    return config.Value.Config;
                });
            }
        }

        protected virtual void InitStartupFilters(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }  
        }

        protected virtual void InitAuthentication(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }           
        }
        
        protected virtual void InitHttpClients(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }  

            if (ServiceOptions.Security.ServerAuthMode != ServerAuthModes.None)
            {            
                services.RegisterAuthHttpClient(ServiceOptions);
                services.RegisterLegacyAuthHttpClient(ServiceOptions);
            }
        }         
        
        protected virtual void InitSwagger(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(options =>
            {                                              
                // In case string enums are used we can simply apply the inline definitions filter for enums
                // but in case also JsonStringEnumConverter is not used we cannot do this because it would
                // block the nice enum descriptions                
                if (ServiceOptions.Json.UseJsonStringEnumConverter && ServiceOptions.Swagger.UseInlineDefinitionsForEnums)
                {
                    options.UseInlineDefinitionsForEnums();
                }
                
                // add a custom operation filter which sets default values
                options.OperationFilter<SwaggerDefaultValues>();
                options.ExampleFilters();                

                // integrate xml comments                
                foreach(var assembly in ProjectAssemblies)
                {
                    var xmlFile = $"{assembly.GetName().Name}.xml";
                    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                                    
                    if (xmlPath != null && File.Exists(xmlPath))
                    {
                        options.IncludeXmlComments(xmlPath);              
                    }    
                }

                if (!ServiceOptions.Json.UseJsonStringEnumConverter)
                {
                    options.DocumentFilter<SwaggerAddEnumDescriptions>();
                }                   
                                
                if (ServiceOptions.Security.ServerAuthMode == ServerAuthModes.Both
                || ServiceOptions.Security.ServerAuthMode == ServerAuthModes.LegacyAuth)
                {
                    //custom Basic Auth to set Legacy Token in request Headers
                    options.AddSecurityDefinition("LegacyAuth", new OpenApiSecurityScheme
                    {
                        Type = SecuritySchemeType.Http,
                        Scheme = "Basic",
                        Description = "Input your username and password to access this API",
                        In = ParameterLocation.Header
                    });
                }

                if (ServiceOptions.Security.ServerAuthMode == ServerAuthModes.Both
                || ServiceOptions.Security.ServerAuthMode == ServerAuthModes.IdentityServer)
                {
                    // validation was already done before 
                    var baseUrl = ServiceOptions.GetServiceInterface(InterfaceOptions.InterfaceOptionKeyServiceAuthIdentityServer).BaseUrl;

                    //security definition for access token
                    options.AddSecurityDefinition("IdentityServer", new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "IdentityServer"
                        },
                        In = ParameterLocation.Header,
                        Name = "Bearer",
                        Scheme = "oauth2",
                        Type = SecuritySchemeType.OAuth2,
                        Flows = new OpenApiOAuthFlows
                        {
                            Implicit = new OpenApiOAuthFlow
                            {
                                AuthorizationUrl = new Uri(baseUrl + "/connect/authorize"),
                                TokenUrl = new Uri(baseUrl + "/connect/token"),
                                Scopes = new Dictionary<string, string>
                                {
                                    { ServiceOptions.Security.ApiName, "" },
                                    { "openid", "" },
                                    { "email", "" },
                                    { "profile",""}
                                }
                            }
                        }
                    });

                    options.OperationFilter<CustomHeaderOperationFilter>();
                    options.OperationFilter<ProblemDetailsOperationFilter>();

                    //security requirement for access token
                    options.AddSecurityRequirement(new OpenApiSecurityRequirement
                        {
                            {
                                new OpenApiSecurityScheme
                                {
                                    Reference=new OpenApiReference{Type=ReferenceType.SecurityScheme,Id="IdentityServer"},
                                    Scheme="oauth2",
                                    Name="Bearer",
                                    In=ParameterLocation.Header
                                },
                                new List<string>{"openid","email","profile",ServiceOptions.Security.ApiName}
                            }
                        });
                } 

                // injecting HttpContextAccessor here is safe since it's registered as a singleton!
                if (ServiceOptions.Swagger.UseHideInternalEndpoints)
                {
                    options.DocumentFilter<InternalOnlyFilter>
                            (Bootstrapper.Features.ApplicationInfo.InternalIPWhitelist, HttpContextAccessor);
                }               
            }); 

            services.AddSwaggerExamplesFromAssemblyOf(this.GetType());   
        }
        
        protected virtual void InitCustomServices(IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            } 
            
            // Show detailed information for IdentityModel logs
            IdentityModelEventSource.ShowPII = ServiceOptions.Logging.ShowPII;
        }
        
        #endregion 

        #region Protected methods - Configure

        protected virtual void ExecutePreConfigurationActions(IApplicationBuilder app)
        {    
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }        
        }

        protected virtual void AddProblemDetailsMiddleware(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            } 

            if (ServiceOptions.EnableCustomProblemDetailsMiddleware)
            {
                app.UseCustomProblemDetailsMiddleware(); 
            }            
        }

        protected virtual void AddRateLimiting(IApplicationBuilder app)
        {    
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }       

            if (ServiceOptions.RateLimiting.Enable) 
            {
                if (ServiceOptions.RateLimiting.IpRateLimiting != null) 
                {
                    app.UseIpRateLimiting();
                }

                if (ServiceOptions.RateLimiting.ClientRateLimiting != null) 
                {
                    app.UseClientRateLimiting();
                }
            }
        }

        protected virtual void AddSecurityHeaders(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }           

            if (!this.IsNonProdHostingEnvironment)
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                // app.UseHsts(); // Done on Nginx level
                // Set CSP headers quite strict, please note that can be simply overwritten
                // see https://docs.nwebsec.com/en/latest/nwebsec/NWebsec.AspNetCore.Mvc.html
                 app.UseCsp(options => options
                    .DefaultSources(s => s.Self())
                    .ScriptSources(s => s.Self())
                    .StyleSources(s => s.Self())
                    .ConnectSources(s => s.Self())
                    .ImageSources(s => s.Self())
                    .ObjectSources(s => s.None())                    
                    );
                    //.ReportUris(r => r.Uris("/__cspreport__"))); 
            }
            else
            {
                 app.UseCspReportOnly(options => options
                    .DefaultSources(s => s.Self())
                    .ScriptSources(s => s.Self())
                    .StyleSources(s => s.Self())
                    .ConnectSources(s => s.Self())
                    .ImageSources(s => s.Self())
                    .ObjectSources(s => s.None())
                    .ReportUris(r => r.Uris(ServiceOptions.BasePath + SecurityOptions.CSPViolationReportUrl))); 
            }

            if (!string.IsNullOrEmpty(ServiceOptions.BasePath))
            {                
                ServiceOptions.Security.CSPExcludedEndpoints.ForEach(c => 
                {
                    if (!c.Name.StartsWith(ServiceOptions.BasePath))
                    {
                        c.Name = ServiceOptions.BasePath + c.Name;
                    }                     
                });
            }
            
            // Add swagger related endpoints as Exception for CSP
            ServiceOptions.Security.CSPExcludedEndpoints.Add(new CSPExcludedEndpoint
            {
                ComparisonMode = CSPExcludedEndpoint.ComparisonModeEnum.StartsWith,
                Name = ServiceOptions.BasePath + "/swagger",
                CustomCSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'"
            });

            if (ServiceOptions.IsLocalEnvironment())
            {
                ServiceOptions.Security.CSPExcludedEndpoints.Add(new CSPExcludedEndpoint
                {
                    ComparisonMode = CSPExcludedEndpoint.ComparisonModeEnum.StartsWith,
                    Name = "/swagger",
                    CustomCSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'"
                });
            }

            app.Use(async (context, next) =>  
            {                  
                const string cspHeader = "Content-Security-Policy";
                const string cspHeaderX = "X-Content-Security-Policy";
                const string cspHeaderReportOnly = "Content-Security-Policy-Report-Only";
                const string xFrameOptionsHeader = "X-Frame-Options";

                if (ServiceOptions.Security.CSPExcludedEndpoints != null)
                {
                    var contextPath = context.Request.Path.Value;
                    var excludedEndpoint = ServiceOptions.Security.CSPExcludedEndpoints.FirstOrDefault(c =>                                 
                            (c.ComparisonMode == CSPExcludedEndpoint.ComparisonModeEnum.Equals &&
                            c.Name != null && c.Name.Equals(contextPath, StringComparison.InvariantCultureIgnoreCase))
                            ||
                            (c.ComparisonMode == CSPExcludedEndpoint.ComparisonModeEnum.StartsWith &&
                            c.Name != null && contextPath.StartsWith(c.Name, true, CultureInfo.InvariantCulture)));                   
                    
                    if (excludedEndpoint != null)
                    {                        
                        // Handle custom X-Frame Options
                        if (excludedEndpoint.RemoveXFrameOptionsHeader || !string.IsNullOrEmpty(excludedEndpoint.CustomXFrameOption))
                        {
                            if (context.Response.Headers.Keys.Contains(xFrameOptionsHeader))                        
                            {
                                context.Response.Headers.Remove(xFrameOptionsHeader);                               
                            }                        

                            if (!string.IsNullOrEmpty(excludedEndpoint.CustomXFrameOption))
                            {
                                string customXFrameOptionsHeader = null;

                                if (IsNonProdHostingEnvironment)
                                {
                                    customXFrameOptionsHeader = excludedEndpoint.CustomXFrameOptionLocalDev ?? excludedEndpoint.CustomXFrameOption;
                                }
                                else
                                {
                                    customXFrameOptionsHeader = excludedEndpoint.CustomXFrameOption;
                                }

                                context.Response.Headers.Add(xFrameOptionsHeader, customXFrameOptionsHeader);  
                            }                             
                        }                        
                        
                        string existingCspHeader = null;
                        string existingCspHeaderReportOnly = null;                        

                        // Check existing CSP from previous middleware
                        if (context.Response.Headers.Keys.Contains(cspHeader))
                        {
                            existingCspHeader = context.Response.Headers[cspHeader];  
                            context.Response.Headers.Remove(cspHeader);                                                       
                        }
                        
                        if (context.Response.Headers.Keys.Contains(cspHeaderReportOnly))
                        {
                            existingCspHeaderReportOnly = context.Response.Headers[cspHeaderReportOnly];  
                            context.Response.Headers.Remove(cspHeaderReportOnly);                                                                                        
                        }                         

                        // Check for custom CSP
                        if (!string.IsNullOrEmpty(excludedEndpoint.CustomCSP))
                        {
                            string customCSPHeader = null;                            
                            
                            // For NonProd envs we will always work with ReportOnly header
                            if (IsNonProdHostingEnvironment)
                            {
                                // Check the custom CSP for DEV purposes for the report-uri 
                                if (!string.IsNullOrEmpty(excludedEndpoint.CustomCSPLocalDev)
                                 && !excludedEndpoint.CustomCSPLocalDev.Contains(SecurityOptions.CSPViolationReportUrl)
                                 && !excludedEndpoint.UseNonReportOnlyCSPInDEV)
                                {
                                    excludedEndpoint.CustomCSPLocalDev = excludedEndpoint.CustomCSPLocalDev + "report-uri " + ServiceOptions.BasePath + SecurityOptions.CSPViolationReportUrl + ";";
                                }
                                                                
                                if (excludedEndpoint.ActionMode == CSPExcludedEndpoint.ActionModeEnum.Append && !string.IsNullOrEmpty(existingCspHeader))
                                {
                                    customCSPHeader = (existingCspHeaderReportOnly ?? existingCspHeader) + " " + excludedEndpoint.CustomCSPLocalDev ?? excludedEndpoint.CustomCSP;                                    
                                }
                                else 
                                {
                                    customCSPHeader = excludedEndpoint.CustomCSPLocalDev ?? excludedEndpoint.CustomCSP;
                                } 

                                if (excludedEndpoint.ActionMode == CSPExcludedEndpoint.ActionModeEnum.AddAdditional)
                                {
                                    context.Response.Headers.Add(excludedEndpoint.UseNonReportOnlyCSPInDEV ? cspHeader : cspHeaderReportOnly, new[]{ (excludedEndpoint.UseNonReportOnlyCSPInDEV ? (existingCspHeader ?? existingCspHeaderReportOnly) : existingCspHeaderReportOnly), customCSPHeader }); 
                                }
                                else
                                {
                                    context.Response.Headers.Add(excludedEndpoint.UseNonReportOnlyCSPInDEV ? cspHeader : cspHeaderReportOnly, customCSPHeader);   
                                }                                
                            }
                            else 
                            {
                                if (ServiceOptions.IsDevEnvironment())                                 
                                {
                                    if (excludedEndpoint.ActionMode == CSPExcludedEndpoint.ActionModeEnum.Append && !string.IsNullOrEmpty(existingCspHeader))
                                    {
                                        customCSPHeader = existingCspHeader + " " + (excludedEndpoint.CustomCSPLocalDev ?? excludedEndpoint.CustomCSP);                                   
                                    }
                                    else 
                                    {                                    
                                        customCSPHeader = excludedEndpoint.CustomCSPLocalDev ?? excludedEndpoint.CustomCSP;
                                    } 
                                }
                                else
                                {
                                    if (excludedEndpoint.ActionMode == CSPExcludedEndpoint.ActionModeEnum.Append && !string.IsNullOrEmpty(existingCspHeader))
                                    {
                                        customCSPHeader = existingCspHeader + " " + excludedEndpoint.CustomCSP;                                   
                                    }
                                    else 
                                    {
                                        customCSPHeader = excludedEndpoint.CustomCSP;
                                    } 
                                }                                
                                
                                if (excludedEndpoint.ActionMode == CSPExcludedEndpoint.ActionModeEnum.AddAdditional)
                                {
                                    context.Response.Headers.Add(cspHeader, new[]{ existingCspHeader, customCSPHeader }); 
                                }
                                else
                                {
                                    context.Response.Headers.Add(cspHeader, customCSPHeader);   
                                }    
                            }                           
                        }                         
                    }  
                }
                                                           
                if (context.Response.Headers.Keys.Contains(cspHeader)
                && !context.Response.Headers.Keys.Contains(cspHeaderX))
                {
                    context.Response.Headers.Add(  
                            cspHeaderX,  
                            context.Response.Headers[cspHeader]);  
                }               

                await next();  
            });
        }
        
        protected abstract void UseExceptionHandler(IApplicationBuilder app, Microsoft.Extensions.Logging.ILogger logger);        

        
        protected virtual void UseAnalytics(IApplicationBuilder app)
        {
            if (ServiceOptions.Analytics.Enable)
            {
                app.UseAnalytics();
            }
        }        
        
        protected virtual void UseLocalization(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }
                        
            var locOptions = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();
            app.UseRequestLocalization(locOptions.Value);
        }

        protected virtual void UseForwardHeaders(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }                                   

            if (!ServiceOptions.UseForwardHeaders)
            {
                return;
            }
            
            app.UseForwardedHeaders();
        }        
      
        protected virtual void UseSettings(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }                                   

            // Use Hsts and HttpsRedirection in case of a Kestrel internal https cert
            if (ServiceOptions.Security.Certificate.UsedCertMode != SecurityCertificateOptions.CertMode.None
                && Bootstrapper.Features.ApplicationInfo.ServerCertificate != null
                && ServiceOptions.Security.Certificate.UseServerCertificateForSecuredKestrel)
            {
                app.UseHsts();
                app.UseHttpsRedirection(); // Don't do this in Docker environments running with http
            }
            
            if (!string.IsNullOrEmpty(ServiceOptions.BasePath))
            {
                app.UsePathBase(ServiceOptions.BasePath);  
            }
        }

        protected virtual void UseSwagger(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            // Check https://docs.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-2.2&tabs=visual-studio-code
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger(o =>
            {                          
            });

            if (ServiceOptions.Swagger.UseSwaggerUI)
            {
                var apiVersionDescriptionProvider = app.ApplicationServices.GetRequiredService<IApiVersionDescriptionProvider>();
                app.UseSwaggerUI(
                options =>
                {
                    if (ServiceOptions.Swagger.UseSwaggerUIAuth && ServiceOptions.Security.ServerAuthMode != ServerAuthModes.None)
                    {                        
                        UseSwaggerUIAuthOptions(app, options);                      
                    }
                    
                    // build a swagger endpoint for each discovered API version
                    // https://github.com/microsoft/aspnet-api-versioning/tree/master/samples/aspnetcore/SwaggerSample
                    foreach (var description in apiVersionDescriptionProvider.ApiVersionDescriptions)
                    {
                        options.SwaggerEndpoint($"{ServiceOptions.BasePath}/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                    }
                });
            }
        }   

        protected virtual void UseSwaggerUIAuthOptions(IApplicationBuilder app, SwaggerUIOptions options)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (!string.IsNullOrEmpty(ServiceOptions.Swagger.SwaggerUIIndexStream))
            {                
                Logger.LogDebug($"Using {ServiceOptions.Swagger.SwaggerUIIndexStream} as SwaggerUI Index stream");
                app.UseStaticFiles();
                options.IndexStream = () => GetType().Assembly.GetManifestResourceStream(ServiceOptions.Swagger.SwaggerUIIndexStream);                            
            } 

            var swaggerClient = ServiceOptions.GetServiceInterface(InterfaceOptions.InterfaceOptionKeyIAZISwagger).Name;
            if (string.IsNullOrEmpty(swaggerClient))
            {
                throw new Exception($"UseSwaggerUIAuthOptions error - The name for interface'{InterfaceOptions.InterfaceOptionKeyIAZISwagger}' is not available in settings");
            }

            var appName = ServiceOptions.Security.AppName;
            if (appName == null)
            {
                appName=string.Empty;
            }

            options.ConfigObject.AdditionalItems.Add("appName", ServiceOptions.Security.AppName);
            options.OAuthClientId(swaggerClient);
            options.OAuthAppName(swaggerClient);
            options.OAuthScopeSeparator(" ");
            options.OAuthAdditionalQueryStringParams(new Dictionary<string, string> { { "nonce", Guid.NewGuid().ToString() } });
        }

        protected abstract void UseCors(IApplicationBuilder app);
        
        protected virtual void UseMVC(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (ServiceOptions.Logging.UseSerilogRequestLoggging)
            {                
                app.UseSerilogRequestLogging();
            }
            
            app.UseRouting();                               

            UseMVCAuthentication(app);

            #region Rate Limiting

            AddRateLimiting(app);

            #endregion

            if (ServiceOptions.Logging.UseSerilogUserInfoLogging)
            {
                app.UseUserInfoLogging();
            }

            app.UseEndpoints(endpoints =>
            {
                UseMVCEndpoints(endpoints);
            });           
        }  

        protected abstract void UseMVCEndpoints(IEndpointRouteBuilder endpoints);       

        protected virtual void UseMVCAuthentication(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (ServiceOptions.Security.ServerAuthMode != ServerAuthModes.None)
            {
                // flipped because https://stackoverflow.com/questions/56185834/asp-net-core-api-always-returns-401-unauthorized-whenever-i-send-a-request-with
                app.UseAuthentication();
                app.UseAuthorization();   
            }
        } 

        protected virtual void ExecutePostConfigurationActions(IApplicationBuilder app)
        {            
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            if (ServiceOptions.Data.EnableRedisCache && ServiceOptions.Data.Redis.EnableRedisInformationMiddleware)
            {                
                app.UseRedisInformation(o => 
                {
                    o.AllowedIPs = Array.Empty<IPAddress>();
                    o.AllowFunction = (HttpContext ctx) =>
                    {
                        var requestIpAddress = ctx.GetRequestIpAddress();
                        return IPAddressHelper.IPAddressIsInIPSafeList(requestIpAddress, Bootstrapper.Features.ApplicationInfo.InternalIPWhitelist);
                    }; 
                });                
            }
        }

        protected virtual ICollection<string> GetServerAddresses(IApplicationBuilder app)
        {
            if (app is null)
            {
                throw new ArgumentNullException(nameof(app));
            }

            // Please note that only Addresses where available that are pre-defined (so default port 5000 won't be shown)
            var serverAddressFeature = app.ServerFeatures.Get<IServerAddressesFeature>();
            return serverAddressFeature != null ? serverAddressFeature.Addresses : null;
        }

        #endregion
        
    }
}

using System;

namespace IAZI.Common.Service.Web.Init
{
    public class Bootstrapper : IDisposable
    {
        #region Properties Singleton

        private static Bootstrapper _bootstrapper = new Bootstrapper
        {           
        };            

        /// <summary>
        /// Returns single instance of Bootstrapper
        /// </summary>
        /// <returns></returns>
        public static Bootstrapper GetInstance() => _bootstrapper;                                 

        #endregion

        #region Properties

        private BootstrapperFeatures _features;

        public BootstrapperFeatures Features 
        {
            get
            {
                if (_features == null)
                {
                    _features = new BootstrapperFeatures();
                }
                
                return _features;
            }
        }                                 

        #endregion

        #region Constructor

        private Bootstrapper()
        {            
        }
            
        #endregion

        #region Public methods

        public Bootstrapper SetFeatures(BootstrapperFeatures features)
        {
            if (features == null)
            {
                throw new ArgumentNullException(nameof(features));
            }

            _features = features;

            return this;
        }
        
        public void Dispose()
        {           
            if (_features != null)
            {
                _features.Dispose();
                _features = null;
            }            
            
            _bootstrapper = new Bootstrapper
            {           
            };            
        }

        #endregion


    }
}
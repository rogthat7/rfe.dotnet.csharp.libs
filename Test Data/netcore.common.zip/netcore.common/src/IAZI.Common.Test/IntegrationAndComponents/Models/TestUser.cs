using System.Collections.Generic;
using System.Security.Claims;
using IAZI.Common.Core.Interfaces.Models.Auth;

namespace IAZI.Common.Test.IntegrationAndComponents.Models
{
    /// <summary>
    /// Unfortunately for Theory based tests with inline data it won't be possible to adjust the testuser between
    /// the different tests. The only chance to ensure this is to work with a static member
    /// </summary>
    public class TestUser
    {                
        #region Properties
      
        public virtual IAuthBase AuthData
        {
            get;
            set;
        }
        
        public virtual bool DisableAuthentication
        {
            get;
            set;
        }

        public virtual bool DisableAuthorization
        {
            get;
            set;
        }
               
        public virtual string IpAddress
        {
            get;
            set;
        } = "192.169.9.100"; // Any IAZI internal IP

        public virtual IEnumerable<Claim> UserClaims 
        {
            get;
            set;
        } = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, "12345678-1234-1234-1234-123456789012"),
                new Claim(ClaimTypes.Name, "TestUser"),
                new Claim(ClaimTypes.Email, "test.user@example.com")                
            };

        private static TestUser _testUser = new TestUser();

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private TestUser()
        {            
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Gets the singleton
        /// </summary>
        /// <returns></returns>
        public static TestUser GetInstance()
        {
            return _testUser;
        }                
            
        #endregion
        
        
    }
}
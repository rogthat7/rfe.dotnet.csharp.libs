using System;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Logging;
using Xunit.Abstractions;
using IAZI.Common.Test.Utils.Logging;
using System.Net;
using System.Threading.Tasks;
using IAZI.Common.Service.Utils;
using System.Collections;
using FluentAssertions;
using System.Collections.Generic;
using System.Linq;
using IAZI.Common.Test.IntegrationAndComponents.Models;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Interfaces.Web.Formatter.Json;
using IAZI.Common.Core.Formatter.Json;
using IAZI.Common.Core.Models.Web.Exceptions;
using JsonOptions = IAZI.Common.Core.Models.Web.Options.JsonOptions;
using System.Security.Claims;

namespace IAZI.Common.Test.IntegrationAndComponents.Shared
{
    /// <summary>
    /// Base class to test Controller logic via Integration testing
    /// </summary>
    /// <typeparam name="TStartup"></typeparam>
    public abstract class IntegrationAndComponentTestBase<TStartup> : IDisposable where TStartup: RootStartupBase
    {
        #region Properties
       
        private string _customIpAddress = "192.168.9.76";
        protected virtual string CustomIpAddress
        {
            get
            {
                // some internal IP Address to set since
                // with in memory service the IP address of the client would be 255.255.255.255
                // this approach allows to customize even IP Address for requests to test e.g. logic based on IP address
                return _customIpAddress;
            }
        }
        
        private readonly TestWebApplicationFactoryBase<TStartup> _factory;

        protected HttpClient HttpClient
        {
            get;
            private set;
        }  

        protected readonly ILogger<IntegrationAndComponentTestBase<TStartup>> Logger;

        /// <summary>
        /// TestUser Singleton instance
        /// </summary>
        /// <returns></returns>
        protected TestUser TestUser
        {
           get
           {
               return TestUser.GetInstance();
           }            
        }

        private IJsonFacade _jsonFacade;
        protected IJsonFacade JsonFacade
        {
            get
            {
                if (_jsonFacade == null)
                {
                    _jsonFacade = new JsonSystemTextFacade();
                }
                
                return _jsonFacade;
            }
        }

        private JsonOptions _jsonConfigurationOptions;
        protected virtual JsonOptions JsonOptions
        {
            get
            {
                if (_jsonConfigurationOptions == null)
                {
                    // Use default json options, overwrite this property to use a different one
                    _jsonConfigurationOptions = new JsonOptions();
                }
                
                return _jsonConfigurationOptions;
            }
        }
            
        #endregion

        #region Constructor        
      
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="factory"></param>
        public IntegrationAndComponentTestBase(ITestOutputHelper testOutputHelper, TestWebApplicationFactoryBase<TStartup> factory)
        {
            _factory = factory;           
            if (testOutputHelper != null)
            {
                Logger = testOutputHelper.CreateLogger<IntegrationAndComponentTestBase<TStartup>>();
            }
        }
            
        #endregion

        #region Public methods

        /// <summary>
        /// Dispose
        /// </summary>
        public virtual void Dispose()
        {
            if (HttpClient != null)
            {
                HttpClient.Dispose();
            }
        }
            
        #endregion

        #region Protected methods

        /// <summary>
        /// Change custom ip address
        /// </summary>
        /// <param name="ipAddress"></param>
        protected void ChangeCustomIpAddress(string ipAddress)
        {
            if (string.IsNullOrEmpty(ipAddress))
            {
                throw new ArgumentNullException(nameof(ipAddress));
            }

            _customIpAddress = ipAddress;
        }

        /// <summary>
        /// Request services via IoC
        /// </summary>
        /// <typeparam name="T"></typeparam>
        protected T GetService<T>() where T: class
        {            
            return _factory.GetService<T>();
        }        
        
        /// <summary>
        /// Gets an instance of HttpClient to connect to Test service
        /// </summary>
        /// <param name="allowAutoRedirect"></param>
        /// <returns></returns>
        protected virtual HttpClient GetHttpClientForSUT(bool allowAutoRedirect = true, bool setCustomIpAddress = true)
        {
            if (HttpClient == null)
            {
                if (!_factory.UseInMemoryService)
                {
                    if (_factory.OverrideClientBaseUrl == null)
                    {
                        throw new Exception("For non-in-memory service you need to set the OverrideClientBaseUrl for the factory!");
                    }
                    
                    HttpClient = GetHttpClientForExternal(_factory.OverrideClientBaseUrl);
                }
                else
                {
                    var options = new WebApplicationFactoryClientOptions
                                    {
                                        AllowAutoRedirect = allowAutoRedirect                                        
                                    };

                    if (_factory.OverrideClientBaseUrl != null)
                    {
                        options.BaseAddress = new Uri(_factory.OverrideClientBaseUrl);
                    }

                    HttpClient = _factory.CreateClient(options);     
                }                           
            }

            if (setCustomIpAddress && !String.IsNullOrEmpty(CustomIpAddress))
            {
                HttpClient.DefaultRequestHeaders.Remove(HttpContextExtensions.RequestProxyIPKey);
                HttpClient.DefaultRequestHeaders.Add(HttpContextExtensions.RequestProxyIPKey, CustomIpAddress);
            }
            
            return HttpClient;
        }

        protected virtual HttpClient GetHttpClientForExternal(string baseUrl)
        {
            if (string.IsNullOrEmpty(baseUrl))
            {
                throw new ArgumentNullException(nameof(baseUrl));
            }
            
            return new HttpClient() { BaseAddress = new Uri(baseUrl) };
        }

        /// <summary>
        /// Possibility to init the Integration test flow by setting a Test user and also parsing the url
        /// </summary>
        /// <param name="expectedHttpStatusCode"></param>
        /// <param name="url"></param>
        /// <param name="urlKeyValueMapper"></param>
        /// <returns></returns>
        protected virtual string InitTestUserAndUrl(HttpStatusCode expectedHttpStatusCode, string url, Dictionary<string, object> urlKeyValueMapper = null)
        {            
            TestUser.GetInstance().DisableAuthentication = expectedHttpStatusCode != HttpStatusCode.Unauthorized;
            
            ModifyTestUser(expectedHttpStatusCode);    

            if (urlKeyValueMapper != null && urlKeyValueMapper.Any())  
            {
                foreach(var key in urlKeyValueMapper.Keys)
                {
                     var value = urlKeyValueMapper[key];
                     if (value != null)
                     {
                         url = url.Replace(key, urlKeyValueMapper[key].ToString());
                     }                     
                }
            }           
                  
            Logger.LogDebug($"Calling url {url}");

            return url;
        } 

        /// <summary>
        /// Sets the Integration Test user for the test based on the expected HttpStatus Code
        /// It is recommended to distinguish between HttpStatusCode.Unauthorized / Forbidden and other codes
        /// </summary>
        /// <param name="expectedHttpStatusCode"></param>
        protected virtual void ModifyTestUser(HttpStatusCode expectedHttpStatusCode)
        {     
            if (expectedHttpStatusCode != HttpStatusCode.Forbidden)
            {
                // Create a default system user wtih access to the service
                TestUser.UserClaims = new List<Claim>
                {                                      
                };
            }
            else
            {
                TestUser.UserClaims = new List<Claim>
                {
                };
            }       
        }          

        /// <summary>
        /// Handles the url call response, logs errors if found 
        /// </summary>
        /// <param name="response"></param>
        /// <param name="expectedHttpStatusCode"></param>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        protected virtual async Task<T> HandleUrlCallResponse<T>(HttpResponseMessage response, HttpStatusCode expectedHttpStatusCode, int? expectedNumberOfRecords = null) where T: class
        {
            if (response is null)
            {
                throw new ArgumentNullException(nameof(response));
            }

            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                var problemDetails = await response.Content.ReadAsAsync<ValidationProblemDetailsDto>(JsonFacade, JsonOptions).ConfigureAwait(false);
                problemDetails.Should().NotBeNull();                 
                Logger.LogError(JsonFacade.Serialize<ValidationProblemDetailsDto>(problemDetails, JsonOptions));
            }   

            response.StatusCode.Should().Be(expectedHttpStatusCode);

            if (expectedHttpStatusCode == HttpStatusCode.OK || expectedHttpStatusCode == HttpStatusCode.Created)
            {                
                var data = await response.EnsureSuccessStatusCode().Content.ReadAsAsync<T>(JsonFacade, JsonOptions).ConfigureAwait(false);
                data.Should().NotBeNull();

                // If passed type is a collection
                if (typeof(T).GetInterface(nameof(IEnumerable)) != null)
                {
                    var dataCollection = data as IEnumerable;
                    if (expectedNumberOfRecords != null)
                    {
                        if (expectedNumberOfRecords == 0)
                        {
                            dataCollection.Should().NotBeNull();
                            dataCollection.Should().BeEmpty();    
                        }
                        else
                        {
                            dataCollection.Should().NotBeNullOrEmpty();
                            dataCollection.Should().HaveCount(expectedNumberOfRecords.Value);                              
                        }                        
                    }
                    else
                    {   
                        dataCollection.Should().NotBeNullOrEmpty();
                        dataCollection.Should().HaveCountGreaterThan(0);    
                    }                    
                }           
                
                return data;  
            }             

            return default(T);
        }   

        #endregion
    }
}
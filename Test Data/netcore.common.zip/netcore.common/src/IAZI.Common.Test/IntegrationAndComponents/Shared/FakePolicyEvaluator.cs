using System.Security.Claims;
using System.Threading.Tasks;
using IAZI.Common.Core.Interfaces.Services.Auth;
using IAZI.Common.Service.Utils;
using IAZI.Common.Test.IntegrationAndComponents.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Test.IntegrationAndComponents.Shared
{
    /// <summary>
    /// Based on https://itbackyard.com/how-to-mock-authorize-attribute-for-testing-in-asp-net-core-3-1/
    /// This allows us to Authenticate users when Authorize attribute is used on Controllers / Actions 
    /// </summary>
    public class FakePolicyEvaluator : PolicyEvaluator, IPolicyEvaluator
    {
        private readonly IAuthorizationService _authorization;

        private readonly IUserClaimInfoService _userClaimInfoService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="authorization">The authorization service.</param>
        public FakePolicyEvaluator(IAuthorizationService authorization, IUserClaimInfoService userClaimInfoService) : base(authorization)
        {
            _authorization = authorization;
            _userClaimInfoService = userClaimInfoService;
        }

        public override async Task<AuthenticateResult> AuthenticateAsync(AuthorizationPolicy policy, HttpContext context)
        {
            var testScheme = "FakeScheme";
            
            var principal = new ClaimsPrincipal();
            
            // Regarding this dependency please check the comments in the class TestUser
            var userSetup = TestUser.GetInstance();
            
            principal.AddIdentity(new ClaimsIdentity(userSetup.UserClaims, testScheme));
           
            // It is possible to disable the authentication logic to test for 401 error
            if (!userSetup.DisableAuthentication)
            {                
                return await Task.FromResult(AuthenticateResult.Fail("Authentication failed since it was not disabled in the TestUser properties."));
            }
                        
            // We are completely overwriting the authentication logic here and create a ticket to successfully authenticate the user
            return await Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(principal,
                new AuthenticationProperties(), testScheme)));
        }

        public override async Task<PolicyAuthorizationResult> AuthorizeAsync(AuthorizationPolicy policy,
            AuthenticateResult authenticationResult, HttpContext context, object resource)
        {
            var userSetup = TestUser.GetInstance();
            
            if (userSetup.DisableAuthorization)
            {
                var claimInfo = _userClaimInfoService.ExtractUserClaimInfo(userSetup.UserClaims, context.Request.Headers);
                context.SetAuthTokenClaimInfo(claimInfo); 

                if (userSetup.AuthData != null)
                {
                    context.SetAuthTokenData(userSetup.AuthData);
                }

                if (userSetup.DisableAuthentication)
                {
                    return await Task.FromResult(PolicyAuthorizationResult.Success());
                }                
            }            

            return await base.AuthorizeAsync(policy, authenticationResult, context, resource);
        }
    }
}
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net.Http;
using IAZI.Common.Core.Models.Web.Init;
using IAZI.Common.Core.Utils;
using IAZI.Common.Service.Web.Init;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace IAZI.Common.Test.IntegrationAndComponents.Shared
{
    /// <summary>
    /// Web Application Factory for testing purposes
    /// </summary>
    public abstract class TestWebApplicationFactoryBase<TStartup> : WebApplicationFactory<TStartup> where TStartup: RootStartupBase
    {       
        #region Properties

        /// <summary>
        ///  Host property only required for non-in-memory server
        /// </summary>
        private IHost _host; 

        public override IServiceProvider Services
        {
            get
            {
                if (UseInMemoryService)
                {
                    return base.Services;
                }
                
                return _host.Services;
            }
        } 

        /// <summary>
        ///  Defines the environment the test server will execute the service, default is Production
        /// </summary>
        /// <value></value>
        public virtual string Environment
        {
            get
            {
                return Microsoft.Extensions.Hosting.Environments.Production;
            }
        }       

        protected readonly ILogger<TestWebApplicationFactoryBase<TStartup>> Logger;

        public virtual bool UseInMemoryService
        {
            get;
            private set;
        }

        protected virtual string OverrideAspNetServiceUrls
        {
            get;
            private set;
        }

        public virtual string OverrideClientBaseUrl
        {
            get;
            private set;
        }

        public virtual string OverrideContentRootPath
        {
            get;
            private set;
        }
            
        #endregion

         #region Constructor        
      
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="factory"></param>
        public TestWebApplicationFactoryBase(bool useInMemoryService = true, string overrideAspNetServiceUrls = null, string overrideClientBaseUrl = null, string overrideContentRootPath = null, bool overrideContentRootPathUseCurrentDirectory = false)
        {
            UseInMemoryService = useInMemoryService;
            OverrideAspNetServiceUrls = overrideAspNetServiceUrls;  
            OverrideClientBaseUrl = overrideClientBaseUrl;   
            OverrideContentRootPath = overrideContentRootPath;  
            
            if (overrideContentRootPathUseCurrentDirectory)
            {
                OverrideContentRootPath = Directory.GetCurrentDirectory();
            }

            if (!UseInMemoryService)
            {
                // Breaking change while migrating from 2.2 to 3.1, TestServer was not called anymore
                CreateServer(null);  
            }            
        }
            
        #endregion
        
        #region Protected methods 

        protected override TestServer CreateServer(IWebHostBuilder builder)
        {
            if (UseInMemoryService)
            {
                return base.CreateServer(builder);
            }

            if (Environment != null)
            {
                EnvironmentExtensions.Set("ASPNETCORE_ENVIRONMENT", Environment);
            }
            
            if (OverrideAspNetServiceUrls != null)
            {
                EnvironmentExtensions.Set("ASPNETCORE_URLS", OverrideAspNetServiceUrls);     
            }
            
            var hostbuilder = CreateHostBuilder();
            if (OverrideContentRootPath != null)
            {
                hostbuilder.UseContentRoot(OverrideContentRootPath);            
            } 
            _host = hostbuilder.Build();
            _host.Start();       

            return new TestServer(new WebHostBuilder().UseStartup<FakeStartup>());
        }     

        protected override IWebHostBuilder CreateWebHostBuilder()
        {            
            if (UseInMemoryService)
            {
                return base.CreateWebHostBuilder();
            }
            
            // We don't use obsolete WebHost anymore
            return null;
        }  

        /// <summary>
        /// ConfigureWebHost
        /// </summary>
        /// <param name="builder"></param>
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {                        
            builder.UseEnvironment(Environment);
            
            builder.ConfigureTestServices(services =>
            {                                
                services.AddSingleton<IPolicyEvaluator, FakePolicyEvaluator>();
                /* services.AddMvc(options =>
                                { */
                                    // This will allow accessing the services without authentication
                                    // to avoid a dependency to IdentityServer / Service.Auth
                                    // But we need to still set the claims for authorization
                                    //options.Filters.Add(new AllowAnonymousFilter());
                                    //options.Filters.Add(new FakeUserFilter());
                               // });
            });          
            
            base.ConfigureWebHost(builder);
        }

        /// <summary>
        /// Required for Integration Testing 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        protected override IHostBuilder CreateHostBuilder()
        {                                            
            return Bootstrapper.GetInstance().Features.CreateHostBuilder<TStartup>(null);                      
        }  

        protected override IHost CreateHost(IHostBuilder builder)
        {
            if (OverrideContentRootPath != null)
            {
                builder.UseContentRoot(OverrideContentRootPath);            
            }            
            return base.CreateHost(builder);
        }        
            
        #endregion

        #region Public methods

         /// <summary>
        /// Request services via IoC
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public virtual T GetService<T>() where T: class
        {
            return Services.GetService(typeof(T)) as T;
        }   

        [ExcludeFromCodeCoverage]
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                _host?.Dispose();
            }
        }

        #endregion
        
    }
}
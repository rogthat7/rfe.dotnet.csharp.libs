using System.Net;
using System.Threading.Tasks;
using IAZI.Common.Test.IntegrationAndComponents.Models;
using Microsoft.AspNetCore.Http;

namespace IAZI.Common.Test.IntegrationAndComponents.Filter
{
    public class FakeRemoteIpAddressMiddleware
    {
        #region Properties

        private readonly RequestDelegate next;

        #endregion
       
        #region Constructor

        /// <summary>
        /// FakeRemoteIpAddressMiddleware
        /// </summary>
        /// <param name="next"></param>
        public FakeRemoteIpAddressMiddleware(RequestDelegate next)
        {
            this.next = next;
        }
            
        #endregion

        #region Public methods

        /// <summary>
        /// Invoke middleware
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext httpContext)
        {
             // Regarding this dependency please check the comments in the class TestWebApplicationFactoryBase
             var userSetup = TestUser.GetInstance();
           
            if (userSetup != null && !string.IsNullOrEmpty(userSetup.IpAddress))
            {
                httpContext.Connection.RemoteIpAddress = IPAddress.Parse(userSetup.IpAddress);
            }            

            await this.next(httpContext);
        }
           
        #endregion

        
    }
}
using System;
using OpenQA.Selenium;

namespace IAZI.Common.Test.Web.Extensions
{
    public class ExpectedConditionsExtensions
    {
         
        #region Public methods

        /// <summary>
        /// An expectation for checking an element is visible and enabled such that you
        /// can click it.
        /// </summary>
        /// <param name="locator">The locator used to find the element.</param>
        /// <returns>The <see cref="IWebElement"/> once it is located and clickable (visible and enabled).</returns>
        public static Func<IWebDriver, IWebElement> ElementToBeClickableWithText(By locator, string text)
        {
            if (text == null)
            {
                throw new ArgumentNullException(nameof(text));
            }
            
            return (driver) =>
            {
                var element = ElementIfVisible(driver.FindElement(locator));
                try
                {
                    if (element != null && element.Enabled && element.Text.Equals(text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        return element;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (StaleElementReferenceException)
                {
                    return null;
                }
            };
        }

        #endregion
        

        #region Private methods

        private static IWebElement ElementIfVisible(IWebElement element)
        {
            return element.Displayed ? element : null;
        }

        #endregion
    }
}
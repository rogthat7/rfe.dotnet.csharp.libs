using System;
using System.Collections.Generic;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace IAZI.Common.Test.Web.Extensions
{
    public static class WebDriverExtensions
    {
       

        #region Public methods

        public static IWebElement FindElementWithWait(this IWebDriver driver, By by, string text = null, double timeoutInMsSeconds = 10 * 2000)
        {
            ExecuteFindElementWaitLogic(driver, by, text, timeoutInMsSeconds);            
            return driver.FindElement(by);
        } 

        public static IEnumerable<IWebElement> FindElementsWithWait(this IWebDriver driver, By by, string text = null, double timeoutInMsSeconds = 10 * 2000)
        {
            ExecuteFindElementWaitLogic(driver, by, text, timeoutInMsSeconds);            
            return driver.FindElements(by);
        } 

        public static IWebElement SafelyFindElement(this IWebDriver driver, By by, double timeoutInMsSeconds = 0.3 * 1000)
        {           
            IWebElement element = null;
            var retries = 0;
            do
            {   retries+=100;
                try
                {
                    element = driver.FindElement(by);                   
                }                     
                catch (NoSuchElementException)
                {
                    Thread.Sleep(100);           
                }                     
            }
            while(element == null && retries < timeoutInMsSeconds);

            return element;                                     
        }
            
        #endregion

        #region Private methods
        private static void ExecuteFindElementWaitLogic(this IWebDriver driver, By by, string text = null, double timeoutInMsSeconds = 10 * 2000)
        {
            if (timeoutInMsSeconds > 0)
            {               
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeoutInMsSeconds));
                
                var ignoreExceptionTypes = new List<Type>() { typeof(StaleElementReferenceException) };                          
                wait.IgnoreExceptionTypes(ignoreExceptionTypes.ToArray());   
                
                if (text == null)
                {
                    wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(by)); 
                }
                else
                {
                    wait.Until(ExpectedConditionsExtensions.ElementToBeClickableWithText(by, text));                     
                }                                                                              
            }                      
        } 

            
        #endregion
    }
}
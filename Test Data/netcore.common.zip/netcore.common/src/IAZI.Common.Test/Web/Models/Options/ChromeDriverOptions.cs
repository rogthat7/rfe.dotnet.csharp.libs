namespace IAZI.Common.Test.Web.Models.Options
{
    public class ChromeDriverOptions
    {
        #region Properties

        public bool HideBrowser { get; set; } = true;
            
        #endregion
    }
}
﻿using System;
using OpenQA.Selenium.Chrome;

namespace IAZI.Common.Test.Web.Interfaces
{
    public interface IChromeDriverFacade : IDisposable
    {
        ChromeDriver ChromeDriver { get; }        
    }
}
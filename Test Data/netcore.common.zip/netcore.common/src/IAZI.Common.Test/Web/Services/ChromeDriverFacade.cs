﻿using System;
using IAZI.Common.Test.Web.Models.Options;
using Microsoft.Extensions.Options;
using OpenQA.Selenium.Chrome;
using IAZI.Common.Test.Web.Interfaces;

namespace IAZI.Common.Test.Web.Services
{
    public class ChromeDriverFacade : IChromeDriverFacade
    {
        #region Properties

        public ChromeDriver ChromeDriver
        {
            get; 
            set;
        }

        private readonly ChromeDriverOptions _chromeDriverOptions;
            
        #endregion

        #region Constructor

        public ChromeDriverFacade(IOptions<ChromeDriverOptions> chromeDriverOptions)
        {      
            _chromeDriverOptions = chromeDriverOptions.Value; 
            InitChromeDriver();       
        }
            
        #endregion

        #region Public Methods       
      
        public void Dispose()
        {
            if (ChromeDriver != null)
            {               
                ChromeDriver.Dispose();
                ChromeDriver = null;
            }            
        }      

        #endregion 

        #region Private methods

        private void InitChromeDriver()
        {
            try
            {
                var co = new ChromeOptions();

                if (_chromeDriverOptions.HideBrowser)
                {
                    co.AddArguments("--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--headless", "--ignore-certificate-errors");
                }
                else
                {
                    co.AddArguments("--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--start-maximized", "--ignore-certificate-errors");
                }

                ChromeDriver = new ChromeDriver(@"/usr/local/bin", co);        
            }
            catch(Exception)
            {
                ChromeDriver?.Dispose();
                throw;
            }               
        }
            
        #endregion   
    }
}
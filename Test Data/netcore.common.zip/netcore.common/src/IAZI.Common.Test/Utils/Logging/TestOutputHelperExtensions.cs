using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Xunit.Abstractions;

namespace IAZI.Common.Test.Utils.Logging
{
    public static class TestOutputHelperExtensions
    {
        public static ILogger<T> CreateLogger<T>(this ITestOutputHelper output) where T: class
        {
            if (output is null)
            {
                throw new ArgumentNullException(nameof(output));
            }

            var serilogLogger = new LoggerConfiguration()
                .MinimumLevel.Verbose()
                .WriteTo.TestOutput(output, LogEventLevel.Debug)
                .CreateLogger()
                .ForContext<T>();

            ILoggerFactory factory = new LoggerFactory();
            factory.AddSerilog(serilogLogger);
            return factory.CreateLogger<T>();
        }
    }
}